# Field Answers + Scenario Clarification (core capability)

Solve "is this field required / what to pass / what format / what enums" type questions.

## Read Path (two-stage: index first, then close reading)

1. **First check `references/kb/api-index.json`** (6.8K, 26 interfaces' uri/title/path/method/operationId) — when the user hasn't named the interface, use it to locate the uri first.
2. **Then close-read `references/kb/api-packs/{uri}.json`** (interface Q&A pack, ~12K on average) — field definitions + required rules + errcodes + spis are all in this one file.

## Field Requiredness Three States

- `M` = required; `O` = optional; `C` = conditionally required.
- A C field's determination basis is merged into the api-pack field's `required_when` / `condition_text` / `confidence`:
  - `required_when` has a value → auto-determinable (e.g. `clearingType=="SWIFT"`).
  - Only `condition_text` has a value → show the condition text to the user for confirmation.
  - Both empty (`confidence=unresolved`) → the condition is in an external doc, mark "to be confirmed", attach `source_doc`, **must not fabricate**.

## Scenario Determination

Use `references/rules/scenario-tree.yaml` to **guide question by question** (one question at a time), producing scenario tags (clearingType / bankCountry / paymentType / accountType, etc.).

## Solving

```
python3 scripts/resolve_fields.py --api <uri> --scene clearingType=LOCAL,bankCountry=BR
```

Output a "fill-in-as-is list" (required/optional/condition-to-confirm), not prose.

## Beneficiary Registration (supplier_request) External References

Enums, country/region, and element rules beyond the fields are in `references/external/`:
- Beneficiary elements (by country): first check `external/supplier/supplier-index.yaml` (contains the `groups` index, `field_enums` enums, `bank_list`, `idn_provinces`, `idn_cities`) to locate → read `external/supplier/{COUNTRY}.yaml` (2~7K per country, with format validators/enums/required M/O). The full bank list uses the interface `supplier__banklist`.
- `country-list.yaml` — 255 countries/regions (ISO 3166-1, alpha2/alpha3/numeric/short name/full name).
- `business-type-enums.yaml` — business type enums (non-settlement 19 + level-2 4 + settlement 14).
- `bank-exempt-list.yaml` — 143 banks exempt from province/city/branch.

⚠️ external/ is a local xlsx snapshot; when it conflicts with official interfaces/Feishu docs, the official version prevails.

## Iron Rules

- If the solving result has "condition to confirm" fields, first confirm the conditions with the user, then give the final list.
- Prefer marking "to be confirmed" over fabricating field rules.
