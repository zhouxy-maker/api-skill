#!/usr/bin/env python3
"""
render_fallback.py — 无头浏览器渲染兜底，处理开放平台「方案文档页」（非接口 tree 中的页面）。

适用场景：标准方案文档里的链接形如 /docs/solutions/apidoc/{solutionId}/{docId}，
这些页面（如「来账商户通知」回调通知）不在 apis/tree.json 中，其 JSON 路径均返回 403，
只能用无头浏览器渲染 DOM 后解析表格。

用法：
  # 直接渲染（需本机安装 Chrome）
  python3 render_fallback.py --url https://open.gptransfer.hk/docs/solutions/apidoc/693becdc7d2c7d0001a23a09/693bed203b0a750001efa619 --name gpt.inbound-notify --title 来账商户通知

  # 跳过渲染，直接解析已有 HTML（离线 / 构建时复用已渲染结果）
  python3 render_fallback.py --html /tmp/rendered.html --name gpt.inbound-notify --title 来账商户通知
"""
import argparse
import html as _html
import json
import os
import re
import subprocess
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPIS_DIR = os.path.join(SKILL_DIR, "references", "kb", "spis")


def log(msg):
    print(f"[render] {msg}", file=sys.stderr)


def find_chrome():
    for p in (
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
    ):
        if os.path.exists(p):
            return p
    return None


def render_url(url, out_html):
    chrome = find_chrome()
    if not chrome:
        raise SystemExit("未找到 Chrome，请先安装 Chrome 或用 --html 指定已渲染的 HTML 文件")
    cmd = [
        chrome, "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
        "--disable-default-apps", "--disable-sync", "--metrics-recording-only",
        "--user-data-dir=/tmp/yop-render-profile", "--virtual-time-budget=20000", "--dump-dom", url,
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    with open(out_html, "w", encoding="utf-8") as f:
        f.write(r.stdout)
    if len(r.stdout) < 5000:
        log("⚠️ 渲染结果过短，可能页面未加载完整")
    return out_html


def strip_tags(s):
    s = re.sub(r"<br\s*/?>", "\n", s)
    s = re.sub(r"</p>", "\n", s)
    s = re.sub(r"<[^>]+>", "", s)
    return _html.unescape(s).strip()


def cell_text(td):
    return re.sub(r"\s+", " ", strip_tags(td)).strip()


def parse_type(cell):
    """'String（32）' -> ('string', '32')；'BigDecimal' -> ('BigDecimal', '')。"""
    c = cell_text(cell)
    m = re.match(r"^(\w+)[（(]([^）)]*)[）)]$", c)
    if m:
        return m.group(1), m.group(2)
    return c, ""


def parse_required(cell):
    """'C（status=SUCCESS时非空）' -> ('C', 'status=SUCCESS时非空')；'M' -> ('M', '')。"""
    c = cell_text(cell)
    m = re.match(r"^([MOC])(?:[（(](.*?)[）)])?$", c)
    if m:
        return m.group(1), (m.group(2) or "").strip()
    return (c, "") if c else ("", "")


def parse_enum(cell):
    """多格式枚举拆分（'VALUE : label' / 'VALUE-label' / 'VALUE 中文label' / '10：数字label'）。

    采用「定位 VALUE 边界」的分割法：找出所有候选值（大写+下划线串 或 数字），
    相邻两个值之间的文本即前一个值的 label。
    """
    c = cell_text(cell)
    if not c:
        return None
    marks = [(m.start(), m.group()) for m in re.finditer(r"[A-Z][A-Z0-9_]{1,40}|\d{1,2}", c)]
    if not marks:
        return None
    pairs = []
    for i, (pos, val) in enumerate(marks):
        if val in ("GET", "POST", "API", "SDK"):
            continue
        end = marks[i + 1][0] if i + 1 < len(marks) else len(c)
        label = c[pos + len(val):end].strip()
        label = re.sub(r"^[:：\-—]\s*", "", label).strip()
        pairs.append((val, label))
    seen, out = set(), []
    for v, lab in pairs:
        if v in seen:
            continue
        seen.add(v)
        out.append({"value": v, "label": lab})
    # 多个值，或单个值且 label 为中文开头（如 'ORIGINAL-原路退款'）
    if len(out) >= 2 or (len(out) == 1 and out[0]["label"] and re.match(r"[\u4e00-\u9fff]", out[0]["label"])):
        return out
    return None


CONTAINER_TYPES = {"list", "List", "object", "Object", "array", "Array"}


def parse_rows(html):
    tables = re.findall(r"<table[\s\S]*?</table>", html)
    if not tables:
        return None
    t = tables[0]
    rows = []
    for tr in re.findall(r"<tr[^>]*>[\s\S]*?</tr>", t):
        tds = re.findall(r"<td[^>]*>([\s\S]*?)</td>", tr)
        if len(tds) < 2:
            continue
        name, param = cell_text(tds[0]), cell_text(tds[1])
        if not param:
            continue
        typ, maxlen = parse_type(tds[3])
        req, cond = parse_required(tds[5])
        rows.append({
            "name": name,
            "param": param,
            "type": typ,
            "maxLength": maxlen,
            "required": req,
            "condition": cond,
            "enum": parse_enum(tds[2]),
            "description": cell_text(tds[6]),
        })
    return rows


def build_hierarchy(rows):
    """栈式层级：type 为容器（list/object）的字段作为父节点，其后的基本类型字段归入其下。

    说明：SPI 通知字段表通常只有一层嵌套（容器 → 基本类型字段），遇到新容器即视为
    前一个容器已结束、回到顶层。若将来出现多层嵌套需人工确认。
    """
    roots = []
    stack = []
    for r in rows:
        node = dict(r)
        node["children"] = []
        is_container = r["type"] in CONTAINER_TYPES
        if is_container:
            stack.clear()
            roots.append(node)
            stack.append(node)
        else:
            if stack:
                stack[-1]["children"].append(node)
            else:
                roots.append(node)
    return roots


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url")
    ap.add_argument("--html", help="跳过渲染，直接解析已有 HTML 文件")
    ap.add_argument("--name", required=True, help="输出文件名（如 gpt.inbound-notify）")
    ap.add_argument("--title", required=True, help="接口标题")
    ap.add_argument("--method", default="POST")
    args = ap.parse_args()

    if args.html:
        html_path = args.html
    elif args.url:
        html_path = os.path.join("/tmp", f"yop-render-{args.name}.html")
        render_url(args.url, html_path)
    else:
        raise SystemExit("需要 --url 或 --html 之一")

    html_text = open(html_path, encoding="utf-8").read()
    rows = parse_rows(html_text)
    if not rows:
        raise SystemExit("未解析到表格字段，请确认 HTML 内容")

    data = {
        "name": args.name,
        "title": args.title,
        "method": args.method,
        "source": args.url or args.html,
        "fields": build_hierarchy(rows),
        "fetchedAt": __import__("time").strftime("%Y-%m-%dT%H:%M:%S"),
    }
    os.makedirs(SPIS_DIR, exist_ok=True)
    out = os.path.join(SPIS_DIR, f"{args.name}.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    log(f"✅ 输出 {out}，字段 {len(rows)} 个")


if __name__ == "__main__":
    main()
