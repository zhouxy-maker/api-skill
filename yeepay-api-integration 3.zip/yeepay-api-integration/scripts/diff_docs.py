#!/usr/bin/env python3
"""
diff_docs.py — 变更监控：重新抓取开放平台文档，对比快照，输出变更报告。

用法：
  python3 diff_docs.py            # 抓取并输出变更报告
  python3 diff_docs.py --check    # 仅比对（不抓取），用当前 manifest 与上次快照对比

原理：fetch_docs.py 每次抓取都会生成 kb/.snapshot/manifest.json（每个接口的 md5），
本脚本先备份旧 manifest，重新抓取后对比，输出 新增/删除/字段变更 三级报告。
"""
import argparse
import json
import os
import shutil
import subprocess
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SNAP_DIR = os.path.join(SKILL_DIR, "references", "kb", ".snapshot")
MANIFEST = os.path.join(SNAP_DIR, "manifest.json")


def find_python():
    """优先用带 pyyaml 的 python。"""
    for p in (
        "/Users/c0259/.workbuddy/binaries/python/envs/default/bin/python3",
        "/usr/bin/python3",
    ):
        if os.path.exists(p):
            return p
    return sys.executable


def load_manifest(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"apis": {}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="仅比对，不重新抓取")
    args = ap.parse_args()

    old = load_manifest(MANIFEST)
    if not args.check:
        print("[diff] 重新抓取文档...", file=sys.stderr)
        py = find_python()
        r = subprocess.run([py, os.path.join(SKILL_DIR, "scripts", "fetch_docs.py")],
                           capture_output=True, text=True)
        if r.returncode != 0:
            print("[diff] 抓取失败：", r.stderr[-500:], file=sys.stderr)
            sys.exit(1)

    new = load_manifest(MANIFEST)
    old_apis, new_apis = old.get("apis", {}), new.get("apis", {})

    added = {k: v for k, v in new_apis.items() if k not in old_apis}
    removed = {k: v for k, v in old_apis.items() if k not in new_apis}
    changed = {k: (old_apis[k], new_apis[k])
               for k in old_apis if k in new_apis and old_apis[k].get("md5") != new_apis[k].get("md5")}

    print("\n===== 文档变更报告 =====")
    print(f"上次：{old.get('fetchedAt', '无')}  本次：{new.get('fetchedAt', '无')}")
    print(f"接口总数：{len(old_apis)} -> {len(new_apis)}")
    print(f"新增：{len(added)} | 删除：{len(removed)} | 变更：{len(changed)}")

    for k, v in added.items():
        print(f"  [新增] {v.get('title', k)}  {v.get('method')} {v.get('path')}")
    for k, v in removed.items():
        print(f"  [删除] {v.get('title', k)}  {v.get('method')} {v.get('path')}")
    for k, (o, n) in changed.items():
        print(f"  [变更] {n.get('title', k)}  {n.get('method')} {n.get('path')}")
    if not (added or removed or changed):
        print("  无变更")

    if changed:
        print("\n变更接口的字段 diff 可用以下方式查看：")
        print("  python3 scripts/fetch_docs.py --only <uri> 后 diff kb/apis/<uri>.json")


if __name__ == "__main__":
    main()
