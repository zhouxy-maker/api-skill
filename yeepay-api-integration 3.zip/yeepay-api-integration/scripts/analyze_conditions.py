#!/usr/bin/env python3
"""
analyze_conditions.py — 扫描知识库所有条件必填（C）字段，生成规则库骨架 + 自动推导。

对每个 C 字段自动提取三类信息：
  1. condition_text —— 描述中「当…时必填 / …时非空 / …模式下需填写」等条件原文
  2. source_doc     —— 描述中「详见：…」「见…」引用的外部参考文档（条件真正所在处）
  3. required_when  —— 可结构化的条件表达式（供 resolve_fields.py 求解），无法结构化则为空

confidence 分级：inferred（AI 从描述提取，待人工确认）/ unresolved（条件在外部文档，待补齐）。

输出：references/rules/field-conditions.yaml
"""
import glob
import json
import os
import re
import sys
import yaml

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_DIR = os.path.join(SKILL_DIR, "references", "kb")
RULES_DIR = os.path.join(SKILL_DIR, "references", "rules")

# 条件语义关键词
REQ_PAT = re.compile(r"当(.+?)(?:时|的情况下|的场景下|模式下)[，,]?\s*(?:需|必须|为必填|必填|非空|填写|需要填写)", re.S)
REQ_PAT2 = re.compile(r"(.+?)(?:模式下|场景下|时|情况下)[，,]?\s*(?:需|必须|需要)?\s*填写", re.S)
SRC_PAT = re.compile(r"(?:详见|见)[:：]?\s*[《「]?([^。；;，,\n]+)[》」]?")


def extract_condition(desc):
    """从描述文本提取条件原文（多个候选取最长者）。"""
    if not desc:
        return None
    conds = []
    for m in REQ_PAT.finditer(desc):
        conds.append("当" + m.group(1) + "时必填")
    for m in REQ_PAT2.finditer(desc):
        conds.append(m.group(1) + "时需填写")
    return conds[0] if conds else None


def extract_source(desc):
    """提取「详见：XXX」「见 XXX」引用的外部文档名。"""
    if not desc:
        return None
    m = SRC_PAT.search(desc)
    if m:
        return m.group(1).strip()
    return None


def to_when(cond_text, field_values):
    """把条件原文结构化为 required_when 表达式（仅限简单单值 AND 条件）。

    示例：'当clearingType=LOCAL，bankCountry=BR，paymentType=PIX时必填'
      -> 'clearingType=="LOCAL" && bankCountry=="BR" && paymentType=="PIX"'

    安全策略：仅当所有子句都是「字段=单个枚举值」的纯 AND 时才生成；一旦出现
    '/'（枚举多选）、'或'、'非'、'不在'、括号等复杂语义，返回 None 交由人工。
    """
    if not cond_text:
        return None
    body = re.sub(r"^当", "", cond_text)
    body = re.sub(r"时必填$", "", body)
    body = re.sub(r"时需填写$", "", body)
    body = re.sub(r"时非空$", "", body)
    # 复杂语义直接放弃
    if re.search(r"[/，,、]?\s*(或|非|不在|且|以及|、)", body):
        return None
    clauses = []
    for seg in re.split(r"[，,;；\n]+", body):
        seg = seg.strip()
        if not seg:
            continue
        m = re.match(r"^(\w+)\s*[=＝]\s*([A-Za-z0-9_\-]+)$", seg)
        if not m:
            return None
        field, val = m.group(1), m.group(2)
        if field not in field_values:
            return None
        clauses.append(f'{field}=="{val}"')
    return " && ".join(clauses) if clauses else None


def flatten(nodes, out=None):
    if out is None:
        out = []
    for n in nodes:
        out.append(n)
        if n.get("children"):
            flatten(n["children"], out)
    return out


def main():
    cond_fields = {}
    for f in glob.glob(os.path.join(KB_DIR, "apis", "*.json")):
        d = json.load(open(f, encoding="utf-8"))
        uri = d["uri"]
        all_fields = flatten(d.get("reqParams", []))
        field_names = {n.get("path", "").split(".")[-1] for n in all_fields}
        for n in all_fields:
            if n.get("required") != "C":
                continue
            desc = n.get("description", "")
            key = f"{uri}.{n.get('path','')}"
            cond_fields[key] = {
                "api": uri,
                "apiTitle": d.get("title", ""),
                "field": n.get("path", ""),
                "type": n.get("type", ""),
                "enum": [e["value"] for e in (n.get("enum") or [])] or None,
                "condition_text": extract_condition(desc),
                "source_doc": extract_source(desc),
                "description": desc,
            }

    out = {"_meta": {
        "说明": "条件必填规则库（字段级 C）。required_when 为空表示条件无法自动结构化，需人工确认，勿臆造。",
        "confidence": "confirmed=已人工确认 / inferred=AI 从描述提取，待确认 / unresolved=条件在外部文档，待补齐",
        "生成": "python3 scripts/analyze_conditions.py",
    }, "fields": {}}
    for key in sorted(cond_fields):
        f = cond_fields[key]
        cond_text = f["condition_text"]
        when = to_when(cond_text, field_names_of(f["api"]))
        conf = "inferred" if cond_text else "unresolved"
        out["fields"][key] = {
            "api": f["api"],
            "apiTitle": f["apiTitle"],
            "field": f["field"],
            "type": f["type"],
            "enum": f["enum"],
            "required_when": when,
            "condition_text": cond_text,
            "source_doc": f["source_doc"],
            "confidence": conf,
            "description": f["description"],
        }

    with open(os.path.join(RULES_DIR, "field-conditions.yaml"), "w", encoding="utf-8") as fp:
        yaml.safe_dump(out, fp, allow_unicode=True, sort_keys=False, width=200)

    from collections import Counter
    conf = Counter(v["confidence"] for v in out["fields"].values())
    with_when = sum(1 for v in out["fields"].values() if v["required_when"])
    with_src = sum(1 for v in out["fields"].values() if v["source_doc"])
    print(f"条件必填字段总数: {len(out['fields'])}")
    print(f"confidence 分布: {dict(conf)}")
    print(f"可结构化 required_when: {with_when}")
    print(f"引用外部文档(source_doc): {with_src}")
    docs = sorted({v["source_doc"] for v in out["fields"].values() if v["source_doc"]})
    print(f"\n被引用的外部参考文档 ({len(docs)} 个):")
    for d in docs:
        print(f"  - {d}")
    print(f"\n骨架已写入 {os.path.join(RULES_DIR, 'field-conditions.yaml')}")


def field_names_of(api):
    """按需从 kb 读取某接口的字段名集合（用于 required_when 校验）。"""
    cache = getattr(field_names_of, "_cache", {})
    if api in cache:
        return cache[api]
    names = set()
    path = os.path.join(KB_DIR, "apis", f"{api}.json")
    if os.path.exists(path):
        d = json.load(open(path, encoding="utf-8"))
        for n in flatten(d.get("reqParams", [])):
            names.add(n.get("path", "").split(".")[-1])
    cache[api] = names
    return names


if __name__ == "__main__":
    main()
