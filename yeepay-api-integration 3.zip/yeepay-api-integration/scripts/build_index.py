#!/usr/bin/env python3
"""
build_index.py — 从完整源派生出「接口问答包」（LLM 精读用）。

背景：kb/apis/{uri}.json 是 fetch_docs.py 产出的完整源，字段解答/联调场景
只需元信息 + 字段 + 错误码 + 回调定义，无需整读大文件。

源（只读，勿手改）：
  kb/apis/{uri}.json          完整源（元信息 + reqParams/respParams + errcodes + spis）
  rules/field-conditions.yaml 条件必填规则库（C 字段的 required_when / condition_text / confidence）

产物（可随时重建）：
  kb/api-packs/{uri}.json     问答包 = 元信息 + reqParams/respParams + errcodes + spis
                              （C 字段合并条件规则，字段已精简）

说明：示例代码不再从开放平台抓取（官方 sampleCodes 已无人维护），
代码生成改由 scripts/gen_code.py 依据 contentType 套用 scripts/code_templates.py 模板。

字段匹配规则：kb/apis 无嵌套 children，字段 key 一律为 {uri}.{name}。

用法：
  python3 build_index.py
"""
import glob
import json
import os
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_DIR = os.path.join(SKILL_DIR, "references", "kb")
RULES_DIR = os.path.join(SKILL_DIR, "references", "rules")
PACK_DIR = os.path.join(KB_DIR, "api-packs")

# reqParams 节点里对 LLM 无用的冗余键（path 恒等于 name，children/depth/root 无嵌套）
DROP_KEYS = {"path", "children", "depth", "root"}
# 条件规则里值得并入字段的键
COND_KEYS = ("required_when", "condition_text", "confidence", "source_doc")


def load_yaml(path):
    try:
        import yaml
    except ImportError:
        sys.stderr.write("缺少 pyyaml\n")
        sys.exit(2)
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def slim_field(node, cond_rule):
    """精简字段节点 + 合并条件规则（仅 C 字段有 cond_rule）。"""
    out = {}
    for k, v in node.items():
        if k in DROP_KEYS:
            continue
        if v is None or v == "" or v == [] or v == {}:
            continue
        out[k] = v
    if cond_rule:
        for k in COND_KEYS:
            if cond_rule.get(k) not in (None, ""):
                out[k] = cond_rule[k]
    return out


def build():
    conditions = load_yaml(os.path.join(RULES_DIR, "field-conditions.yaml"))["fields"]

    os.makedirs(PACK_DIR, exist_ok=True)

    files = sorted(glob.glob(os.path.join(KB_DIR, "apis", "*.json")))
    stats = {"packs": 0, "pack_bytes": 0}
    for f in files:
        api = json.load(open(f, encoding="utf-8"))
        uri = api["uri"]

        # 1) 问答包：字段 + 必填 + errcodes + spis（源已不含 sampleCodes）
        pack = {
            "uri": uri,
            "apiId": api.get("apiId"),
            "title": api.get("title"),
            "method": api.get("method"),
            "path": api.get("path"),
            "apiGroup": api.get("apiGroup"),
            "operationId": api.get("operationId"),
            "desc": api.get("desc"),
            "contentType": api.get("contentType", ""),
            "commonRef": api.get("commonRef"),
            "securityReqs": api.get("securityReqs", []),
            "requestEncrypt": api.get("requestEncrypt", False),
            "responseEncrypt": api.get("responseEncrypt", False),
        }
        req_out = []
        for n in api.get("reqParams", []):
            key = f"{uri}.{n.get('name', '')}"
            cond = conditions.get(key)
            req_out.append(slim_field(n, cond))
        pack["reqParams"] = req_out
        pack["respParams"] = [slim_field(n, None) for n in api.get("respParams", [])]
        pack["errcodes"] = api.get("errcodes", [])
        pack["spis"] = api.get("spis", [])
        # 请求/响应示例对字段解答有参考价值（量小），保留
        if api.get("reqExample"):
            pack["reqExample"] = api["reqExample"]
        if api.get("respExample"):
            pack["respExample"] = api["respExample"]

        pack_path = os.path.join(PACK_DIR, f"{uri}.json")
        with open(pack_path, "w", encoding="utf-8") as fh:
            json.dump(pack, fh, ensure_ascii=False, indent=2)

        stats["packs"] += 1
        stats["pack_bytes"] += os.path.getsize(pack_path)

    print(f"已生成 {stats['packs']} 个 api-packs（共 {stats['pack_bytes']}B）")
    avg = stats["pack_bytes"] // max(stats["packs"], 1)
    print(f"api-pack 平均体积：{avg}B")


if __name__ == "__main__":
    build()
