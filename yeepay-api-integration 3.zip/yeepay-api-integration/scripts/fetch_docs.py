#!/usr/bin/env python3
"""
fetch_docs.py — 抓取易宝国际开放平台（open.gptransfer.hk）文档，生成知识库 kb/。

数据源为静态 JSON，根地址 https://open.gptransfer.hk/apis/docs/ （无需登录）。

性能设计：
  - 并发抓取（ThreadPoolExecutor，10 线程），26 接口约 8~15 秒
  - definition / errcode / spi / models 全部落磁盘缓存（.snapshot/raw 与 .snapshot/models），
    二次运行（无变更）约 1~2 秒
  - --refresh 忽略缓存，强制全量重新抓取

用法：
  python3 fetch_docs.py                 # 默认：缓存优先，缺失才网络抓
  python3 fetch_docs.py --refresh       # 强制重新抓取
  python3 fetch_docs.py --only <uri>    # 只抓单个接口（调试用）
"""
import argparse
import hashlib
import html as _html
import json
import os
import re
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE = "https://open.gptransfer.hk/apis/docs"
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOURCE_DIR = os.path.join(SKILL_DIR, "references", "source")
KB_DIR = os.path.join(SKILL_DIR, "references", "kb")
APIS_DIR = os.path.join(KB_DIR, "apis")
SNAP_DIR = os.path.join(KB_DIR, ".snapshot")
RAW_DIR = os.path.join(SNAP_DIR, "raw")
TREE_CACHE = os.path.join(SNAP_DIR, "tree.json")

UA = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"}

# 全局开关：--refresh 时为 True，忽略所有磁盘缓存
REFRESH = False

# 进程内缓存：models 跨接口复用
_MODEL_CACHE = {}
MODEL_DIR = os.path.join(SNAP_DIR, "models")


def log(msg):
    print(f"[fetch] {msg}", file=sys.stderr)


def http_get(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="replace")


def http_get_json(url, timeout=30):
    return json.loads(http_get(url, timeout))


def cached_json(path, url):
    """优先读磁盘缓存（REFRESH=False 时），否则网络拉取并写缓存。"""
    if not REFRESH and os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    data = http_get_json(url)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    return data


def fetch_model(group, ref):
    key = f"{group}:{ref}"
    if key in _MODEL_CACHE:
        return _MODEL_CACHE[key]
    disk = os.path.join(MODEL_DIR, f"{group}__{ref}.json")
    if not REFRESH and os.path.exists(disk):
        try:
            with open(disk, encoding="utf-8") as f:
                model = json.load(f)
        except Exception:
            model = None
        _MODEL_CACHE[key] = model
        return model
    try:
        model = http_get_json(f"{BASE}/models/{group}/{ref}.json")
    except Exception:
        model = None
    if model is not None:
        os.makedirs(MODEL_DIR, exist_ok=True)
        with open(disk, "w", encoding="utf-8") as f:
            json.dump(model, f, ensure_ascii=False)
    _MODEL_CACHE[key] = model
    return model


def clean_html(s):
    """HTML -> 纯文本，保留换行与枚举项的可读性。"""
    if not s:
        return ""
    s = re.sub(r"<br\s*/?>", "\n", s)
    s = re.sub(r"</p>", "\n", s)
    s = re.sub(r"</li>", "\n", s)
    s = re.sub(r"</(td|th|tr)>", "\t", s)
    s = re.sub(r"<[^>]+>", "", s)
    s = _html.unescape(s)
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n[ \t]+", "\n", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def tri_state(required, condition_required):
    if required:
        return "M"
    if condition_required:
        return "C"
    return "O"


def extract_enum(desc_text):
    if not desc_text:
        return None
    items = []
    for line in desc_text.split("\n"):
        m = re.match(r"^\s*([A-Z][A-Z0-9_\-]{1,40})\s*[:：]\s*(.+?)\s*$", line)
        if m:
            label = m.group(2).strip()
            if m.group(1) in ("GET", "POST", "API", "SDK"):
                continue
            items.append({"value": m.group(1), "label": label})
    if len(items) < 2:
        if len(desc_text) > 120:
            return None
        items = []
        for m in re.finditer(r"([A-Z][A-Z0-9_\-]{1,40})\s*[:：\-]\s*([^\s，。；,]{0,20})", desc_text):
            items.append({"value": m.group(1), "label": m.group(2).strip()})
    seen, uniq = set(), []
    for v in items:
        if v["value"] not in seen:
            seen.add(v["value"])
            uniq.append(v)
    return uniq if len(uniq) >= 2 else None


def fetch_tree():
    tree = cached_json(TREE_CACHE, f"{BASE}/apis/tree.json")
    flat = {}
    def walk(n, loc=""):
        cur = f"{loc}/{n.get('code','')}" if loc else n.get("code", "")
        for it in n.get("items", []) or []:
            flat[it["uri"]] = {
                "apiId": it["apiId"], "title": it["title"], "method": it["method"],
                "path": it["path"], "location": it.get("location", ""),
                "operationId": it.get("operationId", ""),
            }
        for c in n.get("children", []) or []:
            walk(c, cur)
    for n in tree:
        walk(n)
    return flat


def extract_slugs():
    slugs = {}
    for fn in os.listdir(SOURCE_DIR):
        if not fn.endswith(".md"):
            continue
        md = open(os.path.join(SOURCE_DIR, fn), encoding="utf-8").read()
        for url in re.findall(r"\((https://open\.gptransfer\.hk/docs/(?:solutions/apidoc|apis)/[^)]+)\)", md):
            last = url.rstrip("/").split("/")[-1]
            if re.fullmatch(r"[0-9a-f]{24}", last):
                slugs[last] = "docid"
            else:
                slugs[last] = "api"
    return slugs


def normalize_field(n, path_prefix=""):
    name = n.get("name") or n.get("title") or ""
    desc = clean_html(n.get("description") or n.get("desc") or "")
    return {
        "name": name,
        "path": f"{path_prefix}.{name}".strip("."),
        "title": n.get("title") or name,
        "type": n.get("type") or "",
        "format": n.get("format") or "",
        "maxLength": n.get("maxLength") or "",
        "required": tri_state(n.get("required"), n.get("conditionRequired")),
        "example": n.get("example") or "",
        "defVal": n.get("defVal") or "",
        "encrypt": bool(n.get("encrypt")),
        "description": desc,
        "enum": extract_enum(desc),
        "children": [],
    }


def build_fields(nodes, group):
    flat = []
    def rec(ns, prefix, depth):
        result = []
        for n in ns or []:
            ref = n.get("ref")
            if ref and depth < 8:
                model = fetch_model(group, ref)
                if isinstance(model, list):
                    result.extend(rec(model, prefix, depth + 1))
                    continue
            f = normalize_field(n, prefix)
            children = n.get("children") or []
            if children:
                f["children"] = rec(children, f["path"], depth + 1)
            if f["name"]:
                flat.append(f)
            elif f["children"]:
                result.extend(f["children"])
                continue
            result.append(f)
        return result
    tree = rec(nodes, "", 0)
    return tree, flat


def _section_nodes(definition, section):
    nodes = []
    for ct, ns in (definition.get(section) or {}).items():
        if isinstance(ns, list):
            nodes.extend(ns)
    return nodes


def build_api(slug, api_meta):
    aid = api_meta["apiId"]
    definition = cached_json(os.path.join(RAW_DIR, aid, "definition.json"),
                             f"{BASE}/apis/{aid}/definition.json")
    group = definition.get("apiGroup") or "gpt"

    req_tree, _ = build_fields(_section_nodes(definition, "reqParams"), group)
    resp_tree, _ = build_fields(_section_nodes(definition, "respParams"), group)

    errcodes = []
    try:
        errcodes = cached_json(os.path.join(RAW_DIR, aid, "errcode.json"),
                               f"{BASE}/apis/{aid}/errcode.json") or []
    except Exception:
        pass

    spis = []
    try:
        spis = cached_json(os.path.join(RAW_DIR, aid, "spi.json"),
                           f"{BASE}/apis/{aid}/spi.json") or []
    except Exception:
        pass

    return {
        "uri": slug,
        "apiId": aid,
        "title": definition.get("title") or api_meta.get("title", ""),
        "method": definition.get("method") or api_meta.get("method", ""),
        "path": definition.get("path") or api_meta.get("path", ""),
        "apiGroup": group,
        "operationId": api_meta.get("operationId", ""),
        "securityReqs": definition.get("securityReqs") or [],
        "commonRef": definition.get("commonRef") or "",
        "requestEncrypt": bool(definition.get("requestEncrypt")),
        "responseEncrypt": bool(definition.get("responseEncrypt")),
        "desc": clean_html(definition.get("desc") or ""),
        # reqParams 的顶层 key 即 Content-Type（application/json / x-www-form-urlencoded / multipart）
        # gen_code.py 据此选择调用装配方式
        "contentType": next(iter(definition.get("reqParams") or {}), ""),
        "reqParams": req_tree,
        "respParams": resp_tree,
        "reqExample": definition.get("reqExamples") or {},
        "respExample": definition.get("respExamples") or {},
        "errcodes": errcodes,
        "spis": spis,
        "fetchedAt": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


def raw_fingerprint(aid):
    """计算接口 raw 缓存（definition/errcode/spi）的指纹，用于增量构建判定。"""
    fp = []
    for kind in ("definition", "errcode", "spi"):
        p = os.path.join(RAW_DIR, aid, f"{kind}.json")
        if os.path.exists(p):
            st = os.stat(p)
            fp.append(f"{kind}:{st.st_mtime_ns}:{st.st_size}")
    return "|".join(fp)


def main():
    global REFRESH
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", help="只抓单个 uri")
    ap.add_argument("--refresh", action="store_true", help="忽略缓存，强制重新抓取")
    args = ap.parse_args()
    REFRESH = args.refresh

    os.makedirs(APIS_DIR, exist_ok=True)
    os.makedirs(SNAP_DIR, exist_ok=True)

    slugs = extract_slugs()
    log(f"从标准方案文档解析到 {len(slugs)} 个链接")
    docids = [s for s, k in slugs.items() if k == "docid"]
    if docids:
        log(f"其中 {len(docids)} 个为方案文档页（docId），需 render_fallback.py 处理：{docids}")

    tree_flat = fetch_tree()
    log(f"tree.json 共 {len(tree_flat)} 个接口")

    # 读上次构建指纹，用于增量判定
    state_path = os.path.join(SNAP_DIR, "build-state.json")
    old_state = {}
    if os.path.exists(state_path):
        try:
            old_state = json.load(open(state_path, encoding="utf-8"))
        except Exception:
            old_state = {}

    # 需要重新 build 的接口（raw 变更或首次）
    todo, reused, skipped = [], [], []
    for slug, kind in sorted(slugs.items()):
        if kind == "docid":
            skipped.append(slug)
            continue
        if args.only and slug != args.only:
            continue
        meta = tree_flat.get(slug)
        if not meta:
            log(f"⚠️ 未在 tree.json 找到 {slug}，跳过")
            skipped.append(slug)
            continue
        fp = raw_fingerprint(meta["apiId"])
        kb_path = os.path.join(APIS_DIR, f"{slug}.json")
        if not REFRESH and fp and old_state.get(slug) == fp and os.path.exists(kb_path):
            reused.append(slug)
        else:
            todo.append((slug, meta))

    if reused:
        log(f"增量：{len(reused)} 个接口无变更，复用上次结果")

    done = {}
    failed = []
    with ThreadPoolExecutor(max_workers=10) as ex:
        futures = {ex.submit(build_api, slug, meta): slug for slug, meta in todo}
        for fut in as_completed(futures):
            slug = futures[fut]
            try:
                done[slug] = fut.result()
            except Exception as e:
                log(f"❌ 抓取失败 {slug}: {e}")
                failed.append(slug)

    # 读旧 manifest，复用接口直接沿用其 md5（零磁盘读、零重算）
    old_manifest = {}
    manifest_path = os.path.join(SNAP_DIR, "manifest.json")
    if os.path.exists(manifest_path):
        try:
            old_manifest = json.load(open(manifest_path, encoding="utf-8")).get("apis", {})
        except Exception:
            old_manifest = {}

    index = {}
    manifest = {}
    new_state = {}

    # 新增/变更接口：写文件 + 算 md5
    for slug, api in done.items():
        meta = tree_flat[slug]
        out = os.path.join(APIS_DIR, f"{slug}.json")
        with open(out, "w", encoding="utf-8") as f:
            json.dump(api, f, ensure_ascii=False, indent=2)
        digest = hashlib.md5(json.dumps(api, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
        manifest[slug] = {"apiId": meta["apiId"], "title": api["title"],
                          "method": api["method"], "path": api["path"], "md5": digest}
        index[slug] = {"apiId": meta["apiId"], "title": api["title"],
                       "method": api["method"], "path": api["path"],
                       "operationId": meta["operationId"]}
        new_state[slug] = raw_fingerprint(meta["apiId"])

    # 复用接口：沿用旧 md5，只重建 index（内存操作）
    for slug in reused:
        meta = tree_flat[slug]
        manifest[slug] = old_manifest.get(slug, {"apiId": meta["apiId"], "title": meta["title"],
                                                 "method": meta["method"], "path": meta["path"], "md5": ""})
        index[slug] = {"apiId": meta["apiId"], "title": meta["title"],
                       "method": meta["method"], "path": meta["path"],
                       "operationId": meta["operationId"]}
        new_state[slug] = raw_fingerprint(meta["apiId"])

    with open(os.path.join(KB_DIR, "api-index.json"), "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2, sort_keys=True)
    with open(os.path.join(SNAP_DIR, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump({"fetchedAt": time.strftime("%Y-%m-%dT%H:%M:%S"), "apis": manifest},
                  f, ensure_ascii=False, indent=2, sort_keys=True)
    with open(state_path, "w", encoding="utf-8") as f:
        json.dump(new_state, f, ensure_ascii=False, indent=2, sort_keys=True)

    log(f"✅ 完成 {len(done) + len(reused)} 个（新增/变更 {len(todo)}，复用 {len(reused)}），"
        f"失败 {len(failed)} 个，跳过 {len(skipped)} 个")
    log(f"知识库输出：{APIS_DIR}")


if __name__ == "__main__":
    main()
