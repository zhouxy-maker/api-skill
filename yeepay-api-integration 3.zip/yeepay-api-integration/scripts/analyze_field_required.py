#!/usr/bin/env python3
"""
analyze_field_required.py — 字段必填性完整梳理（M/O/C + 条件必填条件）。

核心新增：识别「标注 required=O，但描述中含『xx 情况下必填/必传/需填写』或
『xx 时无需填写』等条件语义」的字段，将其升级为 C（条件必填）。

产出：
  1. references/rules/field-required.yaml —— 全量字段必填性清单（M/O/C + 条件）
  2. 修正 kb 中 O→C 字段的 required 值（写回 JSON，使 resolve_fields.py 正确纳入场景澄清）

用法：python3 scripts/analyze_field_required.py
"""
import glob
import json
import os
import re
import sys
import yaml
from collections import Counter

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_DIR = os.path.join(SKILL_DIR, "references", "kb")
RULES_DIR = os.path.join(SKILL_DIR, "references", "rules")

# ============================================================
# O→C 升级白名单（人工确认：required=O 但描述实为条件必填）
# key = "<uri>.<path>"，value = 条件必填的说明文本
# ============================================================
OC_UPGRADE = {
    "get__rest__v1.0__gpt__payer__query.id":
        "精确查询时必填；传 payersource 或 payerstatus 时为批量查询，无需填写",
    "get__yos__v1.0__gpt__file__download.requestId":
        "type 为 DECLARATION_FILE/OVERSEA_PAYMENT/WITHDRAW/VA_CERTIFICATE/COLLECTION_CERTIFICATE/"
        "COLLECTION_REFUND_CERTIFICATE/PAYOUT_CBPAYMENT_RECEIPT/PAYOUT_CBPAYMENT_REMIT_FORM 时必传",
    "post__rest__v1.0__gpt__account__balance__query.subMerchantId":
        "查询子商户余额时填写；查询自己余额无需填写",
    "post__rest__v1.0__gpt__declaration-detail__commit.tradePlatformName":
        "与 shopUrl（业务网址）至少填一个",
    "post__rest__v1.0__gpt__declaration-detail__commit.shopUrl":
        "与 tradePlatformName（平台名称）至少填一个",
    "post__rest__v1.0__gpt__payment__order.receiveCurrency":
        "payoutType=OVERSEA_PAYMENT/WITHDRAW 时填写（DOMESTIC_PAYMENT/DOMESTIC_PAYMENT_FX 无需）",
    "post__rest__v1.0__gpt__payment__order.pobo":
        "海外付款且需使用指定付款人名称时填写",
    "post__rest__v1.0__gpt__payment__order.payerId":
        "异名 POBO 时必填",
    "post__rest__v1.0__gpt__payment__order.shareholderRatio":
        "异名 POBO 场景下，付款人为企业且 SEPA/GBR LOCAL/AUS LOCAL 付时填写",
    "post__rest__v1.0__gpt__wallet__apply.credentialsNumber":
        "开户主体为企业法人或股东时必填",
}

# 条件语义关键词（用于 C 字段自动提取 condition_text）
REQ_PAT = re.compile(
    r"当(.+?)(?:时|的情况下|的场景下|模式下)[，,]?\s*(?:需|必须|为必填|必填|非空|填写|需要填写|必传)", re.S)
REQ_PAT2 = re.compile(r"(.+?)(?:模式下|场景下|时|情况下)[，,]?\s*(?:需|必须|需要)?\s*填写", re.S)
NEG_PAT = re.compile(
    r"(?:备注[：:]?)?(?:当)?(.+?)(?:时|模式下|情况下|场景下)[，,]?\s*(?:不需要填写|无需填写|不用填写|可不填写|不需要传|无需传)", re.S)
SRC_PAT = re.compile(r"(?:详见|见)[:：]?\s*[《「]?([^。；;，,\n]+)[》」]?")


def extract_condition(desc):
    if not desc:
        return None
    for m in REQ_PAT.finditer(desc):
        return "当" + m.group(1) + "时必填"
    for m in REQ_PAT2.finditer(desc):
        return m.group(1) + "时需填写"
    # 反向：默认必填，xx 时无需填写
    m = NEG_PAT.search(desc)
    if m:
        return "默认必填，" + m.group(1) + "时无需填写"
    return None


def extract_source(desc):
    if not desc:
        return None
    m = SRC_PAT.search(desc)
    return m.group(1).strip() if m else None


def to_when(cond_text, field_values):
    """复用 analyze_conditions 的简单单值 AND 结构化（复杂语义返回 None）。"""
    if not cond_text:
        return None
    body = re.sub(r"^当", "", cond_text)
    body = re.sub(r"(时必填|时需填写|时非空|时必传)$", "", body)
    if re.search(r"[/，,、]?\s*(或|非|不在|且|以及|、|至少|之一)", body):
        return None
    clauses = []
    for seg in re.split(r"[，,;；\n]+", body):
        seg = seg.strip()
        if not seg:
            continue
        m = re.match(r"^(\w+)\s*[=＝]\s*([A-Za-z0-9_\-]+)$", seg)
        if not m:
            return None
        field, val = m.group(1), m.group(2)
        if field not in field_values:
            return None
        clauses.append(f'{field}=="{val}"')
    return " && ".join(clauses) if clauses else None


def flatten(nodes, out=None):
    if out is None:
        out = []
    for n in nodes:
        out.append(n)
        if n.get("children"):
            flatten(n["children"], out)
    return out


def main():
    # 1) 扫描所有字段，应用 O→C 升级
    upgraded = []
    all_entries = []  # (uri, title, path, required_final, title_text, desc, enum, cond, src)
    for f in sorted(glob.glob(os.path.join(KB_DIR, "apis", "*.json"))):
        d = json.load(open(f, encoding="utf-8"))
        uri = d["uri"]
        fields = flatten(d.get("reqParams", []))
        field_names = {n.get("path", "").split(".")[-1] for n in fields}
        for n in fields:
            path = n.get("path", "")
            key = f"{uri}.{path}"
            req = n.get("required", "O")
            desc = (n.get("description") or "").strip()
            # O→C 升级
            if req == "O" and key in OC_UPGRADE:
                req = "C"
                upgraded.append(key)
                n["required"] = "C"
            cond = OC_UPGRADE.get(key) if key in OC_UPGRADE else extract_condition(desc)
            src = extract_source(desc)
            all_entries.append({
                "uri": uri, "title": d.get("title", ""), "path": path,
                "field_title": n.get("title", ""), "type": n.get("type", ""),
                "required": req, "desc": desc,
                "enum": [e["value"] for e in (n.get("enum") or [])] or None,
                "cond": cond, "src": src,
                "field_names": field_names,
            })
        # 写回 required 修正
        json.dump(d, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    # 2) 生成完整清单 field-required.yaml
    out = {"_meta": {
        "说明": "字段必填性完整清单（请求参数 reqParams）。required: M=必填 / C=条件必填 / O=非必填。"
                "condition_text 为 C 字段的触发条件；required_when 为可结构化表达式（空=需人工判断）。",
        "confidence": "confirmed=已人工确认 / inferred=AI 从描述提取 / unresolved=条件在外部文档",
        "生成": "python3 scripts/analyze_field_required.py",
        "O转C升级说明": "标注 required=O 但描述中含条件必填语义的字段已升级为 C，见 OC_UPGRADE 白名单。",
    }, "fields": {}}
    for e in sorted(all_entries, key=lambda x: (x["uri"], x["path"])):
        when = to_when(e["cond"], e["field_names"]) if e["cond"] else None
        conf = "confirmed" if (e["uri"] + "." + e["path"]) in OC_UPGRADE else (
            "inferred" if (e["required"] == "C" and e["cond"]) else None)
        if e["required"] == "C":
            conf = conf or ("unresolved" if not e["cond"] else "inferred")
        entry = {
            "required": e["required"],
            "title": e["field_title"],
            "type": e["type"],
        }
        if e["enum"]:
            entry["enum"] = e["enum"]
        if e["required"] == "C":
            entry["condition_text"] = e["cond"]
            entry["required_when"] = when
            entry["source_doc"] = e["src"]
            entry["confidence"] = conf
        entry["description"] = e["desc"]
        out["fields"][f"{e['uri']}.{e['path']}"] = entry

    with open(os.path.join(RULES_DIR, "field-required.yaml"), "w", encoding="utf-8") as fp:
        yaml.safe_dump(out, fp, allow_unicode=True, sort_keys=False, width=200)

    # 2.5) 同步生成 field-conditions.yaml（C 字段规则，resolve_fields.py 消费）
    cond_out = {"_meta": {
        "说明": "条件必填规则库（字段级 C）。required_when 为空表示条件无法自动结构化，需人工确认，勿臆造。",
        "confidence": "confirmed=已人工确认 / inferred=AI 从描述提取，待确认 / unresolved=条件在外部文档，待补齐",
        "生成": "python3 scripts/analyze_field_required.py",
    }, "fields": {}}
    for e in sorted(all_entries, key=lambda x: (x["uri"], x["path"])):
        if e["required"] != "C":
            continue
        key = f"{e['uri']}.{e['path']}"
        when = to_when(e["cond"], e["field_names"]) if e["cond"] else None
        conf = "confirmed" if key in OC_UPGRADE else ("inferred" if e["cond"] else "unresolved")
        cond_out["fields"][key] = {
            "api": e["uri"],
            "apiTitle": e["title"],
            "field": e["path"],
            "type": e["type"],
            "enum": e["enum"],
            "required_when": when,
            "condition_text": e["cond"],
            "source_doc": e["src"],
            "confidence": conf,
            "description": e["desc"],
        }
    with open(os.path.join(RULES_DIR, "field-conditions.yaml"), "w", encoding="utf-8") as fp:
        yaml.safe_dump(cond_out, fp, allow_unicode=True, sort_keys=False, width=200)

    # 3) 统计
    stat = Counter(e["required"] for e in all_entries)
    c_fields = [e for e in all_entries if e["required"] == "C"]
    with_when = sum(1 for e in c_fields if to_when(e["cond"], e["field_names"]))
    print(f"字段总数(reqParams): {len(all_entries)}")
    print(f"required 分布: {dict(stat)}")
    print(f"O→C 升级字段数: {len(upgraded)}")
    for u in sorted(upgraded):
        print(f"  ↑ {u}")
    print(f"C 字段总数: {len(c_fields)}")
    print(f"  可结构化 required_when: {with_when}")
    print(f"  已提取条件文本(condition_text): {sum(1 for e in c_fields if e['cond'])}")
    print(f"  引用外部文档(source_doc): {sum(1 for e in c_fields if e['src'])}")
    print(f"\n清单已写入 {os.path.join(RULES_DIR, 'field-required.yaml')}")


if __name__ == "__main__":
    main()
