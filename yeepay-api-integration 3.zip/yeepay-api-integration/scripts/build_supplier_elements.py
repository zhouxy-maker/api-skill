#!/usr/bin/env python3
"""
build_supplier_elements.py — 从本地 xlsx 解析「收款方报备要素说明」，切分为按国家查询的小文件。

源：收款方报备要素说明.xlsx（4 sheet：整体说明 / 收款方报备要素 / IDN-印尼省份城市清单 / 银行名称）
产物：references/external/supplier/ 下
  - meta.yaml           字段枚举 + 传值说明（通用）
  - index.yaml          bankCountry -> 文件/币种/清分/字段数（先查它定位）
  - {COUNTRY}.yaml      各国要素字段（2~7K，含格式校验/枚举/必填 M/O）
  - idn-provinces.yaml  印尼 34 省
  - idn-cities.yaml     印尼 520 市
  - bank-list.yaml      银行名称覆盖 36 国（完整清单走接口 supplier__banklist）

数据要点：
  - 「银行所在国家/地区」列有一个合并单元格：36 个欧洲国家共用同一套字段（EUR/LOCAL），
    归一为 EU_EUR_LOCAL 分组（含 countries 列表）。
  - 印尼 province/city 字段的枚举值与原「IDN-印尼省份城市清单」重复，这里去重为引用。

用法：
  python3 build_supplier_elements.py [xlsx路径]
"""
import os
import shutil
import sys

XLSX_DEFAULT = "/Users/c0259/Downloads/收款方报备要素说明.xlsx"
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(SKILL_DIR, "references", "external", "supplier")


def main():
    xlsx = sys.argv[1] if len(sys.argv) > 1 else XLSX_DEFAULT
    if not os.path.exists(xlsx):
        sys.exit(f"找不到源文件：{xlsx}")

    try:
        import openpyxl
        import yaml
    except ImportError as e:
        sys.exit(f"缺少依赖：{e}")

    wb = openpyxl.load_workbook(xlsx, data_only=True)

    # 1) 整体说明 -> field_enums + other_note
    ws0 = wb["整体说明"]
    field_enums = {}
    for r in range(2, ws0.max_row + 1):
        key = ws0.cell(r, 1).value
        val = ws0.cell(r, 2).value
        if key and str(key).strip():
            field_enums[str(key).strip()] = val if val is not None else ""
    other_note = (ws0.cell(1, 5).value or "").strip()

    # 2) 收款方报备要素 -> elements（按 bankCountry 分组）
    ws = wb["收款方报备要素"]
    groups = {}
    order = []
    for r in range(3, ws.max_row + 1):
        param = ws.cell(r, 8).value
        if param is None or str(param).strip() == "":
            continue
        bc_raw = (ws.cell(r, 4).value or "").strip()
        if "\n" in bc_raw:
            key = "EU_EUR_LOCAL"
            countries = [c.strip() for c in bc_raw.split("\n") if c.strip()]
        else:
            key = bc_raw
            countries = None
        if key not in groups:
            groups[key] = {"currency": "", "clearing": "", "fields": []}
            order.append(key)
            if countries:
                groups[key]["countries"] = countries
                groups[key]["note"] = "源文档合并单元格：以下 36 个欧洲国家/地区共用同一套字段要求（EUR/LOCAL 本地清分）"
        g = groups[key]
        cur = (ws.cell(r, 5).value or "").strip()
        clr = (ws.cell(r, 7).value or "").strip()
        if cur and not g["currency"]:
            g["currency"] = cur
        if clr and not g["clearing"]:
            g["clearing"] = clr
        g["fields"].append({
            "param": str(param).strip(),
            "title": (ws.cell(r, 9).value or "").strip(),
            "account_type": (ws.cell(r, 6).value or "").strip(),
            "required": (ws.cell(r, 10).value or "").strip(),
            "validators": ws.cell(r, 11).value if ws.cell(r, 11).value is not None else "",
            "scope": (ws.cell(r, 12).value or "").strip(),
            "remark": (ws.cell(r, 13).value or "").strip(),
        })

    # 3) IDN 省份城市
    ws2 = wb["IDN-印尼省份城市清单"]
    idn_provinces, idn_cities = [], []
    for r in range(2, ws2.max_row + 1):
        pc = ws2.cell(r, 1).value
        pn = ws2.cell(r, 2).value
        if pc is not None and str(pc).strip():
            idn_provinces.append({"province_code": str(int(pc)), "name": str(pn).strip()})
        cc = ws2.cell(r, 3).value
        cn = ws2.cell(r, 4).value
        if cc is not None and str(cc).strip():
            idn_cities.append({"province_code": str(int(cc)), "city": str(cn).strip()})

    # 4) 银行名称
    ws3 = wb["银行名称"]
    bank_countries = []
    for r in range(1, ws3.max_row + 1):
        v = ws3.cell(r, 1).value
        if v is None:
            continue
        s = str(v).strip()
        if s and s != "国家" and s not in bank_countries:
            bank_countries.append(s)
    bank_note = (ws3.cell(1, 4).value or "").strip()
    bank_total = ws3.max_row - 1

    # 切分输出
    if os.path.exists(OUT_DIR):
        shutil.rmtree(OUT_DIR)
    os.makedirs(OUT_DIR, exist_ok=True)

    def dump(obj, path):
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(obj, f, allow_unicode=True, sort_keys=False,
                           default_flow_style=False, width=10000)

    dump({"source": os.path.basename(xlsx), "field_enums": field_enums, "other_note": other_note},
         os.path.join(OUT_DIR, "meta.yaml"))

    index = {}
    for key in order:
        g = groups[key]
        for f in g.get("fields", []):
            if key == "ID" and f.get("param") == "province":
                f["scope"] = "印尼省份枚举，见 supplier/idn-provinces.yaml"
            if key == "ID" and f.get("param") == "city":
                f["scope"] = "印尼城市枚举，见 supplier/idn-cities.yaml"
        fname = f"supplier/{key}.yaml"
        dump(g, os.path.join(OUT_DIR, f"{key}.yaml"))
        entry = {"file": fname, "currency": g.get("currency", ""),
                 "clearing": g.get("clearing", ""), "fields": len(g.get("fields", []))}
        if "countries" in g:
            entry["countries"] = g["countries"]
        index[key] = entry

    dump({"idn_provinces": idn_provinces}, os.path.join(OUT_DIR, "idn-provinces.yaml"))
    dump({"idn_cities": idn_cities}, os.path.join(OUT_DIR, "idn-cities.yaml"))
    dump({"bank_list": {"note": bank_note, "countries": bank_countries,
                        "full_list": f"本清单共 {bank_total} 行银行名称，未展开；建议通过接口 supplier__banklist 实时查询"}},
         os.path.join(OUT_DIR, "bank-list.yaml"))
    dump({"note": "收款人报备要素按 bankCountry 切分；查询某国要素先查本索引定位文件，再读 supplier/{COUNTRY}.yaml",
          "groups": index}, os.path.join(OUT_DIR, "index.yaml"))

    print(f"已生成 {len(order)} 个国家分组到 {OUT_DIR}")


if __name__ == "__main__":
    main()
