# 接口状态流转原文（gpt 产品测试 case 汇总）

> 来源：飞书《gpt产品测试case汇总》 https://yeepay.feishu.cn/wiki/EJ9fwf7UAiDnSJkh641c93xUnRg
> 抓取时间：2026-11-06
> 结构化版见 `status-flow.yaml`（供按接口查询）；本文件为原文对照。

## 使用规则（务必遵守）

1. 用户对接某模块 API 时，**优先指导 success（正常）流程对接**。
2. 正常流程对接完成后，再依据本文档告知用户：「该接口还有以下几种状态，建议上线前也进行测试」。
3. 每个状态讲清三件事：**代表什么、后续怎么操作、是否需人工支持**。
4. 本文档不做真实状态模拟，仅作为「知识」告知。模拟这些状态需要人工支持，**如需模拟相关状态，请联系技术支持**。

---

# 海外付款

## 收款人报备

| 流转状态 | 状态枚举值 | 后续操作 |
|---|---|---|
| 补充材料 | WAIT_SUPPLEMENT_MATERIAL | 调用收款人补充材料接口 supplier__materials__submission |
| 驳回 | RISK_REBUT | 收款人更新：operate=UPDATE（supplier__request） |
| 拒绝 | FAILED | 收款人更新：operate=UPDATE（supplier__request） |
| 成功 | / | / |

## 付款人报备

| 流转状态 | 状态枚举值 | 后续操作 |
|---|---|---|
| 待处理 | INIT | 使用原 requestId 进行资料更新（id = 付款人请求 response 中返回的 id） |
| 待审核 | WAIT_CHECK | / |
| 审核拒绝 | CHECK_REFUSE | 使用原 requestId 进行资料更新（id = 付款人请求 response 中返回的 id） |
| 可用 | AVAILABLE | / |
| 禁用 | DISABLE | / |

## 付款流程

同步接口已 SUCCESS，受理成功。

| 流转状态 | 状态枚举值 | 后续操作 |
|---|---|---|
| 异步直接失败 | 通知：FAIL | （原文未注明） |
| 退票（先成功后失败） | 通知：SUCCESS -> RETURN | （原文未注明） |
| 成功 | 通知：SUCCESS | / |

---

# 结汇

## 机构结汇（海分标准版）

同步接口已 SUCCESS，受理成功。

| 流转状态 | 状态枚举值 | 后续操作 |
|---|---|---|
| 同步失败 | /（资金未操作） | 修正参数后，重新提交汇款请求 |
| 异步失败 | 回调 type=TRANSFER_COMPLETE_RESULT, status=FAIL（资金退回到 CNH） | ① 重新发起明细请求；② 发起新的汇款请求 |
| 冲退 | 回调 type=TRANSFER_COMPLETE_RESULT, status=SUCCESS -> FAIL（资金退回到 CNY REFUND） | 仅需以下参数发起全新汇款请求：payoutCurrency=REFUND；originRequestId=上一笔失败汇款的 requestId；requestId=新生成的 requestId |
| 成功 | （空） | （空） |

服务贸易/货物贸易（非薪酬赡家）和薪酬、赡家场景，建议分开测试。

| 场景 | useCode |
|---|---|
| 服务贸易/货物贸易 | GOODSTRADE / GENERALTRADE / ADVERTISEMENT / TRANSPORT2 / TRANSPORT3 / TRANSPORT5 / TRANSPORT7 / PLANETICKET / HOTELACCOMMODATION / TRAVEL / TRAVEL2 / SOFTWARE |
| 薪酬/赡家 | SALARY / FAMILYALLOWANCE |
