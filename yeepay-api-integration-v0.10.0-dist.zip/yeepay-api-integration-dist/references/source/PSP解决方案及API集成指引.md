# 【PSP】解决方案及API集成指引

# 一、产品能力概述

YeePay（易宝支付）作为中国持牌专业第三方支付服务商，提供一站式全球支付解决方案，帮助您快速构建「充值 → 换汇 → 付款」的完整支付能力。

- **结汇：**在严格遵守国家外汇管理政策的前提下，在货物贸易、服务贸易、薪酬赡家场景下，为您及您的合作方享受**极速到账、稳定清算、资金安全**的核心服务体验。

- **汇兑：**提供60\+币种对换汇服务，支持实时、额度、挂单换汇等，多渠道路由，为您提供极具竞争力的汇率，遵守SAFE/PBOC法规，合规、安全地助您换汇。

- **全球付款：**覆盖130\+国家，提供低成本、高效的全球支付网络，支持Swift与本地支付网络，最快T0到账，并提供POBO能力。



# 二、适用客群

持牌支付机构（无给子商户开VA进行收款需求）



# 三、一站式解决方案

PSP自身做资金归集，将资金打款给YeePay香港客户资金账户，资金入账后，可进行换汇、结汇和外币付款。



# 四、产品及接口介绍

## 一\. 大账充值

#### 1\. 产品介绍

1. **大账充值：**PSP/平台商客户直接打款到易宝香港 GPT 大账户完成充值，易宝通过特定附言为您的资金账户进行入账。

2. **限制：**只支持同名充值。

3. **支持充值币种：**USD、 CNH、HKD、AUD、CAD、EUR、GBP、JPY、SGD

#### 2\. API 集成指引

商户入网后，会提供给您充值帐户及附言内容，直接进行充值即可。接入「[来账商户通知](https://open.gptransfer.hk/docs/solutions/apidoc/693becdc7d2c7d0001a23a09/693bed203b0a750001efa619)」可自行接收充值状态。

|指引|接口|接口说明|集成要求|
|---|---|---|---|
|大账充值|[来账商户通知](https://open.gptransfer.hk/docs/solutions/apidoc/693becdc7d2c7d0001a23a09/693bed203b0a750001efa619)|接收到一笔来账时，会推送来账通知|O|



## 二\. 换汇

#### 1\. 换汇产品

默认换汇产品为实时换汇，可通过接口进行锁汇。

#### 2\. API 集成指引

|**指引**|**接口**|接口说明|**集成要求**|
|---|---|---|---|
|[换汇指引](https://open.gptransfer.hk/docs/open/apiguide/69045d74be3daf00010decce/6904606bbe3daf00010decef)|[换汇\-询价](https://open.gptransfer.hk/docs/solutions/apidoc/apis_5/get__rest__v1.0__gpt__exchange__inquiry)|用于查询可交易的汇率，也可进行锁汇|O|
||[换汇\-请求](https://open.gptransfer.hk/docs/solutions/apidoc/apis_5/post__rest__v1.0__gpt__exchange__order)|发起换汇请求|M|
||[换汇\-查询](https://open.gptransfer.hk/docs/solutions/apidoc/apis_5/get__rest__v1.0__gpt__exchange__query)|换汇交易查询|O|
|**锁汇说明：**<br>将换汇\-询价中获取的token，上传至换汇\-请求中，实现锁汇。默认锁汇时间为120s，可自行通过接口选择锁汇时间。||||



## 三\. 付款至中国大陆（结汇）

#### 1\. 产品介绍：

Yeepay可以为您和您的商户提供更高效、便利的结汇服务，具体请参考以下对客指引链接：

[【对客指引】结汇\-付款到中国大陆 ](https://yeepay.feishu.cn/wiki/Tu9qwMU0Ii7KpTkVlxrc06runic?from=from_copylink)

#### 2\. API 集成指引

1. **结汇**

|**指引**|**接口**|接口说明|**集成要求**|
|---|---|---|---|
|[人民币结汇机构版](https://open.gptransfer.hk/docs/open/apiguide/69045fb5be3daf00010decea/6a2a7d311ccd8c0001d692dc)<br>（单笔接口）<br>|[明细上传\-单笔（参数列表模式）](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__declaration-detail__commit)|提供订单信息、申报主体信息、贸易/薪酬信息等进行明细上传。一次性最多可上传500笔明细。|M|
||[明细上传\-查询](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/get__rest__v1.0__gpt__upload__query)|查询明细上传状态|O|
||[付款\-请求（境内付款\-单笔）](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__fx-settlement__commit)|发起结汇交易（单笔交易）|M|
||[付款\-查询（境内付款\-单笔）](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__fx-settlement__query)|查询交易信息|O|
|**调用顺序：**请严格遵循**优先上传明细，再进行付款请求**的顺序。<br>**勾稽：**进行付款请求时，需勾稽相关明细。<br>（方法：通过字段进行勾稽，付款\-请求**`requestId`**=明细上传** ****`businessRequestId`****）**||||

2. **企业报备**（对公申报时，需在结汇申报前，进行企业报备）

|**指引**|**接口**|接口说明|**集成要求**|
|---|---|---|---|
|企业报备|[企业报备\-请求](https://open.gptransfer.hk/docs/solutions/apidoc/apis_8/post__rest__v1.0__gpt__register__request)|上传境内卖方企业信息，如组织机构代码、联系电话等信息进行报备。|CM|
||[企业报备\-查询](https://open.gptransfer.hk/docs/solutions/apidoc/apis_8/get__rest__v1.0__gpt__register__query)|查询企业报备状态|O|

3. **付款人定制**（结汇异名POBO时，需在结汇申报前，进行付款人定制）

|**指引**|**接口**|接口说明|**集成要求**|
|---|---|---|---|
|付款人定制|[钱包账户申请](https://open.gptransfer.hk/docs/solutions/apidoc/apis_6/post__rest__v1.0__gpt__wallet__apply)|使用要POBO的付款人信息，进行轻量化KYC|CM|
||[钱包账户查询](https://open.gptransfer.hk/docs/solutions/apidoc/apis_6/get__rest__v1.0__gpt__wallet__query)|查询审核状态|O|
||[钱包账户注销](https://open.gptransfer.hk/docs/solutions/apidoc/apis_6/post__rest__v1.0__gpt__wallet__close)|注销该账户信息|O|



## 四\. 外币付款

#### 1\. 产品介绍

1. 商户发起付款至**非CNY**收款账户（含银行账户和钱包账户）的外币付款产品。

2. 付款请求前，需要进行收款人报备。

3. 外币付款支持**同币种下发、错币种下发**。错币种下发时，可以通过【付款\-锁汇】接口进行汇率锁定（1min）。

4. POBO能力：**仅支持英文POBO**

    - 走swift —— 必须POBO；

    - 走Local —— 取决于地区是否支持/强制要求POBO（[全球付款能力表](https://yeepay.feishu.cn/wiki/SnRBwEN7Yi8vzxk7xzYcG3U5nrc?from=from_copylink)）

#### 2\. 全球付款支持能力

[付款能力 对客05\.28](https://yeepay.feishu.cn/wiki/SnRBwEN7Yi8vzxk7xzYcG3U5nrc?from=from_copylink)

#### 3\. API 集成指引

|**指引**|**接口**|接口说明|**集成要求**|
|---|---|---|---|
|[收款人管理](https://open.gptransfer.hk/docs/open/apiguide/69045d65be3daf00010deccc/69045f81be3daf00010dece7)|[收款人报备](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__supplier__request)|上传收款人信息进行报备|M|
||[收款人查询](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/get__rest__v1.0__gpt__supplier__query)|\-|O|
||[收款人删除](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__supplier__delete)|\-|O|
||[收款人报备补充材料](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__supplier__materials__submission)|收款人报备返回状态为“待补充资料”时进行补充|M|
|[外币付款](https://open.gptransfer.hk/docs/open/apiguide/69045d65be3daf00010deccc/69045facbe3daf00010dece9)|[付款\-锁汇](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__payment__inquiry)|使用错币种付款时，可通过该接口进行锁汇、查询手续费等。|O|
||[付款\-请求](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__payment__order)|发起付款交易请求|M|
||[付款\-查询](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/get__rest__v1.0__gpt__payment__query)|查询交易信息、付款状态等|O|
|[付款人管理](https://open.gptransfer.hk/docs/open/apiguide/69045d65be3daf00010deccc/6a2a68db1ccd8c0001d692db/6a2a68eb0253180001c88c56)<br>（实现付款人名称定制，必接**）**|[付款人报备](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__payer__request)|提交贸易作证/关系证明材料等，进行付款人报备|M|
||[付款人查询](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/get__rest__v1.0__gpt__payer__query)|查询付款人信息、报备状态等|O|
||[付款人删除](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__payer__delete)|\-|O|



## 五\. 其他接口

|**指引**|**接口**|接口说明|**集成要求**|
|---|---|---|---|
|用于上传文件|[文件上传](https://open.gptransfer.hk/docs/apis/gpt-all-product/post__yos__v1.0__gpt__file__upload)|（API中涉及文件的字段，均需要先调取“文件\-上传”接口进行上传后，获取路径）|M|
|[对账单获取指引](https://open.gptransfer.hk/docs/open/apiguide/69045d6ebe3daf00010deccd/69046083be3daf00010decf1)|[文件下载（账单）](https://open.gptransfer.hk/docs/apis/gpt-all-product/get__yos__v1.0__gpt__file__download)|下载对账单等|O|
|[余额查询](https://open.gptransfer.hk/docs/open/apiguide/69045d6ebe3daf00010deccd/69045fd0be3daf00010decec)|[余额查询（按币种）](https://open.gptransfer.hk/docs/solutions/apidoc/apis_10/get__rest__v1.0__gpt__account__query)|查询账户某币种余额|M|
||[余额查询（按商编）](https://open.gptransfer.hk/docs/solutions/apidoc/apis_10/post__rest__v1.0__gpt__account__balance__query)|查询某商户账户余额|O|



