# 字段解答 + 场景澄清（核心能力）

解决「这个字段必填吗 / 传什么 / 什么格式 / 枚举有哪些」类问题。

## 读取路径（两段式，先索引后精读）

1. **先查 `references/kb/api-index.json`**（6.8K，26 个接口的 uri/title/path/method/operationId）——用户没说接口名时，先用它定位 uri。
2. **再精读 `references/kb/api-packs/{uri}.json`**（接口问答包，平均 12K）——字段定义 + 必填规则 + errcodes + spis 都已合并进这一份，无需再查其他清单。

## 字段必填性三态

- `M` = 必填；`O` = 选填；`C` = 条件必填。
- C 字段的判定依据已合并进 api-pack 字段的 `required_when` / `condition_text` / `confidence`：
  - `required_when` 有值 → 可自动判定（形如 `clearingType=="SWIFT"`）。
  - 仅 `condition_text` 有值 → 把条件原文展示给用户确认。
  - 两者都空（`confidence=unresolved`）→ 条件在外部文档，标「待确认」，附 `source_doc`，**不得臆造**。

## 场景判定

用 `references/rules/scenario-tree.yaml` **逐题引导**（一次一题），产出场景标签（clearingType / bankCountry / paymentType / accountType 等）。

## 求解

```
python3 scripts/resolve_fields.py --api <uri> --scene clearingType=LOCAL,bankCountry=BR
```

输出「可直接照着填的清单」（必填/选填/条件待确认），不是散文。

## 收款人报备（supplier_request）外部参考

字段之外的枚举、国家/地区、要素规则读 `references/external/`：
- 收款方要素（按国家）：先查 `external/supplier/supplier-index.yaml`（`groups` 索引 + `field_enums` 枚举 + `bank_list` 银行清单 + `idn_provinces`/`idn_cities` 印尼省市）定位 → 再读 `external/supplier/{COUNTRY}.yaml`（每国 2~7K，含格式校验 validators/枚举/必填 M/O）。完整银行清单走接口 `supplier__banklist`。
- `country-list.yaml` — 255 国家/地区（ISO 3166-1，alpha2/alpha3/numeric/简称/全称）。
- `business-type-enums.yaml` — 业务类型枚举（非结汇 19 + 二级 4 + 结汇 14）。
- `bank-exempt-list.yaml` — 143 家免填省市分支行银行。

⚠️ external/ 是本地 xlsx 快照，与官方接口/飞书文档冲突时以官方为准。

## 铁律

- 若求解结果有「条件待确认」字段，先与用户确认条件，再给最终清单。
- 宁可标注「待确认」，不可编造字段规则。
