# 代码生成

生成 JAVA / PYTHON（优先）示例代码，也支持 C# / PHP / GO。**生成前先澄清场景条件**（见 SKILL.md 交互规范）。

## 数据源（重要变化）

- 字段 + 必填规则：`kb/api-packs/{uri}.json`（resolve 内部读）。
- **代码模板：`scripts/code_templates.py`**（5 语言 × 3 调用模式，源自飞书 wiki《测试例子》）。
- ⚠️ 开放平台爬取到的旧示例代码（sampleCodes，6 语言）**已全部删除，不可再引用**——那些代码已无人维护。

## 三种调用模式（由 method + contentType 决定）

| 模式 | method + contentType | 装配方式 | 覆盖接口 |
|---|---|---|---|
| `get_form` | GET + x-www-form-urlencoded | addParameter / get | 10 个 |
| `post_json` | POST + application/json | setContent(jsonBody) / post_json | 14 个 |
| `post_form` | POST + x-www-form-urlencoded | addParameter / post | 1 个（supplier/delete） |
| `multipart` | POST + multipart/form-data | **官方新示例未覆盖，需人工** | 1 个（file/upload） |

`gen_code.py` 会自动读取 api-pack 的 `contentType` 选模板，无需手动指定。

## 流程（先确认条件，再生成代码）

**只确认「影响字段对接的关键业务条件」，不逐项确认每个字段填什么值。**

1. 用 `references/rules/scenario-tree.yaml` 确认场景标签（逐题问清关键分支）。
2. **提炼关键业务条件**（生成前必做）：
   ```
   python3 scripts/gen_code.py --api <uri> --confirm
   ```
   输出该接口下影响「需要对接哪些字段」的关键条件（如付款-请求里的「付款类型」「清分类型」「是否异名 POBO」「用途编码=服贸/货贸/薪酬赡家」），与客户确认这些条件即可。
3. **确认条件后直接生成**（字段以符合要求的示例值填充，特殊字段末尾标注）：
   ```
   python3 scripts/gen_code.py --api <uri> --scene "payoutType=DOMESTIC_PAYMENT,clearingType=LOCAL,useCode=GOODSTRADE"
   ```
   默认输出 **JSON**；客户未指定语言时优先 JSON，再询问是否要写成某种语言。
4. **客户要某种语言时**：
   ```
   python3 scripts/gen_code.py --api <uri> --scene "..." --lang java|python|csharp|php|go|all
   ```

## 字段填充规则（示例值 + 标注，不用占位符堆满）

- **字段内容统一用符合字段要求的示例值填充**：枚举取第一项、有默认值用默认值、金额 `100.00`、币种 `USD`、邮箱 `example@example.com`、电话 `13800138000`、日期 `1990-01-01` 等。
- **敏感值 / 运行时值 / 外部获取值仍用占位符**：`<YOUR_APP_KEY>`、`<YOUR_PRIVATE_KEY>`、`<商户请求号，保持唯一>`、`<商户编号>`、`<询价/锁汇返回的token>`、`<文件上传接口返回的路径>`。
- **末尾输出「字段说明」标注**：需按枚举填写的（列出可选值）、需按模板上传的（文件路径字段）、条件必填/条件填写的（附触发条件）、条件待人工确认的，逐条标注。

## 铁律

- **先确认影响字段的条件，再生成**：不要生成满屏 `if` 判断、塞满待判断规则的代码；也不要逐项追问每个字段填什么值。
- 以 `code_templates.py` 模板为基座，只做字段装配，不重写签名逻辑（签名由官方 SDK 自动完成）。
- 敏感值一律占位符，不得写死真实密钥。
- multipart（file/upload）无官方新模板：如实告知「官方新示例未覆盖，需按 YOP SDK 文件上传能力人工编写」，不编造调用方式。
- PHP 的 DTO/模型类名由 operationId 推导，仅作参考，**以商户侧生成的 SDK 实际类名为准**（例如官方示例的请求体 DTO 是 `SupplierReqDTO` 而非 `SupplierRequestDTO`）。
- **默认 JSON，再问语言**：客户没说语言，先给 JSON，再问要不要 Java/C#/Python/PHP/Go。
