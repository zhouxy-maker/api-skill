# 收付款能力问答

用户问「能收/能付哪些国家、币种」「VA 开户银行」「是否支持 POBO」「到账时效」「是否支持附言」时：

## 第一步：给权威链接

飞书能力表是动态事实源，先返回链接：
- 中文：VA 收款能力 https://yeepay.feishu.cn/wiki/KIPDwdoFkix3WxkBG1FcHrrhnZe ；付款能力 https://yeepay.feishu.cn/wiki/SnRBwEN7Yi8vzxk7xzYcG3U5nrc
- 英文：收付款能力 https://yeepay.feishu.cn/wiki/WBR7w7vZtiP2AUkgPT6ciVsTnyd

## 第二步：具体问题查表回答（快照，附链接）

- VA 收款 → `references/capabilities/va-capability.yaml`（开户地区/币种/开户银行/账户用途/开户时效/入账时效/开户主体限制/是否同名/收款方式/限额）。
- 付款 → `references/capabilities/payout-capability.yaml`（国家/币种/打款方式/账户类型/交易类型/POBO/附言）。
- ⚠️ 两文件为快照，回答时附飞书链接（链接即最新表），不逐条复制过期数据。

## 提问示例（缺关键维度时一次一问引导）

- VA 收款：「收哪个国家/地区的款？币种？平台收款（电商/独立站）还是贸易收款？B 端还是 C 端来款？」
- 付款：「付款到哪个国家？币种？SWIFT 还是 LOCAL？是否 POBO？是否附言？」
- 判定示例：「香港 DBS 的 VA 能否收电商平台款？」→ 查 va-capability.yaml：HK DBS 支持平台收款 → 答「支持」+ 附链接。
