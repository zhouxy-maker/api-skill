#!/usr/bin/env python3
"""
resolve_fields.py — 场景标签 → 必填字段求解器。

输入：接口 uri + 场景标签（scene_tags，形如 clearingType=LOCAL,bankCountry=BR）
输出：该接口的必填 / 选填 / 条件待确认字段清单。

数据源：kb/api-packs/{uri}.json（接口问答包，字段已带 required 与条件规则）。

判定逻辑：
  - required == M -> 必填
  - required == O -> 选填
  - required == C -> 看字段的 required_when：
      * 有 required_when 且场景满足 -> 必填
      * 有 required_when 且场景不满足 -> 选填（本场景不触发）
      * 无 required_when（unresolved）-> 归入「条件待确认」，附 condition_text / source_doc

用法：
  python3 resolve_fields.py --api post__rest__v1.0__gpt__supplier__request \
      --scene clearingType=LOCAL,bankCountry=BR,paymentType=PIX
"""
import argparse
import json
import os
import re

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACK_DIR = os.path.join(SKILL_DIR, "references", "kb", "api-packs")


def eval_when(when, scene):
    """安全求值 required_when 表达式（仅支持 field=="VALUE" 以 && 连接）。"""
    if not when:
        return False
    for clause in when.split("&&"):
        m = re.match(r'^\s*(\w+)\s*==\s*"([^"]+)"\s*$', clause)
        if not m:
            return False
        if scene.get(m.group(1)) != m.group(2):
            return False
    return True


def resolve(uri, scene):
    pack_path = os.path.join(PACK_DIR, f"{uri}.json")
    if not os.path.exists(pack_path):
        return {"error": f"接口 {uri} 不在知识库中（请由维护方同步数据）"}

    pack = json.load(open(pack_path, encoding="utf-8"))

    result = {"api": uri, "title": pack.get("title"), "method": pack.get("method"),
              "path": pack.get("path"), "scene": scene,
              "required": [], "optional": [], "unresolved": []}

    for n in pack.get("reqParams", []):
        field = {
            "name": n.get("name", ""),
            "title": n.get("title", ""),
            "type": n.get("type", ""),
            "format": n.get("format", ""),
            "maxLength": n.get("maxLength", ""),
            "example": n.get("example", ""),
            "defVal": n.get("defVal", ""),
            "enum": n.get("enum"),
            "description": n.get("description", ""),
            "required": n.get("required", "O"),
            "condition_text": n.get("condition_text", ""),
            "required_when": n.get("required_when", ""),
            "source_doc": n.get("source_doc", ""),
            "confidence": n.get("confidence", ""),
        }
        req = n.get("required", "O")
        if req == "M":
            result["required"].append(field)
        elif req == "O":
            result["optional"].append(field)
        else:  # C
            when = n.get("required_when")
            if when and eval_when(when, scene):
                result["required"].append(field)
            elif when:
                result["optional"].append(field)
            elif n.get("name") in scene:
                # 客户已确认该条件字段的取值 -> 视为本场景必填（直接落值）
                result["required"].append(field)
            else:
                result["unresolved"].append(field)
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", required=True)
    ap.add_argument("--scene", default="", help="场景标签，形如 clearingType=LOCAL,bankCountry=BR,paymentType=PIX")
    args = ap.parse_args()
    scene = {}
    if args.scene:
        for kv in args.scene.split(","):
            if "=" in kv:
                k, v = kv.split("=", 1)
                scene[k.strip()] = v.strip()
    out = resolve(args.api, scene)
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
