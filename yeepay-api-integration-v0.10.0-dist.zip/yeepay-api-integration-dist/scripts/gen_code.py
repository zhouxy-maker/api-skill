#!/usr/bin/env python3
"""
gen_code.py — 按调用模式 + 字段装配，生成示例代码 / JSON 请求体。

与旧版不同：旧版读取开放平台爬取的 sampleCodes（已无人维护，全部删除）。
新版依据飞书 wiki《测试例子》沉淀的模板（scripts/code_templates.py），
按「method + contentType」选择调用装配方式，再把字段填进请求。

生成前只确认「影响字段必填性的关键业务条件」（不逐项确认字段值）：
  --confirm 输出该接口下影响字段对接的关键条件（如付款类型 / 服贸货贸 vs 薪酬赡家 / 清分类型），
  客户确认条件后用 --scene 传入，即可生成代码。
字段内容统一以「符合字段要求的示例值」填充（敏感值/运行时值仍用占位符），
需按表填写 / 按枚举填写 / 需特殊注意的字段，在末尾「字段说明」中标注。

调用模式（mode_of）：
  get_form    GET  + application/x-www-form-urlencoded -> addParameter / get
  post_json   POST + application/json                  -> setContent(jsonBody) / post_json
  post_form   POST + application/x-www-form-urlencoded -> addParameter / post
  multipart   POST + multipart/form-data               -> 官方新文档未覆盖，本脚本提示人工处理

数据源：
  kb/api-packs/{uri}.json  元信息 + contentType + 字段 + 必填规则（resolve 内部读）

字段值来源（优先级）：
  1. --values  客户确认的字段值（可选，一般不需要，默认示例值即可）
  2. --scene   客户确认的条件（如 payoutType=DOMESTIC_PAYMENT），命中字段则直接落值
  3. 示例值    符合字段格式要求的示例值（枚举取第一项 / 默认值 / 官方示例 / 语义示例）

用法：
  # 第一步：提炼并确认「影响字段的关键业务条件」
  python3 gen_code.py --api post__rest__v1.0__gpt__payment__order --confirm

  # 第二步：确认条件后生成 JSON（默认，未指定语言时优先 JSON）
  python3 gen_code.py --api post__rest__v1.0__gpt__payment__order \
      --scene "payoutType=DOMESTIC_PAYMENT,clearingType=LOCAL,useCode=GOODSTRADE"

  # 第三步：客户需要某种语言时，指定 --lang 生成
  python3 gen_code.py --api post__rest__v1.0__gpt__payment__order \
      --scene "payoutType=DOMESTIC_PAYMENT" --lang java
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from resolve_fields import resolve  # noqa: E402
from code_templates import TEMPLATES, LANG_LABEL, mode_of  # noqa: E402

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACK_DIR = os.path.join(SKILL_DIR, "references", "kb", "api-packs")

LANGS = ["java", "csharp", "python", "php", "go"]


def parse_kv(s):
    """解析 "k=v,k2=v2" 为 dict。"""
    d = {}
    if not s:
        return d
    for kv in s.split(","):
        if "=" in kv:
            k, v = kv.split("=", 1)
            d[k.strip()] = v.strip()
    return d


def example_value(field):
    """符合字段格式要求的示例值；敏感值/运行时值/外部获取值用占位符。"""
    name = field.get("name", "")
    # 1) 枚举 -> 第一个值
    if field.get("enum"):
        return field["enum"][0]["value"]
    # 2) 默认值
    dv = field.get("defVal")
    if dv not in (None, "", "-"):
        return dv
    n = name.lower()
    # 3) 敏感 / 运行时 / 外部获取值 -> 占位符
    if "requestid" in n:
        return "<商户请求号，保持唯一>"
    if "appkey" in n or "privatekey" in n or "private_key" in n:
        return "<YOUR_APP_KEY>"
    if "merchantid" in n or "submerchant" in n or "商编" in name or "商户编号" in name:
        return "<商户编号>"
    if "token" in n:
        return "<询价/锁汇返回的token>"
    if "notifyurl" in n:
        return "https://your-domain.com/notify"
    if "path" in n or "文件" in name:
        return "<文件上传接口返回的路径>"
    # 4) 个人信息 / 业务语义字段 -> 脱敏示例值（跳过官方 example，避免带入真实样例）
    if "email" in n or "邮箱" in name:
        return "example@example.com"
    if "phone" in n or "mobile" in n or "电话" in name or "手机" in name:
        return "13800138000"
    if "date" in n or "birth" in n or "日期" in name or "时间" in name:
        return "1990-01-01"
    if "name" in n or "名称" in name:
        return "示例名称"
    if ("account" in n and "number" in n) or "账号" in name or "卡号" in name:
        return "6222000000000000"
    if "amount" in n or "金额" in name:
        return "100.00"
    if "currency" in n or "币种" in name:
        return "USD"
    if "ratio" in n or "比例" in name:
        return "20.00"
    if "country" in n or "国家" in name:
        return "CN"
    if "bank" in n and "code" in n:
        return "<银行编码>"
    if "id" in n or "编号" in name:
        return "<对应ID>"
    if "code" in n or "码" in name:
        return "<CODE>"
    if "url" in n:
        return "https://your-domain.com/path"
    # 5) 官方示例值兜底（非个人信息字段）
    ex = field.get("example")
    if ex not in (None, "", "-"):
        return ex
    return "<VALUE>"


def field_value(field, values, scene):
    """字段值：客户确认值 > 场景枚举匹配 > 场景直接值 > 示例值。"""
    name = field.get("name", "")
    v = values.get(name)
    if v not in (None, ""):
        return v
    if field.get("enum"):
        for e in field["enum"]:
            if scene.get(name) == e.get("value"):
                return e["value"]
    sv = scene.get(name)
    if sv not in (None, ""):
        return sv
    return example_value(field)


def field_note(field):
    """字段的标注说明（需按枚举填写 / 按模板填写 / 条件必填 / 默认值等）。"""
    notes = []
    enum = field.get("enum")
    if enum:
        labels = "/".join(e.get("label", e["value"]) for e in enum)
        notes.append(f"枚举：{labels}")
    dv = field.get("defVal")
    if dv not in (None, "", "-"):
        notes.append(f"默认值：{dv}")
    desc = re.sub(r"\s+", " ", field.get("description", "") or "").strip()
    if "模板" in desc or "文件模版" in desc:
        notes.append("需先通过文件上传接口上传，将返回路径填入本字段（模板见 API 文档）")
    req = field.get("required", "O")
    ct = field.get("condition_text") or field.get("required_when")
    if req == "C":
        if ct:
            notes.append(f"条件必填：{ct}")
        else:
            notes.append("条件必填（触发条件待人工确认）")
    elif ct:
        # O 字段带条件语义（如「XX 时填写」）
        notes.append(f"条件填写：{ct}")
    return notes


def camel(name):
    """字段名 -> setter 后缀：requestId -> RequestId, bankCode -> BankCode"""
    return name[:1].upper() + name[1:]


def _esc_quoted(s):
    """转义双引号字符串字面量内的反斜杠与双引号（Java/C#/PHP/Go 用）。"""
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _json_of(fields, values, scene):
    """字段列表 -> 紧凑 JSON 字符串。"""
    obj = {f["name"]: field_value(f, values, scene) for f in fields}
    return json.dumps(obj, ensure_ascii=False)


def build_body(lang, mode, required, optional, values, scene):
    """按语言 + 模式生成 @BODY@（字段装配片段）。required 含 M + 条件必填字段。"""
    lines = []

    def val(f):
        return field_value(f, values, scene)

    if lang == "java":
        if mode == "post_json":
            body = _esc_quoted(_json_of(required, values, scene))
            lines.append(f'        String jsonContent = "{body}";')
            lines.append("        request.setContent(jsonContent);")
        else:
            for f in required:
                lines.append(f'        request.addParameter("{f["name"]}", "{_esc_quoted(val(f))}");')
            for f in optional:
                lines.append(f'        // request.addParameter("{f["name"]}", "{_esc_quoted(val(f))}");  // 选填')

    elif lang == "csharp":
        if mode == "post_json":
            body = _esc_quoted(_json_of(required, values, scene))
            lines.append(f'            string jsonBody = "{body}";')
            lines.append("            request.setContent(jsonBody);")
        else:
            for f in required:
                lines.append(f'            request.addParam("{f["name"]}", "{_esc_quoted(val(f))}");')
            for f in optional:
                lines.append(f'            // request.addParam("{f["name"]}", "{_esc_quoted(val(f))}");  // 选填')

    elif lang == "python":
        for f in required:
            lines.append(f'            {f["name"]!r}: {val(f)!r},')
        for f in optional:
            lines.append(f'            # {f["name"]!r}: {val(f)!r},  # 选填')

    elif lang == "php":
        setter_target = "body" if mode == "post_json" else "request"
        for f in required:
            lines.append(f'${setter_target}->set{camel(f["name"])}("{_esc_quoted(val(f))}");')
        for f in optional:
            lines.append(f'// ${setter_target}->set{camel(f["name"])}("{_esc_quoted(val(f))}");  // 选填')

    elif lang == "go":
        if mode == "post_json":
            for f in required:
                lines.append(f'        "{f["name"]}": "{_esc_quoted(val(f))}",')
            for f in optional:
                lines.append(f'        // "{f["name"]}": "{_esc_quoted(val(f))}",  // 选填')
        else:
            for f in required:
                lines.append(f'    yopRequest.AddParam("{f["name"]}", "{_esc_quoted(val(f))}")')
            for f in optional:
                lines.append(f'    // yopRequest.AddParam("{f["name"]}", "{_esc_quoted(val(f))}")  // 选填')

    return "\n".join(lines)


def php_names(operation_id, path):
    """由 operationId 推导 PHP 的 client 方法名 / Request 模型 / DTO 模型。

    operationId 形如 gpt-all-product_gpt_supplierRequest，
    取最后一段 `_gpt_` 之后 -> supplierRequest（client 方法），
    首字母大写 + Request -> SupplierRequestRequest，+ DTO -> SupplierRequestDTO。
    DTO 实际类名以 SDK 生成为准（例如官方示例为 SupplierReqDTO）。
    """
    op = ""
    if operation_id:
        parts = operation_id.split("_gpt_")
        if len(parts) > 1:
            op = parts[-1]
    if not op:
        op = re.sub(r"[^A-Za-z0-9]", "", path.strip("/").split("/")[-1])
    model = (op[:1].upper() + op[1:]) + "Request"
    dto = (op[:1].upper() + op[1:]) + "DTO"
    return op, model, dto


def render(lang, mode, meta, required, optional, values, scene):
    """填充模板，返回完整代码字符串。"""
    tpl = TEMPLATES[lang][mode]
    body = build_body(lang, mode, required, optional, values, scene)
    replacements = {
        "@API_PATH@": meta.get("path", ""),
        "@METHOD@": meta.get("method", "POST"),
        "@BODY@": body,
        "@APP_KEY@": "<YOUR_APP_KEY>",
        "@PRI_KEY@": "<YOUR_PRIVATE_KEY>",
        "@YOP_PUBLIC_KEY@": "<YOP_PUBLIC_KEY>",
    }
    if lang == "php":
        op, model, dto = php_names(meta.get("operationId", ""), meta.get("path", ""))
        replacements["@MODEL@"] = model
        replacements["@DTO@"] = dto
        replacements["@CLIENT_METHOD@"] = op
    out = tpl
    for k, v in replacements.items():
        out = out.replace(k, v)
    return out


def render_json(meta, required, values, scene):
    """默认输出：请求体 JSON（示例值填充）+ 字段说明。"""
    obj = {f["name"]: field_value(f, values, scene) for f in required}
    return json.dumps(obj, ensure_ascii=False, indent=2)


def print_field_notes(required, optional):
    """输出「字段说明」段落：需按枚举/模板/条件必填等特殊注意的字段。"""
    interesting = []
    for f in required + optional:
        notes = field_note(f)
        if notes:
            interesting.append((f, notes))
    if not interesting:
        return
    print("\n【字段说明】（需按枚举填写 / 按模板填写 / 条件必填等，请重点关注）")
    for f, notes in interesting:
        title = f.get("title") or f["name"]
        print(f"  - {f['name']}（{title}）：{'；'.join(notes)}")


def extract_condition_dims(pack):
    """提炼影响字段必填性的关键决策条件（供客户确认，而非逐字段确认值）。"""
    req = pack.get("reqParams", [])
    by_name = {n.get("name"): n for n in req}
    dims = {}  # name -> {"name","title","enum","labels","why":[]}

    def add(name, why):
        if not name or name not in by_name:
            return
        f = by_name[name]
        d = dims.setdefault(name, {
            "name": name,
            "title": f.get("title") or name,
            "enum": [e.get("value") for e in (f.get("enum") or [])],
            "labels": [e.get("label", e.get("value")) for e in (f.get("enum") or [])],
            "why": [],
        })
        if why and why not in d["why"]:
            d["why"].append(why)

    for n in req:
        # 1) required_when 里的变量（如 clearingType=="SWIFT" -> clearingType）
        when = n.get("required_when") or ""
        for m in re.finditer(r'(\w+)\s*==', when):
            add(m.group(1), f"{n.get('name')} 的必填依赖 {m.group(1)}")
        # 2) condition_text 里的「字段名=值」引用（如 payoutType=DOMESTIC_PAYMENT）
        ct = n.get("condition_text") or ""
        for m in re.finditer(r'([A-Za-z][A-Za-z0-9_]*)\s*=', ct):
            add(m.group(1), f"{n.get('name')}：{ct}")
        # 3) POBO 业务分支（异名付款影响付款人相关字段）
        if "POBO" in ct or "POBO" in (n.get("description") or ""):
            add("pobo", "是否异名 POBO 影响付款人相关字段")
    # 4) C 字段中带枚举的，本身也是决策条件（值决定自身/其他字段是否传）
    for n in req:
        if n.get("required") == "C" and n.get("enum"):
            add(n.get("name"), "条件必填枚举字段，需确认业务场景取值")

    # 被引用越多、越关键，排前面
    return sorted(dims.values(), key=lambda d: (-len(d["why"]), d["name"]))


def print_confirm(pack, uri):
    """输出「关键业务条件确认清单」：让客户确认影响字段对接的条件，而非每个字段值。"""
    title = pack.get("title", "")
    method = pack.get("method", "")
    path = pack.get("path", "")
    print(f"===== 关键业务条件确认：{title}（{method} {path}）=====\n")
    print("该接口下，影响「需要对接哪些字段」的关键条件如下，请与客户确认（无需逐项确认字段填什么值）：\n")

    dims = extract_condition_dims(pack)
    if not dims:
        print("（未发现条件必填依赖，直接生成即可）")
        return

    for i, d in enumerate(dims, 1):
        why = "；".join(d["why"])
        print(f"{i}. {d['title']}（{d['name']}）")
        if d["enum"]:
            opts = " / ".join(f"{v}（{l}）" for v, l in zip(d["enum"], d["labels"]))
            print(f"   可选：{opts}")
        if why:
            print(f"   影响：{why}")

    print("\n确认条件后，用 --scene 传入即可生成代码（字段以示例值填充，特殊字段末尾标注），例如：")
    sample = ",".join(f"{d['name']}={d['enum'][0]}" for d in dims if d["enum"])
    print(f'  python3 gen_code.py --api {uri} --scene "{sample}"')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", required=True)
    ap.add_argument("--lang", default="json", choices=["json"] + LANGS + ["all"],
                    help="输出语言，默认 json（未指定语言时优先 JSON）")
    ap.add_argument("--scene", default="", help="客户确认的条件，形如 payoutType=DOMESTIC_PAYMENT,clearingType=LOCAL")
    ap.add_argument("--values", default="", help="可选：客户确认的字段值，形如 accountName=ABC Ltd")
    ap.add_argument("--confirm", action="store_true", help="只输出关键业务条件确认清单，不生成代码")
    args = ap.parse_args()

    scene = parse_kv(args.scene)
    values = parse_kv(args.values)

    pack = json.load(open(os.path.join(PACK_DIR, f"{args.api}.json"), encoding="utf-8"))

    if args.confirm:
        print_confirm(pack, args.api)
        return

    result = resolve(args.api, scene)
    if "error" in result:
        sys.exit(result["error"])

    mode = mode_of(result["method"], pack.get("contentType", ""))
    required = result["required"] + result["unresolved"]  # 必填 + 条件必填（未确认时按示例值填充并标注）
    optional = result["optional"]

    print(f"===== {result['title']}  {result['method']} {result['path']} =====")
    print(f"Content-Type: {pack.get('contentType') or '（未知）'}  → 调用模式：{mode}")
    if scene:
        print(f"已确认条件：{scene}")
    print(f"必填 {len(result['required'])} | 条件必填 {len(result['unresolved'])} | 选填 {len(result['optional'])}\n")

    if mode == "multipart":
        print("=" * 60)
        print("⚠️ 该接口为 multipart/form-data（文件上传），官方新示例文档未覆盖。")
        print("   请按 YOP SDK 的文件上传能力（addFile / multipart）人工编写，")
        print("   或向研发确认 SDK 文件上传的标准调用方式。")
        print(f"   字段：{', '.join(f['name'] for f in required)}")
        return

    meta = dict(result)
    meta["operationId"] = pack.get("operationId", "")

    if args.lang == "json":
        print("【请求体 JSON】（字段已按示例值填充，敏感/运行时值用占位符）：\n")
        print(render_json(meta, required, values, scene))
        print_field_notes(required, optional)
        print("\n如需生成 Java / C# / Python / PHP / Go 代码，请告知语言。")
        return

    langs = LANGS if args.lang == "all" else [args.lang]
    for lang in langs:
        print("=" * 60)
        print(f"{LANG_LABEL[lang]} 代码\n")
        print(render(lang, mode, meta, required, optional, values, scene))
    print_field_notes(required, optional)


if __name__ == "__main__":
    main()
