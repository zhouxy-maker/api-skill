# 【PSP】API Solution Guide (Top-up version)

# 1. Solution overview

YeePay, as a licensed professional third-party payment service provider in China, offers safer, more efficient global fund services.

- **Pay to China:** YeePay creates compliant Pay to China solutions for scenarios such as goods trade, service trade, salary payment and family remittance. On the premise of strictly complying with the national foreign exchange management policies, you and your partners can enjoy the core service experience of fast account arrival, stable settlement and fund security.
- **FX:** We provide FX services for over 60 currency pairs, supporting real-time, quota-based, and pending-order foreign exchange conversion. With multi-channel routing, we offer you highly competitive exchange rates and assist you in foreign exchange conversion in a compliant and secure manner in accordance with SAFE/PBOC regulations.
- **Global payment:** Covering over 130 countries, we provide a low-cost and efficient global payment network, support Swift and local payment networks. Funds can arrive as fast as T0, and we also provide POBO capabilities.

# 2. Target Customer

Licensed Payment Service Provider

# 3. One-stop solution guide

PSP top up funds into YeePay's account in Hong Kong. After the funds are credited, you can conduct FX, payment to China, and global payout.

# 4. Product introductions and API solutions

Tips: For API guide and API instruction, you may click the link, which will directly direct you to Yeepay's open platform where you can obtain further detailed information.

## 1. Top up

#### 1. Product introduction:

1. The PSP transfers funds directly to YeePay Hong Kong's account for top-up, and YeePay credits the funds to your account via your payment remarks, which is usually your merchant ID.
2. **Limits:** only support funds from same-named account
3. **Support currencies:** USD、CNH、HKD、AUD、CAD、EUR、GBP、JPY、SGD

#### 2. API:

After onboarding, we will provide you with the account information and what remark you need to put. Then you can top up YeePay's account by yourself. There's no API for top-up, but we recommend integrating this notification API to get the information of top-up status.

| API Guide | API instruction | Requirement |
|---|---|---|
| (For Top up, you don't need API to make a transfer. But you can use this API for getting notifications.) | [Incoming Funds Notification](https://open.gptransfer.hk/docs/solutions/apidoc/693becdc7d2c7d0001a23a09/693bed203b0a750001efa619) | O |

## 2. FX

#### 1. API:

| API Guide | API instruction | API introduction | Requirement |
|---|---|---|---|
| [Foreign Exchange](https://open.gptransfer.hk/docs/open/apiguide/69045d74be3daf00010decce/6904606bbe3daf00010decef) | [Foreign Exchange Query](https://open.gptransfer.hk/docs/solutions/apidoc/apis_5/get__rest__v1.0__gpt__exchange__inquiry) | Supports querying tradable FX rates and FX rate locking. | M |
| | [Foreign Exchange - Request](https://open.gptransfer.hk/docs/solutions/apidoc/apis_5/post__rest__v1.0__gpt__exchange__order) | - | M |
| | [Currency Exchange - Inquiry](https://open.gptransfer.hk/docs/solutions/apidoc/apis_5/get__rest__v1.0__gpt__exchange__query) | - | O |

**FX rate lock guide:** Upload the token obtained from 'Foreign Exchange-Query' to 'Foreign Exchange-Request' to complete rate lock. The lock duration can be selected via API fields.

## 3. Pay to China

#### 1. Product introduction:

YeePay delivers efficient and convenient Pay to China services for you and your merchants. Please refer to the guide link below for details:

【Guide】Yeepay's Pay to China Solution (https://yeepay.feishu.cn/wiki/G0uewHKDRiN3LAkQ8dKchBmCnCh)

#### 2. API:

1. **Declaration & Payment:**

| API Guide | API instruction | API introduction | Requirement |
|---|---|---|---|
| [Pay to China](https://yeepay.feishu.cn/wiki/SDLHwjArYi19jEk2EZCcQ1WEnrc) | [Declaration Validation - request](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__declaration-detail__commit) | Upload declaration information. A maximum of 500 item-lists can be uploaded in a single batch. | M |
| | [Declaration Validation - query](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/get__rest__v1.0__gpt__upload__query) | - | O |
| | [Single Payment Request - CNY Payment (Institution)](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__fx-settlement__commit) | - | M |
| | [Single Payment Query - CNY Payment (Institution)](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__fx-settlement__query) | - | O |

- Sequence: conduct the declaration first, then call the 'Pay to China-request' API.
- Reconciliation: When calling the 'Pay to China-request' API, you need to match the declaration. (`requestId` in 'Pay to China-request' = `businessRequestId` in 'Declaration validation-request' API)

2. **Enterprise registration** (required only if you intend to use a company as the declaration entity):

| API Guide | API instruction | API introduction | Requirement |
|---|---|---|---|
| Enterprise Registration | [Enterprise Reporting Request](https://open.gptransfer.hk/docs/solutions/apidoc/apis_8/post__rest__v1.0__gpt__register__request) | Upload the information of sellers in mainland China (such as Organization Code/Unified Social Credit Code, contact number, etc.) | CM |
| | [Enterprise Reporting Query](https://open.gptransfer.hk/docs/solutions/apidoc/apis_8/get__rest__v1.0__gpt__register__query) | - | O |

3. **Payer customization** (required only if you want to customize the payer name as the sub-merchant's name):

| API Guide | API instruction | API introduction | Requirement |
|---|---|---|---|
| Wallet account (used for Pay to China POBO only) | [Create Wallet Account](https://open.gptransfer.hk/docs/solutions/apidoc/apis_6/post__rest__v1.0__gpt__wallet__apply) | Using the payer information for light KYC. | CM |
| | [Wallet account query](https://open.gptransfer.hk/docs/solutions/apidoc/apis_6/get__rest__v1.0__gpt__wallet__query) | - | O |
| | [Wallet Account Cancellation](https://open.gptransfer.hk/docs/solutions/apidoc/apis_6/post__rest__v1.0__gpt__wallet__close) | - | O |

## 4. Global Payout

#### 1. Product introduction

1. Before the payment, you or your sub-merchant need to complete the beneficiary management.
2. **POBO (Pay-on-behalf-of):**
   - through Swift —— mandatory
   - through Local —— depends on the channel (Please check [VA Collection & Global Payout 10.27](https://yeepay.feishu.cn/wiki/WBR7w7vZtiP2AUkgPT6ciVsTnyd) for further information)
   - For POBO function, you need to complete the payer management first.

#### 2. Global Payout capabilities:

[VA Collection & Global Payout 10.27](https://yeepay.feishu.cn/wiki/WBR7w7vZtiP2AUkgPT6ciVsTnyd)

#### 3. API:

| API Guide | API instruction | API introduction | Requirement |
|---|---|---|---|
| [Beneficiary Management](https://open.gptransfer.hk/docs/open/apiguide/69045d65be3daf00010deccc/69045f81be3daf00010dece7) | [Create Beneficiary](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__supplier__request) | You need to create beneficiary before the payment | M |
| | [Beneficiary Query](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/get__rest__v1.0__gpt__supplier__query) | - | O |
| | [Beneficiary Delete](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__supplier__delete) | - | O |
| | [Beneficiary Supplemental Materials Submission Interface](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__supplier__materials__submission) | - | M |
| [Global payout](https://open.gptransfer.hk/docs/open/apiguide/69045d65be3daf00010deccc/69045facbe3daf00010dece9) | [Payout Rate Query](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__payment__inquiry) | Use this API to lock exchange rates when processing cross-currency payments. Lock duration: 1 minute | O |
| | [Payout Request](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__payment__order) | - | M |
| | [Payout Query](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/get__rest__v1.0__gpt__payment__query) | Check the payment information (amount, status, etc) | O |
| [Payer Management](https://open.gptransfer.hk/docs/open/apiguide/69045d65be3daf00010deccc/6a2a68db1ccd8c0001d692db/6a2a68eb0253180001c88c56) (for POBO) | [Payer reporting](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__payer__request) | Upload trade evidence/trade relationship materials to complete the payer reporting. | M |
| | [Payer Query](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/get__rest__v1.0__gpt__payer__query) | - | O |
| | [Delete Payer](https://open.gptransfer.hk/docs/solutions/apidoc/apis_4/post__rest__v1.0__gpt__payer__delete) | - | O |

## 5. Other

| API Guide | API instruction | API introduction | Requirement |
|---|---|---|---|
| Upload file | [File-Upload](https://open.gptransfer.hk/docs/solutions/apidoc/apis_10/post__yos__v1.0__gpt__file__upload) | For fields related to files in the APIs, you need to first call the "File - Upload" interface to upload the files, and then obtain the path. | M |
| [Obtain Reconciliation Files and Payment Vouchers](https://open.gptransfer.hk/docs/open/apiguide/69045d6ebe3daf00010deccd/69046083be3daf00010decf1) | [File-Download](https://open.gptransfer.hk/docs/solutions/apidoc/apis_10/get__yos__v1.0__gpt__file__download) | Download files (general reconciliation file, end-of-day balance file, etc) | O |
| [Balance Inquiry](https://open.gptransfer.hk/docs/open/apiguide/69045d6ebe3daf00010deccd/69045fd0be3daf00010decec) | [Balance Query (by currency)](https://open.gptransfer.hk/docs/solutions/apidoc/apis_10/get__rest__v1.0__gpt__account__query) | Query the balance of a certain currency in the account | O |
| | [Balance Query (by merchant ID)](https://open.gptransfer.hk/docs/solutions/apidoc/apis_10/post__rest__v1.0__gpt__account__balance__query) | Query the balance of a certain merchant in the account | O |
