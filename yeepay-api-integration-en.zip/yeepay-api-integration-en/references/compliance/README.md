# Compliance Restrictions (screening first)

> Fact source: three external compliance lists (2026.07.01), see the yaml under `references/compliance/`.
> When the user's question involves "specific country/region / business scenario / industry / items", **do compliance screening first**, then discuss integration.

## Handling Rules (two tiers)

| Tier | Matched object | Handling |
|---|---|---|
| **Prohibited** | Prohibited countries/regions, prohibited activities/items | **Refuse to operate**: provide no integration assistance/solution/code; point out it falls in the prohibited scope and decline |
| **Extremely high risk / High risk** | Extremely-high-risk countries/regions, high-risk/restricted activities/items | **Compliance assessment required**: tell the user it requires communication with the Yeepay team and a compliance assessment before judging whether business can be conducted; do not directly refuse |

## Files

- `prohibited-countries.yaml` — Appendix 1: prohibited countries/regions (14) + extremely-high-risk countries/regions (15), including the "related customer / related transaction" definition.
- `prohibited-activities.yaml` — Appendix 2: prohibited activities/items (30).
- `high-risk-activities.yaml` — Appendix 3: high-risk/restricted activities/items (6).

## Screening Criteria

- Matches "Prohibited" → decline, don't expand.
- Matches "extremely high risk / high risk" → indicate "requires assessment after communicating with the Yeepay business/compliance team", don't self-judge whether business can be conducted.
- No match → assist integration normally.
- The lists are external snapshots, subject to the official latest version (don't repeatedly emphasize).
