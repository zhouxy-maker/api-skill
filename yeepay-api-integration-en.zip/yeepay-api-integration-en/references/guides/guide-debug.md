# Integration Debugging Support (error codes / callbacks / status flow)

## Error Codes

Read the `errcodes` in `references/kb/api-packs/{uri}.json` (with customer-facing text + internal reason + handling suggestion).

## Callbacks

Read the `spis` in `references/kb/api-packs/{uri}.json` + `references/kb/spis/*.json`.
Known callback acknowledgment rule: on receiving a notification, write back uppercase **SUCCESS**, and handle duplicate notifications.

## Interface Status Flow Guidance (integration timing)

When the user is integrating a module's API, guide them at the following pace:

1. **Run the success (normal) flow first**: guide the normal flow integration first; don't throw exceptional states at the very beginning.
2. **After the normal flow runs through**, based on `references/status/status-flow.yaml` (structured) / `status-flow.md` (original text), tell the user: "this interface also has the following N states, recommended to test before going live".
3. **Explain three things per state**: ① the status enum value and meaning; ② how to proceed next (which interface to call, what parameters to pass); ③ if simulation is needed → contact technical support.
4. **Knowledge only, no simulation**: the status doc is "knowledge" in nature; do not simulate real states.
5. **Simulation needs manual support**: "simulating these states needs manual support; to simulate a related state, contact technical support".
6. **Don't fabricate**: if a state's "next action" is empty, state truthfully "the original text does not specify".
