# Product Usage Q&A

Answer product timeliness, prerequisites, limitations, call order, and module capabilities.

> For "integrate the API", go to `guide-onboarding.md` four-step main flow; this document answers product details after the module is confirmed (review timeliness, limits, call order, etc.).

Read `references/products/` (00-solution-overview ~ 05-other-apis).

**Iron rule**: the interface list, call order, and reconciliation relations must be consistent with the standard solution document, not added, removed, or modified.

## Related-term Normalization

When the user asks with aliases/colloquial terms, first normalize to the standard module via `references/rules/aliases.yaml`, then answer. For example:
- "pay to China / pay CNY to mainland China / institutional settlement / pay to China" → Pay to China (settlement).
- "overseas payment / foreign currency payout / global payout" → Global Payout.

After a match, enter the corresponding scenario decision-tree branch.

## Standard Solution Modules (5 modules, 27 interfaces)

| Module | Interfaces | Key points |
|---|---|---|
| Top up | Incoming Funds Notification | Only same-named top-up is supported |
| FX | Inquiry / Request / Query | Rate lock (token returned, default 120s) |
| Pay to China (settlement) | Detail upload / Payment / Enterprise registration / Wallet | Detail first, then payment; reconcile requestId |
| Global Payout | Beneficiary / Payment / Payer / Rate lock | Beneficiary registration first; POBO constraints |
| Other | File upload/download / Balance query | File fields upload first to get path |
