# Code Generation

Generate JAVA / PYTHON (preferred) sample code, also supports C# / PHP / GO. **Must clarify the scenario before generating** (see the SKILL.md interaction rules).

## Data Sources (important change)

- Fields + required rules: `kb/api-packs/{uri}.json` (read internally by resolve).
- **Code templates: `scripts/code_templates.py`** (5 languages × 3 call patterns, from the Feishu wiki "Test Examples").
- ⚠️ The old sample code (sampleCodes, 6 languages) scraped from the open platform **has been deleted and must not be referenced** — that code is no longer maintained.

## Three Call Patterns (determined by method + contentType)

| Pattern | method + contentType | Assembly method | Covered interfaces |
|---|---|---|---|
| `get_form` | GET + x-www-form-urlencoded | addParameter / get | 10 |
| `post_json` | POST + application/json | setContent(jsonBody) / post_json | 14 |
| `post_form` | POST + x-www-form-urlencoded | addParameter / post | 1 (supplier/delete) |
| `multipart` | POST + multipart/form-data | **not covered by the official new examples, needs manual work** | 1 (file/upload) |

`gen_code.py` reads the api-pack's `contentType` to auto-select the template; no manual specification needed.

## Flow (confirm fields first, then generate code)

1. Use `references/rules/scenario-tree.yaml` to confirm scenario tags (ask the key branches one question at a time).
2. **Output the field confirmation list** (must do before generating):
   ```
   python3 scripts/gen_code.py --api <uri> --confirm
   ```
   Lists required + conditionally-required fields (with enum options, trigger conditions).
3. **Confirm field values with the customer one by one**: have the customer choose enum values; confirm whether conditionally-required fields trigger and what to fill; get the confirmed values.
4. Generate code with the confirmed values:
   ```
   python3 scripts/gen_code.py --api <uri> --lang python|java|csharp|php|go|all \
       --values "type=OVERSEAS_SUPPLIER,supplierType=ENTERPRISE,accountType=PRI,accountName=ABC Ltd"
   ```
5. In the code, fill confirmed fields with concrete values; leave unconfirmed fields as placeholders and list them at the end, then continue confirmation.

## Iron Rules

- **Confirm field values with the customer before generating**: don't generate code full of placeholders / pending-rule branches; enums and conditionally-required fields must be confirmed one by one before landing in code.
- Use `code_templates.py` templates as the base, only assemble fields, don't rewrite signature logic (signing is done automatically by the official SDK).
- Sensitive values are always placeholders (`<YOUR_MERCHANT_ID>`, `<YOUR_APP_KEY>`, `<YOUR_PRIVATE_KEY>`, etc.), never hardcode real keys; `requestId` and other runtime-generated values may stay as placeholders.
- Don't output code right away, and don't generate code stuffed with if-branches — confirm fields first, then assemble.
- multipart (file/upload) has no official new template: state truthfully "not covered by the official new examples; needs manual writing against the YOP SDK file upload capability", don't fabricate the call method.
- PHP DTO/model class names are derived from operationId and are for reference only, **subject to the actual SDK class names generated on the merchant side** (e.g. the official example's request body DTO is `SupplierReqDTO`, not `SupplierRequestDTO`).
