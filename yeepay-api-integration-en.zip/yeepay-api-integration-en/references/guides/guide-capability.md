# Collection & Payout Capability Q&A

When the user asks "which countries/currencies can be collected/paid", "VA account-opening bank", "whether POBO is supported", "arrival timeliness", "whether remarks are supported":

## Step 1: Give the authoritative link

The Feishu capability sheet is the dynamic fact source; return the link first:
- VA Collection & Global Payout: https://yeepay.feishu.cn/wiki/WBR7w7vZtiP2AUkgPT6ciVsTnyd

## Step 2: Look up the sheet for the specific question (snapshot, attach the link)

- VA collection → `references/capabilities/va-capability.yaml` (account-opening region / currency / bank / account usage / opening SLA / deposit speed / entity restriction / amount limit).
- Payout → `references/capabilities/payout-capability.yaml` (country / currency / payment method / account type / transaction type / POBO / remarks).
- ⚠️ Both files are snapshots; when answering, attach the Feishu link (the link is the latest sheet), don't copy stale data item by item.

## Question Examples (guide one question at a time when a key dimension is missing)

- VA collection: "Collecting from which country/region? Currency? Platform collection (e-commerce/independent sites) or trade collection? Business or individual incoming funds?"
- Payout: "Paying to which country? Currency? SWIFT or LOCAL? POBO or not? Remarks or not?"
- Judgment example: "Can the HK DBS VA collect e-commerce platform funds?" → check va-capability.yaml: HK DBS supports platform collection → answer "supported" + attach the link.
