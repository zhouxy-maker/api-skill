# Interface Status Docs

> Status: **delivered**. Sourced from Feishu "gpt product test case summary" https://yeepay.feishu.cn/wiki/EJ9fwf7UAiDnSJkh641c93xUnRg

## Files

- `status-flow.yaml` — structured status flow (organized by "module → interface → status", for skill lookup by interface)
- `status-flow.md` — original text side-by-side (markdown tables, with source links)
- `_template.md` — early reserved template (can be ignored, kept for reference)

## Coverage

Current docs cover 2 modules, 4 interface scenarios:

| Module | Interface | Non-success status count |
|---|---|---|
| Global Payout | Beneficiary registration (supplier__request) | Supplementary materials / rejected / refused |
| Global Payout | Payer registration (payer__request) | Pending / pending review / review rejected / available / disabled |
| Global Payout | Payout flow (payment__order) | Async direct failure / returned (bounced) |
| Pay to China | Institutional settlement - overseas branch standard (fx-settlement__commit) | Sync failure / async failure / chargeback |

## Usage Rules (must follow)

1. **Success first, supplement later**: when the user integrates a module's API, guide the success (normal) flow first; after the normal flow runs through, based on this doc tell the user "this interface also has these states to test".
2. **Knowledge only, no simulation**: this doc is "knowledge" — tell the user what other states the interface has, what each state means, and how to proceed next. Do not simulate real states.
3. **Simulation needs manual support**: simulating these states needs manual support; to simulate, tell the user "contact technical support".
4. **Don't fabricate**: for states with empty "next action", state truthfully "the original text does not specify", must not fabricate.
