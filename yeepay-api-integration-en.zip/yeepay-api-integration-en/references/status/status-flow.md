# Interface Status Flow Original Text (gpt product test case summary)

> Source: Feishu "gpt product test case summary" https://yeepay.feishu.cn/wiki/EJ9fwf7UAiDnSJkh641c93xUnRg
> Fetched at: 2026-11-06
> Structured version see `status-flow.yaml` (for lookup by interface); this file is the original text side-by-side.

## Usage Rules (must follow)

1. When the user integrates a module's API, **guide the success (normal) flow integration first**.
2. After the normal flow is integrated, based on this doc tell the user: "this interface also has the following states, recommended to test before going live".
3. Explain three things per state: **what it means, how to proceed next, whether manual support is needed**.
4. This doc does not simulate real states, only informs as "knowledge". Simulating these states needs manual support; **to simulate a related state, contact technical support**.

---

# Global Payout

## Beneficiary Registration

| Flow state | Status enum value | Next action |
|---|---|---|
| Supplementary materials | WAIT_SUPPLEMENT_MATERIAL | Call the beneficiary supplementary-materials interface supplier__materials__submission |
| Rejected | RISK_REBUT | Beneficiary update: operate=UPDATE (supplier__request) |
| Refused | FAILED | Beneficiary update: operate=UPDATE (supplier__request) |
| Success | / | / |

## Payer Registration

| Flow state | Status enum value | Next action |
|---|---|---|
| Pending | INIT | Update materials using the original requestId (id = the id returned in the payer request response) |
| Pending review | WAIT_CHECK | / |
| Review rejected | CHECK_REFUSE | Update materials using the original requestId (id = the id returned in the payer request response) |
| Available | AVAILABLE | / |
| Disabled | DISABLE | / |

## Payout Flow

The synchronous interface has returned SUCCESS, the request is accepted.

| Flow state | Status enum value | Next action |
|---|---|---|
| Async direct failure | Notification: FAIL | (not specified in the original text) |
| Returned/bounced (success first, then failure) | Notification: SUCCESS -> RETURN | (not specified in the original text) |
| Success | Notification: SUCCESS | / |

---

# Pay to China (Settlement)

## Institutional Settlement (overseas branch standard version)

The synchronous interface has returned SUCCESS, the request is accepted.

| Flow state | Status enum value | Next action |
|---|---|---|
| Sync failure | / (funds not operated) | Correct the parameters, then resubmit the remittance request |
| Async failure | Callback type=TRANSFER_COMPLETE_RESULT, status=FAIL (funds returned to CNH) | ① re-initiate the detail request; ② initiate a new remittance request |
| Chargeback | Callback type=TRANSFER_COMPLETE_RESULT, status=SUCCESS -> FAIL (funds returned to CNY REFUND) | Initiate a brand-new remittance request with only these parameters: payoutCurrency=REFUND; originRequestId=the requestId of the previous failed remittance; requestId=a newly generated requestId |
| Success | (empty) | (empty) |

Service trade / goods trade (non-salary/family-support) and salary/family-support scenarios are recommended to be tested separately.

| Scenario | useCode |
|---|---|
| Service trade / goods trade | GOODSTRADE / GENERALTRADE / ADVERTISEMENT / TRANSPORT2 / TRANSPORT3 / TRANSPORT5 / TRANSPORT7 / PLANETICKET / HOTELACCOMMODATION / TRAVEL / TRAVEL2 / SOFTWARE |
| Salary / family support | SALARY / FAMILYALLOWANCE |
