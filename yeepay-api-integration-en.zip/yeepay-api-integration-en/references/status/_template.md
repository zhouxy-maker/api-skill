# Interface Status Template

> For `references/status/{uri}.md`; fill in per this template after the interface status doc is delivered.

## Basic Info

- Interface: `{uri}`
- Title: `{title}`
- Method: `{method}` `{path}`

## State Machine

| Status code | Meaning | Trigger condition | Next state | Timeout | Merchant-side action |
|---|---|---|---|---|---|
| PROCESSING | Processing | After initiating the request | SUCCESS / FAIL | - | Wait for callback or poll query |
| SUCCESS | Success | - | - | - | - |
| FAIL | Failure | - | - | - | Check the failure reason, retry if necessary |

## State Explanation and Troubleshooting

### PROCESSING (Processing)

- Meaning:
- Troubleshooting:

### SUCCESS (Success)

- Meaning:
- Troubleshooting:

### FAIL (Failure)

- Meaning:
- Troubleshooting:
