# 4. Global Payout

> Source: Yeepay "【PSP】API Solution Guide"

## Product Introduction

1. A merchant initiates payout to a **non-CNY** beneficiary account (including bank accounts and wallet accounts).
2. Beneficiary registration must be completed before the payment request.
3. Global payout supports **same-currency and cross-currency payouts**. For cross-currency payouts, use the Payout Rate Query API to lock the rate (1 minute).
4. POBO capability: **English POBO only**
   - Through Swift —— POBO is mandatory.
   - Through Local —— depends on whether the region supports/requires POBO (see the Global Payout capability table).

## Global Payout Capabilities

[VA Collection & Global Payout 10.27](https://yeepay.feishu.cn/wiki/WBR7w7vZtiP2AUkgPT6ciVsTnyd)

## API Integration Guide

| Guide | Interface | Interface Description | Requirement |
|---|---|---|---|
| Beneficiary Management | Create Beneficiary | Upload beneficiary info for registration | M |
| | Beneficiary Query | - | O |
| | Beneficiary Delete | - | O |
| | Beneficiary Supplemental Materials Submission | Submit supplements when the registration returns "pending supplementary materials" | M |
| Global Payout | Payout Rate Query | Lock the rate / query fees for cross-currency payouts | O |
| | Payout Request | Initiate a payout transaction | M |
| | Payout Query | Query transaction info, payment status, etc. | O |
| Payer Management (for POBO, mandatory) | Payer Reporting | Submit trade evidence/relationship materials for payer registration | M |
| | Payer Query | Query payer info, registration status, etc. | O |
| | Delete Payer | - | O |

### Interface uri Mapping

| Interface | uri | Requirement |
|---|---|---|
| Create Beneficiary | `post__rest__v1.0__gpt__supplier__request` | M |
| Beneficiary Query | `get__rest__v1.0__gpt__supplier__query` | O |
| Beneficiary Delete | `post__rest__v1.0__gpt__supplier__delete` | O |
| Beneficiary Supplemental Materials Submission | `post__rest__v1.0__gpt__supplier__materials__submission` | M |
| Payout Rate Query | `post__rest__v1.0__gpt__payment__inquiry` | O |
| Payout Request | `post__rest__v1.0__gpt__payment__order` | M |
| Payout Query | `get__rest__v1.0__gpt__payment__query` | O |
| Payer Reporting | `post__rest__v1.0__gpt__payer__request` | M |
| Payer Query | `get__rest__v1.0__gpt__payer__query` | O |
| Delete Payer | `post__rest__v1.0__gpt__payer__delete` | O |
