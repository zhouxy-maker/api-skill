# 3. Pay to China (Settlement)

> Source: Yeepay "【PSP】API Solution Guide"

## Product Introduction

YeePay delivers efficient and convenient Pay to China services for you and your merchants. Customer guide: [【Guide】Yeepay's Pay to China Solution](https://yeepay.feishu.cn/wiki/G0uewHKDRiN3LAkQ8dKchBmCnCh)

## API Integration Guide

### 1. Settlement

| Guide | Interface | Interface Description | Requirement |
|---|---|---|---|
| Single CNY Settlement (Institution) | Declaration Validation - request | Upload order info, declaration subject info, trade/salary info, etc. A maximum of 500 item-lists can be uploaded in a single batch. | M |
| | Declaration Validation - query | Query declaration upload status | O |
| | Single Payment Request - CNY Payment (Institution) | Initiate a settlement transaction (single transaction) | M |
| | Single Payment Query - CNY Payment (Institution) | Query transaction info | O |

**Call order:** Strictly follow "upload declaration first, then payment request".
**Reconciliation:** When making a payment request, match the relevant declaration. (`requestId` in Payment Request = `businessRequestId` in Declaration Upload)

### 2. Enterprise Registration (required only if using a company as the declaration entity)

| Guide | Interface | Interface Description | Requirement |
|---|---|---|---|
| Enterprise Registration | Enterprise Reporting Request | Upload mainland seller company info (Organization Code, contact number, etc.) | CM |
| | Enterprise Reporting Query | Query registration status | O |

### 3. Payer Customization (required only if using a different-name POBO)

| Guide | Interface | Interface Description | Requirement |
|---|---|---|---|
| Payer Customization | Create Wallet Account | Light KYC using the payer info for POBO | CM |
| | Wallet Account Query | Query review status | O |
| | Wallet Account Cancellation | Cancel the account | O |

### Interface uri Mapping

| Interface | uri | Requirement |
|---|---|---|
| Declaration Validation - request | `post__rest__v1.0__gpt__declaration-detail__commit` | M |
| Declaration Validation - query | `get__rest__v1.0__gpt__upload__query` | O |
| Single Payment Request - CNY Payment | `post__rest__v1.0__gpt__fx-settlement__commit` | M |
| Single Payment Query - CNY Payment | `post__rest__v1.0__gpt__fx-settlement__query` | O |
| Enterprise Reporting Request | `post__rest__v1.0__gpt__register__request` | CM |
| Enterprise Reporting Query | `get__rest__v1.0__gpt__register__query` | O |
| Create Wallet Account | `post__rest__v1.0__gpt__wallet__apply` | CM |
| Wallet Account Query | `get__rest__v1.0__gpt__wallet__query` | O |
| Wallet Account Cancellation | `post__rest__v1.0__gpt__wallet__close` | O |
