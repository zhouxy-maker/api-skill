# PSP Solution Overview

> Source: Yeepay "【PSP】API Solution Guide" (references/source/PSP-API-Solution-Guide.md)
> Note: This document is one of the Skill's fact sources. Content strictly inherits the standard solution doc; interfaces, call order, and reconciliation relations are not added, removed, or modified.

## Product Capability Overview

YeePay (易宝支付), as a licensed professional third-party payment service provider in China, offers safer, more efficient global fund services, helping you quickly build a complete "top-up → FX → payout" payment capability.

- **Pay to China (Settlement):** Under the premise of strictly complying with national foreign exchange management policies, YeePay provides core service experience of fast account arrival, stable settlement, and fund security in goods trade, service trade, and salary/remittance scenarios.
- **FX:** Provides FX services for 60+ currency pairs, supporting real-time, quota-based, and pending-order conversion, with multi-channel routing and highly competitive rates, compliant and secure in accordance with SAFE/PBOC regulations.
- **Global Payment:** Covers 130+ countries, providing a low-cost, efficient global payment network supporting Swift and local payment networks, funds arriving as fast as T0, with POBO capability.

## Target Customer

Licensed Payment Service Providers (no need to open VA accounts for sub-merchants).

## One-stop Solution

The PSP aggregates funds and transfers them to YeePay Hong Kong's customer fund account. After the funds are credited, FX, Pay to China, and Global Payout can be conducted.

## Product Modules and Interface List

| Module | Products Involved | Interface Count |
|---|---|---|
| 1. Top up | Same-named top-up | 1 |
| 2. FX | Real-time FX, rate lock | 3 |
| 3. Pay to China (settlement) | Settlement, enterprise registration, payer customization | 9 |
| 4. Global Payout | Beneficiary management, global payout, payer management | 10 |
| 5. Other APIs | File upload/download, balance query | 4 |

**27 interfaces in total.**

## Integration Requirement Markers

- Interface-level: **M** = mandatory / **O** = optional / **CM** = conditionally mandatory (used by this solution doc)
- Field-level: **M** = required / **O** = optional / **C** = conditionally required (used by the API docs)

The two marker systems have different meanings; do not mix them during Q&A and code generation.
