# 1. Top up

> Source: Yeepay "【PSP】API Solution Guide"

## Product Introduction

1. **Top up:** PSP/platform customers transfer funds directly to YeePay Hong Kong's GPT master account to complete top-up. YeePay credits the funds to your account via a specific payment remark.
2. **Limits:** Only same-named top-up is supported.
3. **Supported currencies:** USD, CNH, HKD, AUD, CAD, EUR, GBP, JPY, SGD.

## API Integration Guide

After merchant onboarding, YeePay provides the top-up account and remark content, so you can top up directly. Integrate the "Incoming Funds Notification" to receive top-up status on your own.

| Guide | Interface | Interface Description | Requirement |
|---|---|---|---|
| Top up | Incoming Funds Notification | Pushes an incoming-funds notification when a transfer is received | O |

### Interface uri Mapping

| Interface | uri / docId | Requirement |
|---|---|---|
| Incoming Funds Notification | `693bed203b0a750001efa619` (solution doc page) | O |

> Note: The Incoming Funds Notification is a solution doc page (callback notification), not in the interface tree.json; its field definitions are in references/kb/spis/.
