# 5. Other APIs

> Source: Yeepay "【PSP】API Solution Guide"

## API Integration Guide

| Guide | Interface | Interface Description | Requirement |
|---|---|---|---|
| Upload file | File Upload | Fields involving files in the APIs must first call the "File - Upload" API to upload and obtain the path | M |
| Obtain Reconciliation Files and Payment Vouchers | File Download (reconciliation) | Download reconciliation files, etc. | O |
| Balance Inquiry | Balance Query (by currency) | Query the balance of a certain currency in the account | O |
| | Balance Query (by merchant ID) | Query the balance of a certain merchant in the account | O |

### Interface uri Mapping

| Interface | uri | Requirement |
|---|---|---|
| File Upload | `post__yos__v1.0__gpt__file__upload` | M |
| File Download (reconciliation) | `get__yos__v1.0__gpt__file__download` | O |
| Balance Query (by currency) | `get__rest__v1.0__gpt__account__query` | O |
| Balance Query (by merchant ID) | `post__rest__v1.0__gpt__account__balance__query` | O |
