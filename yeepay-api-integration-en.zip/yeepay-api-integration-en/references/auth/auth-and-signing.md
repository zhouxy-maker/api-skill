# Authentication & Signing

> Info source: the open platform definition.json `securityReqs` + Feishu wiki "Test Examples" code templates (scripts/code_templates.py).

## Signing Mechanism

All interfaces in this solution use the following signing mechanism uniformly (from each interface's `securityReqs` field, two items each):

| Signing algorithm | Description |
|---|---|
| YOP-RSA2048-SHA256 | RSA2048 key + SHA256 digest |
| YOP-SM2-SM3 | SM2 signing + SM3 digest (Chinese national cryptography) |

> Note: signing is done automatically by the official SDK when the request is initiated; the merchant side only needs to configure `appKey` and the corresponding private key, no need to manually assemble the signing string.

## Key Preparation (merchant side)

1. Create an application in the YeePay International open platform (mp.yeepay.com developer center) to obtain the `appKey`.
2. Prepare the corresponding certificate/key pair (RSA2048 or SM2), referring to the platform doc "Key Management".
3. Configure the IP whitelist (if the platform requires).

## SDK Configuration per Language (from the official examples)

### Python

```python
from client.yopclient import YopClient
from client.yop_client_config import YopClientConfig

# Method 1: load the default config config/yop_sdk_config_rsa_prod.json
client = YopClient()

# Method 2: custom config file
# config_file = 'config/yop_sdk_config_{}.json'.format(xxx)
# clientConfig = YopClientConfig(config_file)
# client = YopClient(clientConfig, env, cert_type)
```

Credentials can be specified explicitly (requires importing YopCredentials):
```python
# credentials = YopCredentials(appKey='<APP_KEY>', cert_type='RSA2048|SM2', priKey='<PRIVATE_KEY>')
```

### Java

```java
import com.yeepay.yop.sdk.service.common.YopClient;
import com.yeepay.yop.sdk.service.common.YopClientBuilder;

// Thread-safe, singleton recommended
private static final YopClient client = YopClientBuilder.builder().build();
```

## Security Constraints (must follow)

- **Never write real `appKey`, private keys, or merchant numbers into any file or code repository.**
- When generating sample code, sensitive values are always placeholders: `<APP_KEY>`, `<YOUR_MERCHANT_ID>`, `<PRIVATE_KEY>`, etc.
- Private key file paths and certificate passwords are injected only via environment variables or local protected config; hardcoding is prohibited.
