#!/usr/bin/env python3
"""
fetch_docs.py — Fetch Yeepay International open platform (open.gptransfer.hk) docs into kb/.

Data source is static JSON, root at https://open.gptransfer.hk/apis/docs/ (no login).
Language: `--lang en` (default) or `--lang zh`. English uses the `_en_US` suffix
convention (e.g. definition.json -> definition_en_US.json) discovered from the SPA.

Performance design:
  - Concurrent fetch (ThreadPoolExecutor, 10 threads); 26 APIs take ~8-15s
  - definition / errcode / spi / models all cached to disk (.snapshot/raw and .snapshot/models);
    second run (no change) ~1-2s
  - --refresh ignores cache and forces a full re-fetch

Usage:
  python3 fetch_docs.py                 # default: cache first, fetch only on miss
  python3 fetch_docs.py --refresh       # force re-fetch
  python3 fetch_docs.py --lang en       # fetch the English version (_en_US suffix)
  python3 fetch_docs.py --only <uri>    # fetch a single API (for debugging)
"""
import argparse
import hashlib
import html as _html
import json
import os
import re
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE = "https://open.gptransfer.hk/apis/docs"
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOURCE_DIR = os.path.join(SKILL_DIR, "references", "source")
KB_DIR = os.path.join(SKILL_DIR, "references", "kb")
APIS_DIR = os.path.join(KB_DIR, "apis")
SNAP_DIR = os.path.join(KB_DIR, ".snapshot")
RAW_DIR = os.path.join(SNAP_DIR, "raw")
TREE_CACHE = os.path.join(SNAP_DIR, "tree.json")

UA = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"}

# global flag: True when --refresh, ignore all disk cache
REFRESH = False

# global language flag: 'zh' | 'en' (English uses the _en_US suffix)
LANG = "en"


def localize(url):
    """In en mode, insert _en_US before the .json/.html extension (matching the official frontend)."""
    if LANG == "en":
        if url.endswith(".json") or url.endswith(".html"):
            return url[:-5] + "_en_US" + url[-5:]
    return url


# in-process cache: models reused across APIs
_MODEL_CACHE = {}
MODEL_DIR = os.path.join(SNAP_DIR, "models")


def log(msg):
    print(f"[fetch] {msg}", file=sys.stderr)


def http_get(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="replace")


def http_get_json(url, timeout=30):
    return json.loads(http_get(url, timeout))


def cached_json(path, url):
    """Read disk cache first (when REFRESH=False), otherwise fetch and write cache."""
    if not REFRESH and os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    data = http_get_json(url)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    return data


def fetch_model(group, ref):
    key = f"{group}:{ref}"
    if key in _MODEL_CACHE:
        return _MODEL_CACHE[key]
    disk = os.path.join(MODEL_DIR, f"{group}__{ref}.json")
    if not REFRESH and os.path.exists(disk):
        try:
            with open(disk, encoding="utf-8") as f:
                model = json.load(f)
        except Exception:
            model = None
        _MODEL_CACHE[key] = model
        return model
    try:
        model = http_get_json(localize(f"{BASE}/models/{group}/{ref}.json"))
    except Exception:
        model = None
    if model is not None:
        os.makedirs(MODEL_DIR, exist_ok=True)
        with open(disk, "w", encoding="utf-8") as f:
            json.dump(model, f, ensure_ascii=False)
    _MODEL_CACHE[key] = model
    return model


def clean_html(s):
    """HTML -> plain text, preserving newlines and enum-item readability."""
    if not s:
        return ""
    s = re.sub(r"<br\s*/?>", "\n", s)
    s = re.sub(r"</p>", "\n", s)
    s = re.sub(r"</li>", "\n", s)
    s = re.sub(r"</(td|th|tr)>", "\t", s)
    s = re.sub(r"<[^>]+>", "", s)
    s = _html.unescape(s)
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n[ \t]+", "\n", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def tri_state(required, condition_required):
    if required:
        return "M"
    if condition_required:
        return "C"
    return "O"


def extract_enum(desc_text):
    if not desc_text:
        return None
    items = []
    for line in desc_text.split("\n"):
        m = re.match(r"^\s*([A-Z][A-Z0-9_\-]{1,40})\s*[:：]\s*(.+?)\s*$", line)
        if m:
            label = m.group(2).strip()
            if m.group(1) in ("GET", "POST", "API", "SDK"):
                continue
            items.append({"value": m.group(1), "label": label})
    if len(items) < 2:
        if len(desc_text) > 120:
            return None
        items = []
        for m in re.finditer(r"([A-Z][A-Z0-9_\-]{1,40})\s*[:：\-]\s*([^\s，。；,]{0,20})", desc_text):
            items.append({"value": m.group(1), "label": m.group(2).strip()})
    seen, uniq = set(), []
    for v in items:
        if v["value"] not in seen:
            seen.add(v["value"])
            uniq.append(v)
    return uniq if len(uniq) >= 2 else None


def fetch_tree():
    tree = cached_json(TREE_CACHE, localize(f"{BASE}/apis/tree.json"))
    flat = {}
    def walk(n, loc=""):
        cur = f"{loc}/{n.get('code','')}" if loc else n.get("code", "")
        for it in n.get("items", []) or []:
            flat[it["uri"]] = {
                "apiId": it["apiId"], "title": it["title"], "method": it["method"],
                "path": it["path"], "location": it.get("location", ""),
                "operationId": it.get("operationId", ""),
            }
        for c in n.get("children", []) or []:
            walk(c, cur)
    for n in tree:
        walk(n)
    return flat


def extract_slugs():
    slugs = {}
    for fn in os.listdir(SOURCE_DIR):
        if not fn.endswith(".md"):
            continue
        md = open(os.path.join(SOURCE_DIR, fn), encoding="utf-8").read()
        for url in re.findall(r"\((https://open\.gptransfer\.hk/docs/(?:solutions/apidoc|apis)/[^)]+)\)", md):
            last = url.rstrip("/").split("/")[-1]
            if re.fullmatch(r"[0-9a-f]{24}", last):
                slugs[last] = "docid"
            else:
                slugs[last] = "api"
    return slugs


def normalize_field(n, path_prefix=""):
    name = n.get("name") or n.get("title") or ""
    desc = clean_html(n.get("description") or n.get("desc") or "")
    return {
        "name": name,
        "path": f"{path_prefix}.{name}".strip("."),
        "title": n.get("title") or name,
        "type": n.get("type") or "",
        "format": n.get("format") or "",
        "maxLength": n.get("maxLength") or "",
        "required": tri_state(n.get("required"), n.get("conditionRequired")),
        "example": n.get("example") or "",
        "defVal": n.get("defVal") or "",
        "encrypt": bool(n.get("encrypt")),
        "description": desc,
        "enum": extract_enum(desc),
        "children": [],
    }


def build_fields(nodes, group):
    flat = []
    def rec(ns, prefix, depth):
        result = []
        for n in ns or []:
            ref = n.get("ref")
            if ref and depth < 8:
                model = fetch_model(group, ref)
                if isinstance(model, list):
                    result.extend(rec(model, prefix, depth + 1))
                    continue
            f = normalize_field(n, prefix)
            children = n.get("children") or []
            if children:
                f["children"] = rec(children, f["path"], depth + 1)
            if f["name"]:
                flat.append(f)
            elif f["children"]:
                result.extend(f["children"])
                continue
            result.append(f)
        return result
    tree = rec(nodes, "", 0)
    return tree, flat


def _section_nodes(definition, section):
    nodes = []
    for ct, ns in (definition.get(section) or {}).items():
        if isinstance(ns, list):
            nodes.extend(ns)
    return nodes


def build_api(slug, api_meta):
    aid = api_meta["apiId"]
    definition = cached_json(os.path.join(RAW_DIR, aid, "definition.json"),
                             localize(f"{BASE}/apis/{aid}/definition.json"))
    group = definition.get("apiGroup") or "gpt"

    req_tree, _ = build_fields(_section_nodes(definition, "reqParams"), group)
    resp_tree, _ = build_fields(_section_nodes(definition, "respParams"), group)

    errcodes = []
    try:
        errcodes = cached_json(os.path.join(RAW_DIR, aid, "errcode.json"),
                               localize(f"{BASE}/apis/{aid}/errcode.json")) or []
    except Exception:
        pass

    spis = []
    try:
        spis = cached_json(os.path.join(RAW_DIR, aid, "spi.json"),
                           localize(f"{BASE}/apis/{aid}/spi.json")) or []
    except Exception:
        pass

    return {
        "uri": slug,
        "apiId": aid,
        "title": definition.get("title") or api_meta.get("title", ""),
        "method": definition.get("method") or api_meta.get("method", ""),
        "path": definition.get("path") or api_meta.get("path", ""),
        "apiGroup": group,
        "operationId": api_meta.get("operationId", ""),
        "securityReqs": definition.get("securityReqs") or [],
        "commonRef": definition.get("commonRef") or "",
        "requestEncrypt": bool(definition.get("requestEncrypt")),
        "responseEncrypt": bool(definition.get("responseEncrypt")),
        "desc": clean_html(definition.get("desc") or ""),
        # reqParams' top-level key is the Content-Type (application/json / x-www-form-urlencoded / multipart)
        # gen_code.py picks the assembly mode from this
        "contentType": next(iter(definition.get("reqParams") or {}), ""),
        "reqParams": req_tree,
        "respParams": resp_tree,
        "reqExample": definition.get("reqExamples") or {},
        "respExample": definition.get("respExamples") or {},
        "errcodes": errcodes,
        "spis": spis,
        "fetchedAt": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


def raw_fingerprint(aid):
    """Compute the fingerprint of an API's raw cache (definition/errcode/spi) for incremental build."""
    fp = []
    for kind in ("definition", "errcode", "spi"):
        p = os.path.join(RAW_DIR, aid, f"{kind}.json")
        if os.path.exists(p):
            st = os.stat(p)
            fp.append(f"{kind}:{st.st_mtime_ns}:{st.st_size}")
    return "|".join(fp)


def main():
    global REFRESH, LANG
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", help="fetch a single uri")
    ap.add_argument("--refresh", action="store_true", help="ignore cache, force re-fetch")
    ap.add_argument("--lang", choices=["zh", "en"], default="en", help="language: zh=Chinese / en=English")
    args = ap.parse_args()
    REFRESH = args.refresh
    LANG = args.lang

    os.makedirs(APIS_DIR, exist_ok=True)
    os.makedirs(SNAP_DIR, exist_ok=True)

    slugs = extract_slugs()
    log(f"Parsed {len(slugs)} links from the standard solution doc")
    docids = [s for s, k in slugs.items() if k == "docid"]
    if docids:
        log(f"{len(docids)} of them are solution doc pages (docId), to be handled by render_fallback.py: {docids}")

    tree_flat = fetch_tree()
    log(f"tree.json has {len(tree_flat)} APIs")

    # read last build fingerprint for incremental decision
    state_path = os.path.join(SNAP_DIR, "build-state.json")
    old_state = {}
    if os.path.exists(state_path):
        try:
            old_state = json.load(open(state_path, encoding="utf-8"))
        except Exception:
            old_state = {}

    # APIs that need rebuild (raw changed or first time)
    todo, reused, skipped = [], [], []
    for slug, kind in sorted(slugs.items()):
        if kind == "docid":
            skipped.append(slug)
            continue
        if args.only and slug != args.only:
            continue
        meta = tree_flat.get(slug)
        if not meta:
            log(f"⚠️ {slug} not found in tree.json, skipped")
            skipped.append(slug)
            continue
        fp = raw_fingerprint(meta["apiId"])
        kb_path = os.path.join(APIS_DIR, f"{slug}.json")
        if not REFRESH and fp and old_state.get(slug) == fp and os.path.exists(kb_path):
            reused.append(slug)
        else:
            todo.append((slug, meta))

    if reused:
        log(f"Incremental: {len(reused)} APIs unchanged, reusing last results")

    done = {}
    failed = []
    with ThreadPoolExecutor(max_workers=10) as ex:
        futures = {ex.submit(build_api, slug, meta): slug for slug, meta in todo}
        for fut in as_completed(futures):
            slug = futures[fut]
            try:
                done[slug] = fut.result()
            except Exception as e:
                log(f"❌ fetch failed {slug}: {e}")
                failed.append(slug)

    # read old manifest; reused APIs keep their md5 (zero disk read, zero recompute)
    old_manifest = {}
    manifest_path = os.path.join(SNAP_DIR, "manifest.json")
    if os.path.exists(manifest_path):
        try:
            old_manifest = json.load(open(manifest_path, encoding="utf-8")).get("apis", {})
        except Exception:
            old_manifest = {}

    index = {}
    manifest = {}
    new_state = {}

    # new/changed APIs: write file + compute md5
    for slug, api in done.items():
        meta = tree_flat[slug]
        out = os.path.join(APIS_DIR, f"{slug}.json")
        with open(out, "w", encoding="utf-8") as f:
            json.dump(api, f, ensure_ascii=False, indent=2)
        digest = hashlib.md5(json.dumps(api, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
        manifest[slug] = {"apiId": meta["apiId"], "title": api["title"],
                          "method": api["method"], "path": api["path"], "md5": digest}
        index[slug] = {"apiId": meta["apiId"], "title": api["title"],
                       "method": api["method"], "path": api["path"],
                       "operationId": meta["operationId"]}
        new_state[slug] = raw_fingerprint(meta["apiId"])

    # reused APIs: keep old md5, rebuild index only (in-memory)
    for slug in reused:
        meta = tree_flat[slug]
        manifest[slug] = old_manifest.get(slug, {"apiId": meta["apiId"], "title": meta["title"],
                                                 "method": meta["method"], "path": meta["path"], "md5": ""})
        index[slug] = {"apiId": meta["apiId"], "title": meta["title"],
                       "method": meta["method"], "path": meta["path"],
                       "operationId": meta["operationId"]}
        new_state[slug] = raw_fingerprint(meta["apiId"])

    with open(os.path.join(KB_DIR, "api-index.json"), "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2, sort_keys=True)
    with open(os.path.join(SNAP_DIR, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump({"fetchedAt": time.strftime("%Y-%m-%dT%H:%M:%S"), "apis": manifest},
                  f, ensure_ascii=False, indent=2, sort_keys=True)
    with open(state_path, "w", encoding="utf-8") as f:
        json.dump(new_state, f, ensure_ascii=False, indent=2, sort_keys=True)

    log(f"✅ Done {len(done) + len(reused)} (new/changed {len(todo)}, reused {len(reused)}), "
        f"failed {len(failed)}, skipped {len(skipped)}")
    log(f"Knowledge base output: {APIS_DIR}")


if __name__ == "__main__":
    main()
