#!/usr/bin/env python3
"""
analyze_conditions.py — Scan all conditionally-required (C) fields in the KB, generate the rule base skeleton + auto-derivation.

For each C field, extract three kinds of info:
  1. condition_text —— the condition clause in the description ("required when ...", "not required when ...", etc.)
  2. source_doc     —— the external reference doc cited via "For details, see: X" / "See X" (where the condition actually lives)
  3. required_when  —— the structurable condition expression (for resolve_fields.py); empty if not structurable

confidence levels: inferred (AI extracted from description, to confirm) / unresolved (condition is in an external doc, to fill).

Output: references/rules/field-conditions.yaml
"""
import glob
import json
import os
import re
import sys
import yaml

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_DIR = os.path.join(SKILL_DIR, "references", "kb")
RULES_DIR = os.path.join(SKILL_DIR, "references", "rules")


def extract_condition(desc):
    """Extract the condition clause from the description (longest candidate wins)."""
    if not desc:
        return None
    m = re.search(r"[Rr]equired\s+(?:when|if|for)\s+([^.\n]+)", desc)
    if m:
        return "Required when " + m.group(1).strip().rstrip(".").strip()
    m = re.search(r"([^.\n]+?)\s+is\s+not\s+required", desc)
    if m:
        return "Not required when " + m.group(1).strip()
    return None


def extract_source(desc):
    """Extract the external doc name from "For details, see: XXX" / "See XXX"."""
    if not desc:
        return None
    m = re.search(r"(?:For details[,:]?\s*)?[Ss]ee\s*[:：]?\s*([^.\n]+)", desc)
    return m.group(1).strip() if m else None


def to_when(cond_text, field_values):
    """Structure cond_text into a required_when expression (simple single-value AND only).

    Example: 'Required when clearingType=LOCAL,bankCountry=BR,paymentType=PIX'
      -> 'clearingType=="LOCAL" && bankCountry=="BR" && paymentType=="PIX"'

    Safety policy: only generate when every clause is "field=single-enum-value" pure AND;
    on '/' (multi-select enum), 'or', 'not', parentheses, etc., return None for manual handling.
    """
    if not cond_text:
        return None
    body = re.sub(r"^Required when\s+", "", cond_text)
    body = re.sub(r"^Not required when\s+", "", body)
    body = body.strip().rstrip(".")
    # complex semantics -> give up
    if re.search(r"[/，,、]?\s*(or|not|and|either|at least one)", body):
        return None
    clauses = []
    for seg in re.split(r"[，,;；\n]+", body):
        seg = seg.strip()
        if not seg:
            continue
        m = re.match(r"^(\w+)\s*[=＝]\s*([A-Za-z0-9_\-]+)$", seg)
        if not m:
            return None
        field, val = m.group(1), m.group(2)
        if field not in field_values:
            return None
        clauses.append(f'{field}=="{val}"')
    return " && ".join(clauses) if clauses else None


def flatten(nodes, out=None):
    if out is None:
        out = []
    for n in nodes:
        out.append(n)
        if n.get("children"):
            flatten(n["children"], out)
    return out


def main():
    cond_fields = {}
    for f in glob.glob(os.path.join(KB_DIR, "apis", "*.json")):
        d = json.load(open(f, encoding="utf-8"))
        uri = d["uri"]
        all_fields = flatten(d.get("reqParams", []))
        field_names = {n.get("path", "").split(".")[-1] for n in all_fields}
        for n in all_fields:
            if n.get("required") != "C":
                continue
            desc = n.get("description", "")
            key = f"{uri}.{n.get('path','')}"
            cond_fields[key] = {
                "api": uri,
                "apiTitle": d.get("title", ""),
                "field": n.get("path", ""),
                "type": n.get("type", ""),
                "enum": [e["value"] for e in (n.get("enum") or [])] or None,
                "condition_text": extract_condition(desc),
                "source_doc": extract_source(desc),
                "description": desc,
            }

    out = {"_meta": {
        "description": "Conditional-required rule base (field-level C). Empty required_when means the condition cannot be auto-structured; confirm manually, do not fabricate.",
        "confidence": "confirmed=manually confirmed / inferred=AI extracted from description, to confirm / unresolved=condition is in an external doc, to fill",
        "generated_by": "python3 scripts/analyze_conditions.py",
    }, "fields": {}}
    for key in sorted(cond_fields):
        f = cond_fields[key]
        cond_text = f["condition_text"]
        when = to_when(cond_text, field_names_of(f["api"]))
        conf = "inferred" if cond_text else "unresolved"
        out["fields"][key] = {
            "api": f["api"],
            "apiTitle": f["apiTitle"],
            "field": f["field"],
            "type": f["type"],
            "enum": f["enum"],
            "required_when": when,
            "condition_text": cond_text,
            "source_doc": f["source_doc"],
            "confidence": conf,
            "description": f["description"],
        }

    with open(os.path.join(RULES_DIR, "field-conditions.yaml"), "w", encoding="utf-8") as fp:
        yaml.safe_dump(out, fp, allow_unicode=True, sort_keys=False, width=200)

    from collections import Counter
    conf = Counter(v["confidence"] for v in out["fields"].values())
    with_when = sum(1 for v in out["fields"].values() if v["required_when"])
    with_src = sum(1 for v in out["fields"].values() if v["source_doc"])
    print(f"Conditional-required field total: {len(out['fields'])}")
    print(f"confidence distribution: {dict(conf)}")
    print(f"structured required_when: {with_when}")
    print(f"referencing external doc (source_doc): {with_src}")
    docs = sorted({v["source_doc"] for v in out["fields"].values() if v["source_doc"]})
    print(f"\nReferenced external docs ({len(docs)}):")
    for d in docs:
        print(f"  - {d}")
    print(f"\nSkeleton written to {os.path.join(RULES_DIR, 'field-conditions.yaml')}")


def field_names_of(api):
    """Read the field-name set of an API from the KB on demand (for required_when validation)."""
    cache = getattr(field_names_of, "_cache", {})
    if api in cache:
        return cache[api]
    names = set()
    path = os.path.join(KB_DIR, "apis", f"{api}.json")
    if os.path.exists(path):
        d = json.load(open(path, encoding="utf-8"))
        for n in flatten(d.get("reqParams", [])):
            names.add(n.get("path", "").split(".")[-1])
    cache[api] = names
    return names


if __name__ == "__main__":
    main()
