#!/usr/bin/env python3
"""
gen_code.py — Generate sample code by call mode + field assembly.

Unlike the old version (which read sampleCodes scraped from the open platform — now unmaintained
and removed), this version uses templates distilled from the Feishu wiki "Test Examples"
(scripts/code_templates.py), picks the assembly mode by "method + contentType", and fills fields.

Call modes (mode_of):
  get_form    GET  + application/x-www-form-urlencoded -> addParameter / get
  post_json   POST + application/json                  -> setContent(jsonBody) / post_json
  post_form   POST + application/x-www-form-urlencoded -> addParameter / post
  multipart   POST + multipart/form-data               -> not covered by official docs; this script prompts for manual handling

Data source:
  kb/api-packs/{uri}.json  metadata + contentType + fields + required rules (read internally by resolve)

Field value source (priority):
  1. --values   field values confirmed by the customer (confirm each before generating code)
  2. --scene    enum values / direct values in the scene tags
  3. placeholder  unconfirmed fields use <XXX>, listed at the end as "pending"

Usage:
  # Step 1: output the field confirmation list, confirm each value with the customer
  python3 gen_code.py --api post__rest__v1.0__gpt__supplier__request --confirm

  # Step 2: generate code with confirmed values
  python3 gen_code.py --api post__rest__v1.0__gpt__supplier__request --lang python \
      --values "type=OVERSEAS_SUPPLIER,supplierType=ENTERPRISE,accountType=PRI,accountName=ABC Ltd"
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from resolve_fields import resolve  # noqa: E402
from code_templates import TEMPLATES, LANG_LABEL, mode_of  # noqa: E402

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACK_DIR = os.path.join(SKILL_DIR, "references", "kb", "api-packs")

LANGS = ["java", "csharp", "python", "php", "go"]


def parse_kv(s):
    """Parse "k=v,k2=v2" into a dict."""
    d = {}
    if not s:
        return d
    for kv in s.split(","):
        if "=" in kv:
            k, v = kv.split("=", 1)
            d[k.strip()] = v.strip()
    return d


def guess_value(field):
    """Placeholder value for unconfirmed fields: enums take the first value, others by name semantics."""
    name = field.get("name", "")
    if field.get("enum"):
        return field["enum"][0]["value"]
    n = name.lower()
    if n == "requestid" or "requestid" in n:
        return "<YOUR_REQUEST_ID>"
    if "merchantid" in n or "submerchantid" in n:
        return "<YOUR_MERCHANT_ID>"
    if "token" in n:
        return "<INQUIRY_TOKEN>"
    if "notifyurl" in n:
        return "https://your-domain.com/notify"
    if "amount" in n or "balance" in n:
        return "<AMOUNT>"
    if "currency" in n:
        return "<CURRENCY>"
    if "name" in n:
        return "<NAME>"
    if "url" in n or "path" in n or "file" in n:
        return "<FILE_PATH>"
    if "time" in n or "date" in n:
        return "2026-10-27"
    if "phone" in n or "mobile" in n:
        return "<PHONE>"
    if "email" in n:
        return "<EMAIL>"
    if "id" in n or n.endswith("no") or "number" in n:
        return "<ID>"
    if "code" in n:
        return "<CODE>"
    return "<VALUE>"


def field_value(field, values, scene):
    """Field value: customer confirmed > scene enum match > scene direct value > placeholder. Returns (value, confirmed)."""
    name = field.get("name", "")
    v = values.get(name)
    if v not in (None, ""):
        return v, True
    if field.get("enum"):
        for e in field["enum"]:
            if scene.get(name) == e.get("value"):
                return e["value"], True
    sv = scene.get(name)
    if sv not in (None, ""):
        return sv, True
    return guess_value(field), False


def camel(name):
    """Field name -> setter suffix: requestId -> RequestId, bankCode -> BankCode"""
    return name[:1].upper() + name[1:]


def _esc_quoted(s):
    """Escape backslashes and double quotes in a string literal (Java/C#/PHP/Go)."""
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _json_of(required, values, scene):
    """Required fields -> compact JSON string."""
    obj = {f["name"]: field_value(f, values, scene)[0] for f in required}
    return json.dumps(obj, ensure_ascii=False)


def build_body(lang, mode, required, optional, values, scene):
    """Generate @BODY@ (field assembly fragment) by language + mode. Returns (body, unconfirmed fields)."""
    lines = []
    unconfirmed = []

    def val(f):
        v, ok = field_value(f, values, scene)
        if not ok:
            unconfirmed.append(f["name"])
        return v

    if lang == "java":
        if mode == "post_json":
            body = _esc_quoted(_json_of(required, values, scene))
            for f in required:
                if not field_value(f, values, scene)[1]:
                    unconfirmed.append(f["name"])
            lines.append(f'        String jsonContent = "{body}";')
            lines.append("        request.setContent(jsonContent);")
        else:
            for f in required:
                lines.append(f'        request.addParameter("{f["name"]}", "{_esc_quoted(val(f))}");')
            for f in optional:
                lines.append(f'        // request.addParameter("{f["name"]}", "{_esc_quoted(guess_value(f))}");  // optional')

    elif lang == "csharp":
        if mode == "post_json":
            body = _esc_quoted(_json_of(required, values, scene))
            for f in required:
                if not field_value(f, values, scene)[1]:
                    unconfirmed.append(f["name"])
            lines.append(f'            string jsonBody = "{body}";')
            lines.append("            request.setContent(jsonBody);")
        else:
            for f in required:
                lines.append(f'            request.addParam("{f["name"]}", "{_esc_quoted(val(f))}");')
            for f in optional:
                lines.append(f'            // request.addParam("{f["name"]}", "{_esc_quoted(guess_value(f))}");  // optional')

    elif lang == "python":
        for f in required:
            lines.append(f'            {f["name"]!r}: {repr(val(f))},  # required')
        for f in optional:
            lines.append(f'            # {f["name"]!r}: {repr(guess_value(f))},  # optional')

    elif lang == "php":
        setter_target = "body" if mode == "post_json" else "request"
        for f in required:
            lines.append(f'${setter_target}->set{camel(f["name"])}("{_esc_quoted(val(f))}");')
        for f in optional:
            lines.append(f'// ${setter_target}->set{camel(f["name"])}("{_esc_quoted(guess_value(f))}");  // optional')

    elif lang == "go":
        if mode == "post_json":
            for f in required:
                lines.append(f'        "{f["name"]}": "{_esc_quoted(val(f))}",')
            for f in optional:
                lines.append(f'        // "{f["name"]}": "{_esc_quoted(guess_value(f))}",  // optional')
        else:
            for f in required:
                lines.append(f'    yopRequest.AddParam("{f["name"]}", "{_esc_quoted(val(f))}")')
            for f in optional:
                lines.append(f'    // yopRequest.AddParam("{f["name"]}", "{_esc_quoted(guess_value(f))}")  // optional')

    return "\n".join(lines), unconfirmed


def php_names(operation_id, path):
    """Derive PHP client method name / Request model / DTO model from operationId.

    operationId looks like gpt-all-product_gpt_supplierRequest;
    take the segment after the last `_gpt_` -> supplierRequest (client method),
    capitalize + Request -> SupplierRequestRequest, + DTO -> SupplierRequestDTO.
    The actual DTO class name follows the SDK generation (e.g. the official example uses SupplierReqDTO).
    """
    op = ""
    if operation_id:
        parts = operation_id.split("_gpt_")
        if len(parts) > 1:
            op = parts[-1]
    if not op:
        op = re.sub(r"[^A-Za-z0-9]", "", path.strip("/").split("/")[-1])
    model = (op[:1].upper() + op[1:]) + "Request"
    dto = (op[:1].upper() + op[1:]) + "DTO"
    return op, model, dto


def render(lang, mode, meta, required, optional, values, scene):
    """Fill the template, return (full code, unconfirmed fields)."""
    tpl = TEMPLATES[lang][mode]
    body, unconfirmed = build_body(lang, mode, required, optional, values, scene)
    replacements = {
        "@API_PATH@": meta.get("path", ""),
        "@METHOD@": meta.get("method", "POST"),
        "@BODY@": body,
        "@APP_KEY@": "<YOUR_APP_KEY>",
        "@PRI_KEY@": "<YOUR_PRIVATE_KEY>",
        "@YOP_PUBLIC_KEY@": "<YOP_PUBLIC_KEY>",
    }
    if lang == "php":
        op, model, dto = php_names(meta.get("operationId", ""), meta.get("path", ""))
        replacements["@MODEL@"] = model
        replacements["@DTO@"] = dto
        replacements["@CLIENT_METHOD@"] = op
    out = tpl
    for k, v in replacements.items():
        out = out.replace(k, v)
    return out, unconfirmed


def _fmt_field(n, show_condition=False):
    """Format a field as one line of the confirmation list (with newline)."""
    name = n.get("name", "")
    typ = n.get("type", "") or "string"
    desc = re.sub(r"\s+", " ", n.get("description", "") or "").strip()
    line = f'  - {name}  ({typ})'
    enum = n.get("enum")
    if enum:
        line += f'  options [ {"/".join(e["value"] for e in enum)} ]'
    if desc:
        line += f'  {desc[:40]}'
    out = [line]
    if show_condition:
        cond = n.get("required_when") or n.get("condition_text") or ""
        if cond:
            out.append(f'      trigger condition: {cond}')
    return "\n".join(out)


def print_confirm(pack, uri):
    """Output the field confirmation list: required + conditional fields, for the customer to confirm one by one."""
    title = pack.get("title", "")
    method = pack.get("method", "")
    path = pack.get("path", "")
    print(f"===== Field confirmation list: {title} ({method} {path}) =====\n")

    required, conditional = [], []
    for n in pack.get("reqParams", []):
        req = n.get("required", "O")
        if req == "M":
            required.append(n)
        elif req == "C":
            conditional.append(n)

    print("[Required fields] Confirm each value with the customer:")
    for n in required:
        print(_fmt_field(n))
    if conditional:
        print("\n[Conditional fields] Confirm whether they are triggered and what value to fill:")
        for n in conditional:
            print(_fmt_field(n, show_condition=True))

    print(f"\nAfter confirmation, pass the confirmed values via --values to generate code, e.g.:")
    sample = ",".join(f"{n.get('name','')}=..." for n in required[:3])
    print(f'  python3 gen_code.py --api {uri} --lang python --values "{sample}"')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", required=True)
    ap.add_argument("--lang", default="python", choices=LANGS + ["all"])
    ap.add_argument("--scene", default="", help="Scene tags, e.g. clearingType=LOCAL,bankCountry=BR")
    ap.add_argument("--values", default="", help="Confirmed field values, e.g. accountType=PRI,accountName=ABC Ltd")
    ap.add_argument("--confirm", action="store_true", help="Only output the field confirmation list, no code")
    args = ap.parse_args()

    scene = parse_kv(args.scene)
    values = parse_kv(args.values)

    pack = json.load(open(os.path.join(PACK_DIR, f"{args.api}.json"), encoding="utf-8"))

    if args.confirm:
        print_confirm(pack, args.api)
        return

    result = resolve(args.api, scene)
    if "error" in result:
        sys.exit(result["error"])

    mode = mode_of(result["method"], pack.get("contentType", ""))
    langs = LANGS if args.lang == "all" else [args.lang]

    print(f"===== {result['title']}  {result['method']} {result['path']} =====")
    print(f"Content-Type: {pack.get('contentType') or '(unknown)'}  -> call mode: {mode}")
    if scene:
        print(f"Scene: {scene}")
    if values:
        print(f"Confirmed field values: {len(values)}")
    print(f"required {len(result['required'])} | optional {len(result['optional'])} | condition pending {len(result['unresolved'])}\n")

    if result["unresolved"]:
        print(f"⚠️ {len(result['unresolved'])} conditional field(s) cannot be auto-resolved (confirm with the customer):")
        for f in result["unresolved"][:10]:
            src = f" source: {f['source_doc']}" if f.get("source_doc") else ""
            print(f'  - {f["name"]}{src}')
        print()

    if mode == "multipart":
        print("=" * 60)
        print("⚠️ This API is multipart/form-data (file upload), not covered by the official new examples.")
        print("   Write it manually using the YOP SDK file upload capability (addFile / multipart),")
        print("   or confirm the standard SDK file-upload call with engineering.")
        print(f"   Fields: {', '.join(f['name'] for f in result['required'])}")
        return

    meta = dict(result)
    meta["operationId"] = pack.get("operationId", "")

    all_unconfirmed = set()
    for lang in langs:
        print("=" * 60)
        print(f"{LANG_LABEL[lang]} code\n")
        code, unconfirmed = render(lang, mode, meta, result["required"], result["optional"], values, scene)
        print(code)
        all_unconfirmed.update(unconfirmed)

    if all_unconfirmed:
        print("=" * 60)
        print(f"⚠️ The following {len(all_unconfirmed)} required field(s) have unconfirmed values (placeholders used); confirm with the customer and replace:")
        print("  " + ", ".join(sorted(all_unconfirmed)))


if __name__ == "__main__":
    main()
