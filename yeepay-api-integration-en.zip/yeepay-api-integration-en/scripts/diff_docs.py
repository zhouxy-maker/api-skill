#!/usr/bin/env python3
"""
diff_docs.py — Change monitoring: re-fetch the open platform docs, diff against the snapshot, output a change report.

Usage:
  python3 diff_docs.py            # fetch and output the change report
  python3 diff_docs.py --check    # compare only (no fetch), current manifest vs last snapshot

How it works: every fetch_docs.py run writes kb/.snapshot/manifest.json (md5 per API).
This script backs up the old manifest, re-fetches, then diffs to output a three-level report: added/removed/field-changed.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SNAP_DIR = os.path.join(SKILL_DIR, "references", "kb", ".snapshot")
MANIFEST = os.path.join(SNAP_DIR, "manifest.json")


def find_python():
    """Prefer the python with pyyaml."""
    for p in (
        "/Users/c0259/.workbuddy/binaries/python/envs/default/bin/python3",
        "/usr/bin/python3",
    ):
        if os.path.exists(p):
            return p
    return sys.executable


def load_manifest(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"apis": {}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="Compare only, do not re-fetch")
    args = ap.parse_args()

    old = load_manifest(MANIFEST)
    if not args.check:
        print("[diff] Re-fetching docs...", file=sys.stderr)
        py = find_python()
        r = subprocess.run([py, os.path.join(SKILL_DIR, "scripts", "fetch_docs.py")],
                           capture_output=True, text=True)
        if r.returncode != 0:
            print("[diff] Fetch failed: ", r.stderr[-500:], file=sys.stderr)
            sys.exit(1)

    new = load_manifest(MANIFEST)
    old_apis, new_apis = old.get("apis", {}), new.get("apis", {})

    added = {k: v for k, v in new_apis.items() if k not in old_apis}
    removed = {k: v for k, v in old_apis.items() if k not in new_apis}
    changed = {k: (old_apis[k], new_apis[k])
               for k in old_apis if k in new_apis and old_apis[k].get("md5") != new_apis[k].get("md5")}

    print("\n===== Doc change report =====")
    print(f"Last: {old.get('fetchedAt', 'none')}  This: {new.get('fetchedAt', 'none')}")
    print(f"API total: {len(old_apis)} -> {len(new_apis)}")
    print(f"Added: {len(added)} | Removed: {len(removed)} | Changed: {len(changed)}")

    for k, v in added.items():
        print(f"  [Added] {v.get('title', k)}  {v.get('method')} {v.get('path')}")
    for k, v in removed.items():
        print(f"  [Removed] {v.get('title', k)}  {v.get('method')} {v.get('path')}")
    for k, (o, n) in changed.items():
        print(f"  [Changed] {n.get('title', k)}  {n.get('method')} {n.get('path')}")
    if not (added or removed or changed):
        print("  No changes")

    if changed:
        print("\nField diff of changed APIs can be viewed via:")
        print("  python3 scripts/fetch_docs.py --only <uri>, then diff kb/apis/<uri>.json")


if __name__ == "__main__":
    main()
