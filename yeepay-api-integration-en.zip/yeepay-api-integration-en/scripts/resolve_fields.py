#!/usr/bin/env python3
"""
resolve_fields.py — Scene tags -> required-field solver.

Input: API uri + scene tags (scene_tags, e.g. clearingType=LOCAL,bankCountry=BR)
Output: the API's required / optional / condition-pending field lists.

Data source: kb/api-packs/{uri}.json (Q&A pack; fields carry required + conditional rules,
derived by build_index.py from kb/apis + field-conditions.yaml; no need to re-read big lists).

Judgment logic:
  - required == M -> required
  - required == O -> optional
  - required == C -> check the field's required_when:
      * has required_when and scene matches -> required
      * has required_when and scene does not match -> optional (not triggered here)
      * no required_when (unresolved) -> "condition pending", with condition_text / source_doc

Usage:
  python3 resolve_fields.py --api post__rest__v1.0__gpt__supplier__request \
      --scene clearingType=LOCAL,bankCountry=BR,paymentType=PIX
"""
import argparse
import json
import os
import re

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACK_DIR = os.path.join(SKILL_DIR, "references", "kb", "api-packs")


def eval_when(when, scene):
    """Safely evaluate a required_when expression (only supports field=="VALUE" joined by &&)."""
    if not when:
        return False
    for clause in when.split("&&"):
        m = re.match(r'^\s*(\w+)\s*==\s*"([^"]+)"\s*$', clause)
        if not m:
            return False
        if scene.get(m.group(1)) != m.group(2):
            return False
    return True


def resolve(uri, scene):
    pack_path = os.path.join(PACK_DIR, f"{uri}.json")
    if not os.path.exists(pack_path):
        return {"error": f"API {uri} is not in the knowledge base; run fetch_docs.py then build_index.py first"}

    pack = json.load(open(pack_path, encoding="utf-8"))

    result = {"api": uri, "title": pack.get("title"), "method": pack.get("method"),
              "path": pack.get("path"), "scene": scene,
              "required": [], "optional": [], "unresolved": []}

    for n in pack.get("reqParams", []):
        field = {
            "name": n.get("name", ""),
            "title": n.get("title", ""),
            "type": n.get("type", ""),
            "maxLength": n.get("maxLength", ""),
            "example": n.get("example", ""),
            "enum": n.get("enum"),
            "description": n.get("description", ""),
        }
        req = n.get("required", "O")
        if req == "M":
            result["required"].append(field)
        elif req == "O":
            result["optional"].append(field)
        else:  # C
            when = n.get("required_when")
            if when and eval_when(when, scene):
                result["required"].append(field)
            elif when:
                result["optional"].append(field)
            else:
                field["condition_text"] = n.get("condition_text")
                field["source_doc"] = n.get("source_doc")
                field["confidence"] = n.get("confidence")
                result["unresolved"].append(field)
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", required=True)
    ap.add_argument("--scene", default="", help="Scene tags, e.g. clearingType=LOCAL,bankCountry=BR,paymentType=PIX")
    args = ap.parse_args()
    scene = {}
    if args.scene:
        for kv in args.scene.split(","):
            if "=" in kv:
                k, v = kv.split("=", 1)
                scene[k.strip()] = v.strip()
    out = resolve(args.api, scene)
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
