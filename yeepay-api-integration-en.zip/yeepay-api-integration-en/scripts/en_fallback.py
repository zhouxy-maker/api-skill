#!/usr/bin/env python3
"""
en_fallback.py — English fallback patch for the Yeepay International API knowledge base.

The official English source (open.gptransfer.hk `_en_US` JSON) still contains some
Chinese residue. This is an official-source gap, not a local bug:

  1. `errcode.innerSolution` is left in Chinese, even though each entry's
     `subErrorMsg` already carries the official English translation.
  2. A few field `title` / `description` / `enum` labels / `example` values are in Chinese.
  3. A handful of `errcode.subErrorMsg` / `outerSolution` strings have Chinese
     translator notes mixed in (e.g. "The收款账号 has not passed the review").
  4. The inbound-notification SPI (`references/kb/spis/*.json`) was rendered from the
     Chinese solution page and is fully Chinese.

This script patches the DERIVED knowledge base (`references/kb/apis/*.json` and
`references/kb/spis/*.json`) into full English, while the raw snapshot
(`references/kb/.snapshot/raw`) keeps the official text untouched.

Run order (after any re-fetch):

  python3 scripts/fetch_docs.py
  python3 scripts/en_fallback.py            # <-- this script
  python3 scripts/analyze_field_required.py
  python3 scripts/build_index.py
"""
import glob
import json
import os
import re
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_DIR = os.path.join(SKILL_DIR, "references", "kb")
APIS_DIR = os.path.join(KB_DIR, "apis")
SPIS_DIR = os.path.join(KB_DIR, "spis")

_ZH = re.compile(r"[\u4e00-\u9fff]")


def has_zh(s):
    return bool(s) and bool(_ZH.search(s))


def log(msg):
    print(f"[en-fallback] {msg}", file=sys.stderr)


# ---------------------------------------------------------------------------
# Exact-match translations (whole-string values: title / name / description /
# enum label). Applied only when the value matches the key exactly.
# ---------------------------------------------------------------------------
EXACT_MAP = {
    # --- field titles ---
    "询价过期时间，单位秒": "Inquiry expiry time, in seconds",
    "子商户商户编号": "Sub-merchant number",
    "汇款费用收取方式": "Remittance fee collection method",
    # --- field descriptions (simple) ---
    "子商户商户编号，以子商户身份发起时填写": "Sub-merchant number; filled when initiating as a sub-merchant",
    # --- enum labels ---
    "内扣（手续费从付款金额哪扣取），定额到账不支持内扣手续费":
        "Fee deducted from the payout amount; fixed-amount credit does not support deducted fees",
    "外扣（手续费从账户余额内扣取）":
        "Fee deducted from the account balance",
    # --- SPI: inbound notification ---
    "来账商户通知": "Incoming Funds Notification",
    "收款账户商编": "Collecting account merchant number",
    "收款记录ID": "Collection record ID",
    "请求号": "Request number",
    "事件类型": "Event type",
    "银行来账流水号": "Bank incoming transaction serial number",
    "订单类型": "Order type",
    "入账金额": "Credit amount",
    "入账币种": "Credit currency",
    "付款金额": "Payment amount",
    "付款币种": "Payment currency",
    "汇率": "Exchange rate",
    "手续费金额": "Fee amount",
    "手续费币种": "Fee currency",
    "付款方名称": "Payer name",
    "付款方账号": "Payer account",
    "付款方银行SWIFT Code": "Payer bank SWIFT code",
    "付款方银行名称": "Payer bank name",
    "来账时间": "Incoming funds time",
    "收款账户账号": "Collecting account number",
    "汇款附言": "Remittance remarks",
    "关联请求号": "Related request number",
    "关联交易订单": "Related transaction order",
    "驳回原因": "Rejection reason",
    "退款信息": "Refund information",
    # --- SPI: enum labels ---
    "需要补充资料": "Supplementary information required",
    "平台收款需要补充资料": "Platform collection requires supplementary information",
    "需要关联交易单": "Transaction order matching required",
    "审核驳回": "Review rejected",
    "入账成功": "Credit successful",
    "入账后置审核成功": "Post-credit review successful",
    "入账后置审核失败": "Post-credit review failed",
    "入账失败": "Credit failed",
    "退款处理中": "Refund in progress",
    "退款已汇出": "Refund remitted",
    "充值": "Top-up",
    "贸易收款": "Trade collection",
    "平台收款": "Platform collection",
    # --- SPI: short descriptions ---
    "本次被驳回的关联请求号": "Related request number rejected this time",
    "本次收款关联的关联订单集合": "The set of related orders associated with this collection",
    "eventCode为35、40时非空": "Non-empty when eventCode is 35 or 40",
    # --- SPI: nested children (Related transaction order) ---
    "交易订单号": "Transaction order number",
    "关联金额": "Related amount",
    "交易订单审核状态": "Transaction order review status",
    "可修改信息类型": "Modifiable information type",
    "处理中": "In progress",
    "通过": "Approved",
    "驳回": "Rejected",
    "不可修改": "Not modifiable",
    "补充资料": "Supplementary information",
    "全量修改": "Full modification",
    "补充材料是指可追加otherFiles和contractFiles信息；全量修改是指所有交易订单字段可修改":
        "Supplementary information means otherFiles and contractFiles can be appended; "
        "full modification means all transaction order fields can be modified",
    # --- SPI: nested children (Rejection reason) ---
    "驳回原因代码": "Rejection reason code",
    "驳回原因代码文字说明": "Rejection reason code description",
    "具体原因描述": "Specific reason description",
    "订单关联有误": "Order association error",
    "订单信息/材料有误": "Order information/material error",
    "需补充材料": "Supplementary materials required",
    "没有驳回（没有选驳回原因时返回此值）": "No rejection (returned when no rejection reason is selected)",
    # --- SPI: nested children (Refund information) ---
    "退款请求号": "Refund request number",
    "退款订单号": "Refund order number",
    "退款状态": "Refund status",
    "退款汇出": "Refund remitted",
    "退款方式": "Refund method",
    "原路退款": "Refund to original account",
    "退款金额": "Refund amount",
    "退款币种": "Refund currency",
    "退款手续费": "Refund fee",
    "退款手续费币种": "Refund fee currency",
    "退款的收款账户": "Refund collecting account",
    "退款的收款账户名称": "Refund collecting account name",
    "退款发起时间": "Refund initiation time",
    "退款完成时间": "Refund completion time",
    # --- SPI: conditions ---
    "status=SUCCESS时非空": "Non-empty when status=SUCCESS",
}

# ---------------------------------------------------------------------------
# Substring translations (longest-key-first). Used for composite values such as
# the exchange-rate enum description and the JSON example placeholders.
# ---------------------------------------------------------------------------
SUBSTR_MAP = {
    # exchange-rate validity enum items
    "汇率有效期2分钟": "exchange rate valid for 2 minutes",
    "汇率有效期5分钟": "exchange rate valid for 5 minutes",
    "汇率有效期30分钟": "exchange rate valid for 30 minutes",
    "汇率有效期1小时": "exchange rate valid for 1 hour",
    "汇率有效期2小时": "exchange rate valid for 2 hours",
    "汇率有效期3小时": "exchange rate valid for 3 hours",
    "汇率有效期6小时": "exchange rate valid for 6 hours",
    # fee-collection mode description
    "汇款费用（系统手续费）收取方式": "Remittance fee (system service fee) collection method",
    "可选项如下": "Options",
    "外扣（手续费从账户余额内扣取）": " fee deducted from the account balance",
    "内扣（手续费从付款金额哪扣取），定额到账不支持内扣手续费":
        " fee deducted from the payout amount; fixed-amount credit does not support deducted fees",
    # example placeholders
    "示例值：": "Example: ",
    "法人证件生效日期": "legal person ID effective date",
    "法人证件失效日期": "legal person ID expiry date",
    "法人联系手机号": "legal person contact phone number",
    "法人证件类型": "legal person ID type",
    "股东证件号码": "shareholder ID number",
    "股东证件类型": "shareholder ID type",
    "银行卡账户名称": "bank account name",
    "银行分支行名称": "bank branch name",
    "营业执照图片路径(必传)": "business license image path (required)",
    "身份证正面图片路径(必传)": "ID card front image path (required)",
    "身份证背面图片路(必传)": "ID card back image path (required)",
    "法人名称": "legal person name",
    "股东名称": "shareholder name",
    "银行卡号": "bank card number",
    "银行所在省": "bank province",
    "银行所在市": "bank city",
    "银行名称": "bank name",
    "其他文件路径": "other file path",
    "医疗器械": "medical devices",
    # inline Chinese terms inside otherwise-English errcode strings
    "收款账号": "receiving account",
    "The收款账号": "The receiving account",
    "校验失败": "",
}

# The inbound-notification "event type" field description is a long Chinese
# paragraph listing 10 return codes. It is matched by feature (contains "返回10")
# rather than by an exact copy of the whole paragraph, then replaced wholesale.
SPI_EVENT_DESC_EN = (
    "1. Returns 10: call the \"Top-up Supplementary Information\" API to submit materials "
    "and complete the credit review. 2. Returns 13: call the \"Platform Collection "
    "Supplementary Information\" API to submit materials and complete the credit review. "
    "3. Returns 15: call the \"Create/Update Contract Order\" API to submit materials and "
    "complete the credit review. 4. Returns 17: revise according to the review comments and "
    "resubmit; the call logic is the same as the first submission. (1) For top-up "
    "supplementary materials: after revising, the merchant resubmits through the \"Top-up "
    "Supplementary Information\" API based on the original application, without creating a "
    "new application. (2) For trade collection: after revising, the merchant resubmits "
    "through the \"Create/Update Contract Order\" API based on the original application, "
    "without creating a new application; alternatively, a new order can be created and "
    "re-matched through the \"Collection Record Contract Order Matching\" API. (3) For "
    "platform collection: after revising, the merchant resubmits through the \"Platform "
    "Collection Supplementary Information\" API based on the original application, without "
    "creating a new application. 5. Returns 20: credit successful; call the \"Query "
    "Collection Record\" API to query the collection details. 6. Returns 30: credit failed "
    "and cannot be credited; Yeepay International will initiate a refund process. 7. Returns "
    "35: the refund request has been received and the refund is being processed. 8. Returns "
    "40: the refund has been successfully remitted; the arrival time depends on the payment "
    "channel, so please monitor the relevant account information. 9. Returns 21: the "
    "settlement quota has increased; settlement can be performed based on the corresponding "
    "contract order. 10. Returns 22: the settlement quota increase failed; per the review "
    "comments, call the \"Create/Update Contract Order\" API to create or update the trade "
    "contract, then call the \"Collection Record Contract Order Matching\" API to "
    "re-associate the contract and complete the review."
)

# Precise English fix for errcode entries whose subErrorMsg itself starts with
# Chinese (the generic note-stripper would leave a stray leading colon).
ERRCODE_SUB_FIX = {
    "G06200": "Request number is duplicated.",
}


def translate_text(s):
    """Translate a Chinese-bearing string using EXACT_MAP then SUBSTR_MAP."""
    if not s or not has_zh(s):
        return s
    # long event-type description (SPI): replace wholesale by feature detection
    if "返回10" in s and len(s) > 200:
        return SPI_EVENT_DESC_EN
    if s in EXACT_MAP:
        return EXACT_MAP[s]
    for k in sorted(SUBSTR_MAP, key=len, reverse=True):
        s = s.replace(k, SUBSTR_MAP[k])
    return s


def strip_zh_notes(s):
    """Clean Chinese translator notes out of a mostly-English errcode string.

    Handles three patterns seen in the official source:
      - full-width parenthetical notes: （这里...）
      - half-width parenthetical notes containing Chinese: (...收款账号...)
      - whole lines that are Chinese notes (translation discussion)
    Then maps known inline Chinese terms via SUBSTR_MAP and drops any remainder.
    """
    if not s:
        return s
    # remove full-width parenthetical notes
    s = re.sub(r"（[^）]*）", "", s)
    # remove half-width parenthetical notes that contain Chinese
    s = re.sub(r"\([^()]*[\u4e00-\u9fff][^()]*\)", "", s)
    # drop lines that are mostly Chinese notes
    kept = []
    for ln in s.split("\n"):
        zh_n = len(_ZH.findall(ln))
        ascii_n = len(re.findall(r"[A-Za-z]", ln))
        if zh_n == 0 or ascii_n > zh_n:
            kept.append(ln)
    s = "\n".join(kept)
    # map known inline Chinese terms, then drop any remaining Chinese
    s = translate_text(s)
    s = _ZH.sub("", s)
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r" ?: ?", ": ", s)
    s = re.sub(r"\s+([.,;:!?])", r"\1", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def patch_errcodes(errcodes):
    """Fill Chinese innerSolution with the official English subErrorMsg and clean notes."""
    changed = 0
    for e in errcodes:
        if not isinstance(e, dict):
            continue
        code = e.get("subErrorCode") or ""
        inner = e.get("innerSolution") or ""
        sub = e.get("subErrorMsg") or ""
        outer = e.get("outerSolution") or ""
        # precise fix for entries whose subErrorMsg starts with Chinese (the
        # generic note-stripper would leave a stray leading colon)
        if code in ERRCODE_SUB_FIX and has_zh(sub):
            e["subErrorMsg"] = ERRCODE_SUB_FIX[code]
            sub = e["subErrorMsg"]
            changed += 1
        if has_zh(inner):
            if sub and not has_zh(sub):
                e["innerSolution"] = sub
            elif outer and not has_zh(outer):
                e["innerSolution"] = strip_zh_notes(outer)
            else:
                e["innerSolution"] = strip_zh_notes(inner)
            changed += 1
        if has_zh(sub):
            e["subErrorMsg"] = strip_zh_notes(sub)
        if has_zh(outer):
            e["outerSolution"] = strip_zh_notes(outer)
    return changed


def patch_field_node(node):
    """Translate a single field node's Chinese-bearing text values (in place)."""
    changed = 0
    for k in ("title", "description"):
        v = node.get(k) or ""
        if has_zh(v):
            node[k] = translate_text(v)
            changed += 1
    example = node.get("example") or ""
    if has_zh(example):
        node["example"] = translate_text(example)
        changed += 1
    enum = node.get("enum") or []
    for it in enum:
        if isinstance(it, dict) and has_zh(it.get("label") or ""):
            it["label"] = translate_text(it["label"])
            changed += 1
    return changed


def patch_field_tree(nodes):
    """Recursively patch a field tree (reqParams / respParams)."""
    changed = 0
    for n in nodes or []:
        if isinstance(n, dict):
            changed += patch_field_node(n)
            changed += patch_field_tree(n.get("children") or [])
    return changed


def patch_api_file(path):
    """Patch one kb/apis/*.json file. Returns (errcode_changes, field_changes)."""
    with open(path, encoding="utf-8") as f:
        api = json.load(f)
    ec = patch_errcodes(api.get("errcodes") or [])
    fc = patch_field_tree(api.get("reqParams") or [])
    fc += patch_field_tree(api.get("respParams") or [])
    if has_zh(api.get("desc") or ""):
        api["desc"] = translate_text(api["desc"])
        fc += 1
    if ec or fc:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(api, f, ensure_ascii=False, indent=2)
    return ec, fc


def _patch_spi_node(node, changed):
    """Recursively translate one SPI field node (and its children)."""
    if not isinstance(node, dict):
        return changed
    for k in ("name", "title", "description", "condition"):
        if has_zh(node.get(k) or ""):
            node[k] = translate_text(node[k])
            changed += 1
    for it in node.get("enum") or []:
        if isinstance(it, dict) and has_zh(it.get("label") or ""):
            it["label"] = translate_text(it["label"])
            changed += 1
    for child in node.get("children") or []:
        changed = _patch_spi_node(child, changed)
    return changed


def patch_spi_file(path):
    """Patch one kb/spis/*.json file. Returns number of changed values."""
    with open(path, encoding="utf-8") as f:
        spi = json.load(f)
    changed = 0
    if has_zh(spi.get("title") or ""):
        spi["title"] = translate_text(spi["title"])
        changed += 1
    for fld in spi.get("fields") or []:
        changed = _patch_spi_node(fld, changed)
    if changed:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(spi, f, ensure_ascii=False, indent=2)
    return changed


def main():
    api_files = sorted(glob.glob(os.path.join(APIS_DIR, "*.json")))
    spi_files = sorted(glob.glob(os.path.join(SPIS_DIR, "*.json")))

    tot_ec = tot_fc = 0
    for path in api_files:
        ec, fc = patch_api_file(path)
        tot_ec += ec
        tot_fc += fc

    tot_spi = 0
    for path in spi_files:
        tot_spi += patch_spi_file(path)

    log(f"patched {len(api_files)} api files: "
        f"{tot_ec} errcode innerSolution + {tot_fc} field values")
    log(f"patched {len(spi_files)} spi files: {tot_spi} values")

    # verify no Chinese remains in the derived KB
    remain = []
    for path in api_files + spi_files:
        txt = open(path, encoding="utf-8").read()
        if has_zh(txt):
            remain.append(path)
    if remain:
        log(f"⚠️ Chinese still remains in: {remain}")
    else:
        log("✅ derived KB is now fully English")


if __name__ == "__main__":
    main()
