#!/usr/bin/env python3
"""
build_supplier_elements.py — Parse the local xlsx "Beneficiary Registration Requirements" and split it into per-country files.

Source: 收款方报备要素说明.xlsx (4 sheets: 整体说明 / 收款方报备要素 / IDN-印尼省份城市清单 / 银行名称)
Output: under references/external/supplier/
  - meta.yaml           field enums + value notes (generic)
  - index.yaml          bankCountry -> file/currency/clearing/field-count (look up this first)
  - {COUNTRY}.yaml      per-country required fields (2~7K, with format validators/enums/M-O)
  - idn-provinces.yaml  34 Indonesian provinces
  - idn-cities.yaml     520 Indonesian cities
  - bank-list.yaml      bank names covering 36 countries (full list via supplier__banklist API)

Data notes:
  - The "银行所在国家/地区" (bank country) column has a merged cell: 36 European countries share one
    field set (EUR/LOCAL), normalized into the EU_EUR_LOCAL group (with a countries list).
  - Indonesian province/city enum values are deduplicated into references.

Usage:
  python3 build_supplier_elements.py [xlsx_path]
"""
import os
import shutil
import sys

XLSX_DEFAULT = "/Users/c0259/Downloads/收款方报备要素说明.xlsx"
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(SKILL_DIR, "references", "external", "supplier")


def main():
    xlsx = sys.argv[1] if len(sys.argv) > 1 else XLSX_DEFAULT
    if not os.path.exists(xlsx):
        sys.exit(f"Source file not found: {xlsx}")

    try:
        import openpyxl
        import yaml
    except ImportError as e:
        sys.exit(f"Missing dependency: {e}")

    wb = openpyxl.load_workbook(xlsx, data_only=True)

    # 1) 整体说明 -> field_enums + other_note
    ws0 = wb["整体说明"]
    field_enums = {}
    for r in range(2, ws0.max_row + 1):
        key = ws0.cell(r, 1).value
        val = ws0.cell(r, 2).value
        if key and str(key).strip():
            field_enums[str(key).strip()] = val if val is not None else ""
    other_note = (ws0.cell(1, 5).value or "").strip()

    # 2) 收款方报备要素 -> elements（按 bankCountry 分组）
    ws = wb["收款方报备要素"]
    groups = {}
    order = []
    for r in range(3, ws.max_row + 1):
        param = ws.cell(r, 8).value
        if param is None or str(param).strip() == "":
            continue
        bc_raw = (ws.cell(r, 4).value or "").strip()
        if "\n" in bc_raw:
            key = "EU_EUR_LOCAL"
            countries = [c.strip() for c in bc_raw.split("\n") if c.strip()]
        else:
            key = bc_raw
            countries = None
        if key not in groups:
            groups[key] = {"currency": "", "clearing": "", "fields": []}
            order.append(key)
            if countries:
                groups[key]["countries"] = countries
                groups[key]["note"] = "Source merged cell: the following 36 European countries/regions share one field set (EUR/LOCAL local clearing)"
        g = groups[key]
        cur = (ws.cell(r, 5).value or "").strip()
        clr = (ws.cell(r, 7).value or "").strip()
        if cur and not g["currency"]:
            g["currency"] = cur
        if clr and not g["clearing"]:
            g["clearing"] = clr
        g["fields"].append({
            "param": str(param).strip(),
            "title": (ws.cell(r, 9).value or "").strip(),
            "account_type": (ws.cell(r, 6).value or "").strip(),
            "required": (ws.cell(r, 10).value or "").strip(),
            "validators": ws.cell(r, 11).value if ws.cell(r, 11).value is not None else "",
            "scope": (ws.cell(r, 12).value or "").strip(),
            "remark": (ws.cell(r, 13).value or "").strip(),
        })

    # 3) IDN 省份城市
    ws2 = wb["IDN-印尼省份城市清单"]
    idn_provinces, idn_cities = [], []
    for r in range(2, ws2.max_row + 1):
        pc = ws2.cell(r, 1).value
        pn = ws2.cell(r, 2).value
        if pc is not None and str(pc).strip():
            idn_provinces.append({"province_code": str(int(pc)), "name": str(pn).strip()})
        cc = ws2.cell(r, 3).value
        cn = ws2.cell(r, 4).value
        if cc is not None and str(cc).strip():
            idn_cities.append({"province_code": str(int(cc)), "city": str(cn).strip()})

    # 4) 银行名称
    ws3 = wb["银行名称"]
    bank_countries = []
    for r in range(1, ws3.max_row + 1):
        v = ws3.cell(r, 1).value
        if v is None:
            continue
        s = str(v).strip()
        if s and s != "国家" and s not in bank_countries:
            bank_countries.append(s)
    bank_note = (ws3.cell(1, 4).value or "").strip()
    bank_total = ws3.max_row - 1

    # 切分输出
    if os.path.exists(OUT_DIR):
        shutil.rmtree(OUT_DIR)
    os.makedirs(OUT_DIR, exist_ok=True)

    def dump(obj, path):
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(obj, f, allow_unicode=True, sort_keys=False,
                           default_flow_style=False, width=10000)

    dump({"source": os.path.basename(xlsx), "field_enums": field_enums, "other_note": other_note},
         os.path.join(OUT_DIR, "meta.yaml"))

    index = {}
    for key in order:
        g = groups[key]
        for f in g.get("fields", []):
            if key == "ID" and f.get("param") == "province":
                f["scope"] = "Indonesian province enum, see supplier/idn-provinces.yaml"
            if key == "ID" and f.get("param") == "city":
                f["scope"] = "Indonesian city enum, see supplier/idn-cities.yaml"
        fname = f"supplier/{key}.yaml"
        dump(g, os.path.join(OUT_DIR, f"{key}.yaml"))
        entry = {"file": fname, "currency": g.get("currency", ""),
                 "clearing": g.get("clearing", ""), "fields": len(g.get("fields", []))}
        if "countries" in g:
            entry["countries"] = g["countries"]
        index[key] = entry

    dump({"idn_provinces": idn_provinces}, os.path.join(OUT_DIR, "idn-provinces.yaml"))
    dump({"idn_cities": idn_cities}, os.path.join(OUT_DIR, "idn-cities.yaml"))
    dump({"bank_list": {"note": bank_note, "countries": bank_countries,
                        "full_list": f"This list has {bank_total} bank-name rows, not expanded; query in real time via the supplier__banklist API"}},
         os.path.join(OUT_DIR, "bank-list.yaml"))
    dump({"note": "Beneficiary registration elements split by bankCountry; to query a country's elements, look up this index first, then read supplier/{COUNTRY}.yaml",
          "groups": index}, os.path.join(OUT_DIR, "index.yaml"))

    print(f"Generated {len(order)} country groups into {OUT_DIR}")


if __name__ == "__main__":
    main()
