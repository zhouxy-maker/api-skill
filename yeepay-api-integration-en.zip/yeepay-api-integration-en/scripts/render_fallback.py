#!/usr/bin/env python3
"""
render_fallback.py — Headless-browser rendering fallback, for open-platform "solution doc pages"
(pages not in the API tree).

When to use: links in the standard solution doc like /docs/solutions/apidoc/{solutionId}/{docId}
(e.g. the "Incoming Funds Notification" callback) are NOT in apis/tree.json and their JSON paths
return 403, so we must render the DOM with a headless browser and parse the table.

Usage:
  # render directly (requires Chrome installed locally)
  python3 render_fallback.py --url https://open.gptransfer.hk/docs/solutions/apidoc/693becdc7d2c7d0001a23a09/693bed203b0a750001efa619 --name gpt.inbound-notify --title "Incoming Funds Notification"

  # skip rendering, parse an existing HTML file (offline / reuse rendered result)
  python3 render_fallback.py --html /tmp/rendered.html --name gpt.inbound-notify --title "Incoming Funds Notification"
"""
import argparse
import html as _html
import json
import os
import re
import subprocess
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPIS_DIR = os.path.join(SKILL_DIR, "references", "kb", "spis")


def log(msg):
    print(f"[render] {msg}", file=sys.stderr)


def find_chrome():
    for p in (
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
    ):
        if os.path.exists(p):
            return p
    return None


def render_url(url, out_html):
    chrome = find_chrome()
    if not chrome:
        raise SystemExit("Chrome not found; install Chrome or pass --html with an already-rendered HTML file")
    cmd = [
        chrome, "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
        "--disable-default-apps", "--disable-sync", "--metrics-recording-only",
        "--user-data-dir=/tmp/yop-render-profile", "--virtual-time-budget=20000", "--dump-dom", url,
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    with open(out_html, "w", encoding="utf-8") as f:
        f.write(r.stdout)
    if len(r.stdout) < 5000:
        log("⚠️ Rendered result is too short; the page may not have fully loaded")
    return out_html


def strip_tags(s):
    s = re.sub(r"<br\s*/?>", "\n", s)
    s = re.sub(r"</p>", "\n", s)
    s = re.sub(r"<[^>]+>", "", s)
    return _html.unescape(s).strip()


def cell_text(td):
    return re.sub(r"\s+", " ", strip_tags(td)).strip()


def parse_type(cell):
    """'String(32)' -> ('string', '32'); 'BigDecimal' -> ('BigDecimal', '')."""
    c = cell_text(cell)
    m = re.match(r"^(\w+)[（(]([^）)]*)[）)]$", c)
    if m:
        return m.group(1), m.group(2)
    return c, ""


def parse_required(cell):
    """'C(status=SUCCESS, non-empty)' -> ('C', 'status=SUCCESS, non-empty'); 'M' -> ('M', '')."""
    c = cell_text(cell)
    m = re.match(r"^([MOC])(?:[（(](.*?)[）)])?$", c)
    if m:
        return m.group(1), (m.group(2) or "").strip()
    return (c, "") if c else ("", "")


def parse_enum(cell):
    """Split multi-format enums ('VALUE : label' / 'VALUE-label' / 'VALUE  label' / '10: numeric label').

    Uses a "locate VALUE boundary" approach: find all candidate values (uppercase+underscore tokens
    or digits), and the text between two adjacent values is the previous value's label.
    """
    c = cell_text(cell)
    if not c:
        return None
    marks = [(m.start(), m.group()) for m in re.finditer(r"[A-Z][A-Z0-9_]{1,40}|\d{1,2}", c)]
    if not marks:
        return None
    pairs = []
    for i, (pos, val) in enumerate(marks):
        if val in ("GET", "POST", "API", "SDK"):
            continue
        end = marks[i + 1][0] if i + 1 < len(marks) else len(c)
        label = c[pos + len(val):end].strip()
        label = re.sub(r"^[:：\-—]\s*", "", label).strip()
        pairs.append((val, label))
    seen, out = set(), []
    for v, lab in pairs:
        if v in seen:
            continue
        seen.add(v)
        out.append({"value": v, "label": lab})
    # multiple values, or a single value whose label is non-empty
    if len(out) >= 2 or (len(out) == 1 and out[0]["label"]):
        return out
    return None


CONTAINER_TYPES = {"list", "List", "object", "Object", "array", "Array"}


def parse_rows(html):
    tables = re.findall(r"<table[\s\S]*?</table>", html)
    if not tables:
        return None
    t = tables[0]
    rows = []
    for tr in re.findall(r"<tr[^>]*>[\s\S]*?</tr>", t):
        tds = re.findall(r"<td[^>]*>([\s\S]*?)</td>", tr)
        if len(tds) < 2:
            continue
        name, param = cell_text(tds[0]), cell_text(tds[1])
        if not param:
            continue
        typ, maxlen = parse_type(tds[3])
        req, cond = parse_required(tds[5])
        rows.append({
            "name": name,
            "param": param,
            "type": typ,
            "maxLength": maxlen,
            "required": req,
            "condition": cond,
            "enum": parse_enum(tds[2]),
            "description": cell_text(tds[6]),
        })
    return rows


def build_hierarchy(rows):
    """Stack-based hierarchy: container-typed fields (list/object) are parent nodes, following basic-typed fields go under them.

    Note: SPI notification field tables usually have only one nesting level (container -> basic fields);
    a new container means the previous container ended and we return to the top. Multi-level nesting would need manual confirmation.
    """
    roots = []
    stack = []
    for r in rows:
        node = dict(r)
        node["children"] = []
        is_container = r["type"] in CONTAINER_TYPES
        if is_container:
            stack.clear()
            roots.append(node)
            stack.append(node)
        else:
            if stack:
                stack[-1]["children"].append(node)
            else:
                roots.append(node)
    return roots


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url")
    ap.add_argument("--html", help="Skip rendering, parse an existing HTML file")
    ap.add_argument("--name", required=True, help="Output file name (e.g. gpt.inbound-notify)")
    ap.add_argument("--title", required=True, help="API title")
    ap.add_argument("--method", default="POST")
    args = ap.parse_args()

    if args.html:
        html_path = args.html
    elif args.url:
        html_path = os.path.join("/tmp", f"yop-render-{args.name}.html")
        render_url(args.url, html_path)
    else:
        raise SystemExit("Need one of --url or --html")

    html_text = open(html_path, encoding="utf-8").read()
    rows = parse_rows(html_text)
    if not rows:
        raise SystemExit("No table fields parsed; check the HTML content")

    data = {
        "name": args.name,
        "title": args.title,
        "method": args.method,
        "source": args.url or args.html,
        "fields": build_hierarchy(rows),
        "fetchedAt": __import__("time").strftime("%Y-%m-%dT%H:%M:%S"),
    }
    os.makedirs(SPIS_DIR, exist_ok=True)
    out = os.path.join(SPIS_DIR, f"{args.name}.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    log(f"✅ Output {out}, {len(rows)} fields")


if __name__ == "__main__":
    main()
