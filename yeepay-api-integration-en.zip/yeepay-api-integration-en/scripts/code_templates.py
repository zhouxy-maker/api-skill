#!/usr/bin/env python3
"""
code_templates.py — Code generation template library (5 languages x 3 call modes).

Source: Feishu wiki "Test Examples" (yeepay.feishu.cn/wiki/EBdRwGr0livg9KkOlHFcBM6Unvc),
covering 3 call modes x 5 languages:
  post_json   POST + application/json
  get_form    GET  + application/x-www-form-urlencoded
  post_form   POST + application/x-www-form-urlencoded

Notes:
  - Templates are desensitized: real test RSA private/public keys and appKey are replaced by @APP_KEY@ / @PRI_KEY@ / @YOP_PUBLIC_KEY@.
  - Fixed source-doc defects: Python empty method name `def (self):` -> `def call(self):`,
    Go empty function name `func () {` -> `func Call() {`.
  - Placeholders are replaced by gen_code.py: @API_PATH@ @METHOD@ @BODY@ @MODEL@ @DTO@ @CLIENT_METHOD@.
  - multipart/form-data (file/upload) is not covered by official docs; this module provides no template, gen_code.py prompts explicitly.
"""


# ============================================================
# JAVA — YopClient / YopClientBuilder / YopRequest
# ============================================================

JAVA_POST_JSON = '''package com.yeepay.yop.sdk.example;

import com.yeepay.yop.sdk.service.common.YopClient;
import com.yeepay.yop.sdk.service.common.YopClientBuilder;
import com.yeepay.yop.sdk.service.common.request.YopRequest;
import com.yeepay.yop.sdk.service.common.response.YopResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Example {

    // this Client is thread safe, please use singleton mode for multiple requests
    private static final YopClient client = YopClientBuilder.builder().build();
    private static final Logger LOGGER = LoggerFactory.getLogger(Example.class);

    public static void main(String[] args) {
        YopRequest request = new YopRequest("@API_PATH@", "@METHOD@");
@BODY@

        try {
            YopResponse response = client.request(request);
            LOGGER.info("result:{}", response.getResult());
        } catch (Exception ex) {
            LOGGER.error("Exception when calling, ex:", ex);
        }
    }

}
'''

JAVA_GET_FORM = JAVA_POST_JSON  # same frame, only @BODY@ differs
JAVA_POST_FORM = JAVA_POST_JSON


# ============================================================
# C# — YopRsaClient
# ============================================================

CSHARP_POST_JSON = '''using System;
using System.Diagnostics;
using SDK.yop.client;

namespace Example
{
    public class Example
    {
        public static void main()
        {
            string appKey = "@APP_KEY@";
            string apiUri = "@API_PATH@";
            /* your private key */
            string private_key = "@PRI_KEY@";
            /* platform public key */
            string yop_public_key = "@YOP_PUBLIC_KEY@";
            YopRequest request = new YopRequest(appKey, private_key, "https://openapi.yeepay.com/yop-center", yop_public_key);

@BODY@

            try
            {
                YopResponse response = YopRsaClient.post(apiUri, request);
                if (response.isSuccess()) {
                    Debug.Print(response.stringResult);
                }
            }
            catch (Exception e)
            {
                Debug.Print("Exception happened, " + e.Message );
            }
        }
    }

}
'''

CSHARP_GET_FORM = '''using System;
using System.Diagnostics;
using SDK.yop.client;

namespace Example
{
    public class Example
    {
        public static void main()
        {
            string appKey = "@APP_KEY@";
            string apiUri = "@API_PATH@";
            /* your private key */
            string private_key = "@PRI_KEY@";
            /* platform public key */
            string yop_public_key = "@YOP_PUBLIC_KEY@";
            YopRequest request = new YopRequest(appKey, private_key, "https://openapi.yeepay.com/yop-center", yop_public_key);

@BODY@

            try
            {
                YopResponse response = YopRsaClient.get(apiUri, request);
                if (response.isSuccess()) {
                    Debug.Print(response.stringResult);
                }
            }
            catch (Exception e)
            {
                Debug.Print("Exception happened, " + e.Message );
            }
        }
    }

}
'''

CSHARP_POST_FORM = '''using System;
using System.Diagnostics;
using SDK.yop.client;

namespace Example
{
    public class Example
    {
        public static void main()
        {
            string appKey = "@APP_KEY@";
            string apiUri = "@API_PATH@";
            /* your private key */
            string private_key = "@PRI_KEY@";
            /* platform public key */
            string yop_public_key = "@YOP_PUBLIC_KEY@";
            YopRequest request = new YopRequest(appKey, private_key, "https://openapi.yeepay.com/yop-center", yop_public_key);

@BODY@

            try
            {
                YopResponse response = YopRsaClient.post(apiUri, request);
                if (response.isSuccess()) {
                    Debug.Print(response.stringResult);
                }
            }
            catch (Exception e)
            {
                Debug.Print("Exception happened, " + e.Message );
            }
        }
    }

}
'''


# ============================================================
# Python — client.yopclient.YopClient
# ============================================================

PYTHON_POST_JSON = '''# -*- coding: utf-8 -*-

from client.yopclient import YopClient
from client.yop_client_config import YopClientConfig

# load default config file, config/yop_sdk_config_rsa_prod.json
client = YopClient()

# load your own defined config file
# config_file = 'config/yop_sdk_config_{}.json'.format(xxx)
# clientConfig = YopClientConfig(config_file)
# client = YopClient(clientConfig, env, cert_type)


class Client(object):
    def __init__(self, client):
        self.client = client

    def call(self):
        api = '@API_PATH@'
        params = {
@BODY@
        }
        res = self.client.post_json(api=api, params=params)
        # if you want to use another credentials, just define one and use client with it
        # credentials = YopCredentials(appKey='@APP_KEY@',
        #                                     cert_type='RSA2048|SM2',
        #                                     priKey='@PRI_KEY@')
        # self.client.xxx(api=api, params=params, credentials=credentials)
'''

PYTHON_GET_FORM = '''# -*- coding: utf-8 -*-

from client.yopclient import YopClient
from client.yop_client_config import YopClientConfig

# load default config file, config/yop_sdk_config_rsa_prod.json
client = YopClient()

# load your own defined config file
# config_file = 'config/yop_sdk_config_{}.json'.format(xxx)
# clientConfig = YopClientConfig(config_file)
# client = YopClient(clientConfig, env, cert_type)


class Client(object):
    def __init__(self, client):
        self.client = client

    def call(self):
        api = '@API_PATH@'
        params = {
@BODY@
        }
        res = self.client.get(api=api, params=params)
        # if you want to use another credentials, just define one and use client with it
        # credentials = YopCredentials(appKey='@APP_KEY@',
        #                                     cert_type='RSA2048|SM2',
        #                                     priKey='@PRI_KEY@')
        # self.client.xxx(api=api, params=params, credentials=credentials)
'''

PYTHON_POST_FORM = '''# -*- coding: utf-8 -*-

from client.yopclient import YopClient
from client.yop_client_config import YopClientConfig

# load default config file, config/yop_sdk_config_rsa_prod.json
client = YopClient()

# load your own defined config file
# config_file = 'config/yop_sdk_config_{}.json'.format(xxx)
# clientConfig = YopClientConfig(config_file)
# client = YopClient(clientConfig, env, cert_type)


class Client(object):
    def __init__(self, client):
        self.client = client

    def call(self):
        api = '@API_PATH@'
        params = {
@BODY@
        }
        res = self.client.post(api=api, params=params)
        # if you want to use another credentials, just define one and use client with it
        # credentials = YopCredentials(appKey='@APP_KEY@',
        #                                     cert_type='RSA2048|SM2',
        #                                     priKey='@PRI_KEY@')
        # self.client.xxx(api=api, params=params, credentials=credentials)
'''


# ============================================================
# PHP — GptClientBuilder + DTO
# ============================================================

PHP_POST_JSON = '''<?php
require_once(__DIR__ . '/vendor/autoload.php');

// choose one way as you want:
// 1. use local config file：supporting absolute path、relative path(against to the project root path)
$sdkConfigFile = "yop_sdk_config_default.json";
$api_client = Yeepay\\Yop\\Sdk\\Service\\Gpt\\GptClientBuilder::builder($sdkConfigFile)->build();

// 2. use json string (fill in your own app_key / yop_public_key / isv_private_key)
// $sdkConfigJson = '{"app_key":"@APP_KEY@","server_root":"https://openapi.yeepay.com/yop-center", ...}';
// $api_client = Yeepay\\Yop\\Sdk\\Service\\Gpt\\GptClientBuilder::builder(new AppSdkConfig(\\GuzzleHttp\\json_decode($sdkConfigJson, true)))->build();

$request = new Yeepay\\Yop\\Sdk\\Service\\Gpt\\Model\\@MODEL@();
// JSON request body: carried by the SDK-generated DTO; the DTO class name follows the generated SDK (derived from operationId here)
$body = new \\Yeepay\\Yop\\Sdk\\Service\\Gpt\\Model\\@DTO@();
@BODY@
$request->setBody($body);

try {
    $response = $api_client->@CLIENT_METHOD@($request);
    print_r($response->getResult());
}catch (\\Exception $e) {
    echo 'Exception when calling GptClient->@CLIENT_METHOD@: ', $e->getMessage(), PHP_EOL;
}
?>
'''

PHP_GET_FORM = '''<?php
require_once(__DIR__ . '/vendor/autoload.php');

// choose one way as you want:
// 1. use local config file：supporting absolute path、relative path(against to the project root path)
$sdkConfigFile = "yop_sdk_config_default.json";
$api_client = Yeepay\\Yop\\Sdk\\Service\\Gpt\\GptClientBuilder::builder($sdkConfigFile)->build();

// 2. use json string (fill in your own app_key / yop_public_key / isv_private_key)
// $sdkConfigJson = '{"app_key":"@APP_KEY@","server_root":"https://openapi.yeepay.com/yop-center", ...}';
// $api_client = Yeepay\\Yop\\Sdk\\Service\\Gpt\\GptClientBuilder::builder(new AppSdkConfig(\\GuzzleHttp\\json_decode($sdkConfigJson, true)))->build();

$request = new Yeepay\\Yop\\Sdk\\Service\\Gpt\\Model\\@MODEL@();
@BODY@

try {
    $response = $api_client->@CLIENT_METHOD@($request);
    print_r($response->getResult());
}catch (\\Exception $e) {
    echo 'Exception when calling GptClient->@CLIENT_METHOD@: ', $e->getMessage(), PHP_EOL;
}
?>
'''

PHP_POST_FORM = PHP_GET_FORM  # same frame, only @BODY@ differs


# ============================================================
# Go — yop-go-sdk
# ============================================================

GO_POST_JSON = '''import (
    "github.com/yop-platform/yop-go-sdk/yop/client"
    "github.com/yop-platform/yop-go-sdk/yop/request"
    "github.com/yop-platform/yop-go-sdk/yop/utils"
)

func Call() {
    // For custom credentials: var priKey = &request.IsvPriKey{Value: "@PRI_KEY@", CertType: request.RSA2048}
    var yopRequest = request.NewYopRequest("@METHOD@", "@API_PATH@")

    // json params
    var params = map[string]any{
@BODY@
    }

    yopRequest.Content = utils.ParseToJsonStr(params)
    yopResp, err := client.DefaultClient.Request(yopRequest)
    if nil != err {
        // request failed
    }
    // yopResp.Result type is json
}
'''

GO_GET_FORM = '''import (
    "github.com/yop-platform/yop-go-sdk/yop/client"
    "github.com/yop-platform/yop-go-sdk/yop/request"
)

func Call() {
    // For custom credentials: var priKey = &request.IsvPriKey{Value: "@PRI_KEY@", CertType: request.RSA2048}
    var yopRequest = request.NewYopRequest("@METHOD@", "@API_PATH@")

@BODY@

    yopResp, err := client.DefaultClient.Request(yopRequest)
    if nil != err {
        // request failed
    }
    // yopResp.Result type is json
}
'''

GO_POST_FORM = GO_GET_FORM  # same frame, only @BODY@ differs


# ============================================================
# template index
# ============================================================

TEMPLATES = {
    "java": {
        "post_json": JAVA_POST_JSON,
        "get_form": JAVA_GET_FORM,
        "post_form": JAVA_POST_FORM,
    },
    "csharp": {
        "post_json": CSHARP_POST_JSON,
        "get_form": CSHARP_GET_FORM,
        "post_form": CSHARP_POST_FORM,
    },
    "python": {
        "post_json": PYTHON_POST_JSON,
        "get_form": PYTHON_GET_FORM,
        "post_form": PYTHON_POST_FORM,
    },
    "php": {
        "post_json": PHP_POST_JSON,
        "get_form": PHP_GET_FORM,
        "post_form": PHP_POST_FORM,
    },
    "go": {
        "post_json": GO_POST_JSON,
        "get_form": GO_GET_FORM,
        "post_form": GO_POST_FORM,
    },
}

# language display names (for output hints)
LANG_LABEL = {
    "java": "JAVA",
    "csharp": "C#",
    "python": "PYTHON",
    "php": "PHP",
    "go": "GO",
}


def mode_of(method, content_type):
    """Derive the call mode from method + contentType."""
    ct = (content_type or "").lower()
    if method.upper() == "GET":
        return "get_form"
    if "multipart" in ct:
        return "multipart"          # not covered by official docs; gen_code prompts
    if "json" in ct:
        return "post_json"
    if "x-www-form-urlencoded" in ct:
        return "post_form"
    return "post_json"              # fallback (POST without explicit contentType treated as JSON)
