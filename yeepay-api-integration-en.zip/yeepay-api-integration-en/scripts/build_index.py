#!/usr/bin/env python3
"""
build_index.py — Derive per-API "Q&A packs" (for LLM close reading) from the full source.

Background: kb/apis/{uri}.json is the full source produced by fetch_docs.py. Field Q&A and
debugging scenarios only need metadata + fields + errcodes + SPI definitions, not the whole file.

Sources (read-only, do not hand-edit):
  kb/apis/{uri}.json          full source (metadata + reqParams/respParams + errcodes + spis)
  rules/field-conditions.yaml conditional-required rule base (required_when / condition_text / confidence)

Output (rebuildable anytime):
  kb/api-packs/{uri}.json     Q&A pack = metadata + reqParams/respParams + errcodes + spis
                              (C fields merge conditional rules; fields are slimmed)

Note: sample code is no longer scraped from the open platform (official sampleCodes are unmaintained).
Code generation now uses scripts/gen_code.py with scripts/code_templates.py templates keyed by contentType.

Field matching rule: kb/apis has no nested children; field key is always {uri}.{name}.

Usage:
  python3 build_index.py
"""
import glob
import json
import os
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_DIR = os.path.join(SKILL_DIR, "references", "kb")
RULES_DIR = os.path.join(SKILL_DIR, "references", "rules")
PACK_DIR = os.path.join(KB_DIR, "api-packs")

# redundant keys in reqParams nodes that are useless to the LLM (path always == name; no nested children/depth/root)
DROP_KEYS = {"path", "children", "depth", "root"}
# conditional-rule keys worth merging into a field
COND_KEYS = ("required_when", "condition_text", "confidence", "source_doc")


def load_yaml(path):
    try:
        import yaml
    except ImportError:
        sys.stderr.write("Missing pyyaml\n")
        sys.exit(2)
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def slim_field(node, cond_rule):
    """Slim a field node + merge the conditional rule (only C fields have cond_rule)."""
    out = {}
    for k, v in node.items():
        if k in DROP_KEYS:
            continue
        if v is None or v == "" or v == [] or v == {}:
            continue
        out[k] = v
    if cond_rule:
        for k in COND_KEYS:
            if cond_rule.get(k) not in (None, ""):
                out[k] = cond_rule[k]
    return out


def build():
    conditions = load_yaml(os.path.join(RULES_DIR, "field-conditions.yaml"))["fields"]

    os.makedirs(PACK_DIR, exist_ok=True)

    files = sorted(glob.glob(os.path.join(KB_DIR, "apis", "*.json")))
    stats = {"packs": 0, "pack_bytes": 0}
    for f in files:
        api = json.load(open(f, encoding="utf-8"))
        uri = api["uri"]

        # 1) Q&A pack: fields + required + errcodes + spis (source no longer has sampleCodes)
        pack = {
            "uri": uri,
            "apiId": api.get("apiId"),
            "title": api.get("title"),
            "method": api.get("method"),
            "path": api.get("path"),
            "apiGroup": api.get("apiGroup"),
            "operationId": api.get("operationId"),
            "desc": api.get("desc"),
            "contentType": api.get("contentType", ""),
            "commonRef": api.get("commonRef"),
            "securityReqs": api.get("securityReqs", []),
            "requestEncrypt": api.get("requestEncrypt", False),
            "responseEncrypt": api.get("responseEncrypt", False),
        }
        req_out = []
        for n in api.get("reqParams", []):
            key = f"{uri}.{n.get('name', '')}"
            cond = conditions.get(key)
            req_out.append(slim_field(n, cond))
        pack["reqParams"] = req_out
        pack["respParams"] = [slim_field(n, None) for n in api.get("respParams", [])]
        pack["errcodes"] = api.get("errcodes", [])
        pack["spis"] = api.get("spis", [])
        # request/response examples are useful reference for field Q&A (small), keep them
        if api.get("reqExample"):
            pack["reqExample"] = api["reqExample"]
        if api.get("respExample"):
            pack["respExample"] = api["respExample"]

        pack_path = os.path.join(PACK_DIR, f"{uri}.json")
        with open(pack_path, "w", encoding="utf-8") as fh:
            json.dump(pack, fh, ensure_ascii=False, indent=2)

        stats["packs"] += 1
        stats["pack_bytes"] += os.path.getsize(pack_path)

    print(f"Generated {stats['packs']} api-packs ({stats['pack_bytes']}B total)")
    avg = stats["pack_bytes"] // max(stats["packs"], 1)
    print(f"Average api-pack size: {avg}B")


if __name__ == "__main__":
    build()
