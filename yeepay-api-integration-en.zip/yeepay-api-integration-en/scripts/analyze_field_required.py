#!/usr/bin/env python3
"""
analyze_field_required.py — Full field-required analysis (M/O/C + conditional-required conditions).

Core addition: identify fields marked required=O but whose description carries conditional
semantics ("required when ...", "provide when ...", "either A or B must be filled", etc.),
and upgrade them to C (conditionally required).

Output:
  1. references/rules/field-required.yaml —— full field-required list (M/O/C + conditions)
  2. Writes back the O->C field's required value into the JSON (so resolve_fields.py includes them in scene clarification)

Usage: python3 scripts/analyze_field_required.py
"""
import glob
import json
import os
import re
import sys
import yaml
from collections import Counter

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_DIR = os.path.join(SKILL_DIR, "references", "kb")
RULES_DIR = os.path.join(SKILL_DIR, "references", "rules")

# ============================================================
# O->C upgrade whitelist (manually confirmed: required=O but the
# description is actually conditionally required).
# key = "<uri>.<path>", value = condition text
# ============================================================
OC_UPGRADE = {
    "get__rest__v1.0__gpt__payer__query.id":
        "Required for exact query; for batch query, provide payerSource or payerStatus instead",
    "get__yos__v1.0__gpt__file__download.requestId":
        "Required when type is DECLARATION_FILE/OVERSEA_PAYMENT/WITHDRAW/VA_CERTIFICATE/"
        "COLLECTION_CERTIFICATE/COLLECTION_REFUND_CERTIFICATE",
    "post__rest__v1.0__gpt__account__balance__query.subMerchantId":
        "Provide when querying a sub-merchant's balance; leave blank when querying your own balance",
    "post__rest__v1.0__gpt__declaration-detail__commit.tradePlatformName":
        "Either tradePlatformName or shopUrl must be filled (at least one)",
    "post__rest__v1.0__gpt__declaration-detail__commit.shopUrl":
        "Either tradePlatformName or shopUrl must be filled (at least one)",
    "post__rest__v1.0__gpt__payment__order.receiveCurrency":
        "Provide when payoutType=OVERSEA_PAYMENT/WITHDRAW; not required when payoutType=DOMESTIC_PAYMENT/DOMESTIC_PAYMENT_FX",
    "post__rest__v1.0__gpt__payment__order.pobo":
        "Required for overseas payment when a specific payer name needs to be used",
    "post__rest__v1.0__gpt__payment__order.payerId":
        "Required for POBO payments where the payer and account holder have different names",
    "post__rest__v1.0__gpt__payment__order.shareholderRatio":
        "For POBO payments where the payer and account holder have different names, if the payer "
        "is a corporate entity and the beneficiary country is within SEPA/GBR/AUS",
    "post__rest__v1.0__gpt__wallet__apply.credentialsNumber":
        "Required when the account holder is a legal representative or shareholder of an enterprise",
}


def extract_condition(desc):
    """Best-effort extraction of the condition clause from an English description."""
    if not desc:
        return None
    # "Required when X" / "Required if X" / "Required for X"
    m = re.search(r"[Rr]equired\s+(?:when|if|for)\s+([^.\n]+)", desc)
    if m:
        return "Required when " + m.group(1).strip().rstrip(".").strip()
    # "When X, ... (this field is) mandatory/required"
    m = re.search(r"[Ww]hen\s+([^,.\n]+),\s*(?:this\s+field\s+)?(?:is\s+)?(?:mandatory|required)", desc)
    if m:
        return "Required when " + m.group(1).strip()
    # default required, "X is not required (when Y)"
    m = re.search(r"([^.\n]+?)\s+is\s+not\s+required", desc)
    if m:
        return "Not required when " + m.group(1).strip()
    return None


def extract_source(desc):
    """Extract the referenced external doc name from "For details, see: X" / "See X"."""
    if not desc:
        return None
    m = re.search(r"(?:For details[,:]?\s*)?[Ss]ee\s*[:：]?\s*([^.\n]+)", desc)
    return m.group(1).strip() if m else None


def to_when(cond_text, field_values):
    """Structure cond_text into required_when (simple single-value AND only)."""
    if not cond_text:
        return None
    body = re.sub(r"^Required when\s+", "", cond_text)
    body = re.sub(r"^Not required when\s+", "", body)
    body = re.sub(r"^Required for\s+", "", body)
    body = body.strip().rstrip(".")
    # complex semantics -> give up (let a human confirm)
    if re.search(r"\s(or|and|not|either|at least one)|[/，,、]", body):
        return None
    clauses = []
    for seg in re.split(r"[，,;；\n]+", body):
        seg = seg.strip()
        if not seg:
            continue
        m = re.match(r"^(\w+)\s*[=＝]\s*([A-Za-z0-9_\-]+)$", seg)
        if not m:
            return None
        field, val = m.group(1), m.group(2)
        if field not in field_values:
            return None
        clauses.append(f'{field}=="{val}"')
    return " && ".join(clauses) if clauses else None


def flatten(nodes, out=None):
    if out is None:
        out = []
    for n in nodes:
        out.append(n)
        if n.get("children"):
            flatten(n["children"], out)
    return out


def main():
    # 1) scan all fields, apply O->C upgrade
    upgraded = []
    all_entries = []  # (uri, title, path, required_final, title_text, desc, enum, cond, src)
    for f in sorted(glob.glob(os.path.join(KB_DIR, "apis", "*.json"))):
        d = json.load(open(f, encoding="utf-8"))
        uri = d["uri"]
        fields = flatten(d.get("reqParams", []))
        field_names = {n.get("path", "").split(".")[-1] for n in fields}
        for n in fields:
            path = n.get("path", "")
            key = f"{uri}.{path}"
            req = n.get("required", "O")
            desc = (n.get("description") or "").strip()
            # O->C upgrade
            if req == "O" and key in OC_UPGRADE:
                req = "C"
                upgraded.append(key)
                n["required"] = "C"
            cond = OC_UPGRADE.get(key) if key in OC_UPGRADE else extract_condition(desc)
            src = extract_source(desc)
            all_entries.append({
                "uri": uri, "title": d.get("title", ""), "path": path,
                "field_title": n.get("title", ""), "type": n.get("type", ""),
                "required": req, "desc": desc,
                "enum": [e["value"] for e in (n.get("enum") or [])] or None,
                "cond": cond, "src": src,
                "field_names": field_names,
            })
        # write back required corrections
        json.dump(d, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    # 2) generate full list field-required.yaml
    out = {"_meta": {
        "description": "Full field-required list (request params reqParams). required: M=required / C=conditionally required / O=optional. "
                       "condition_text is the trigger condition of a C field; required_when is the structured expression (empty = manual confirmation).",
        "confidence": "confirmed=manually confirmed / inferred=AI extracted from description / unresolved=condition is in an external doc",
        "generated_by": "python3 scripts/analyze_field_required.py",
        "o_to_c_upgrade_note": "Fields marked required=O whose description carries conditional semantics were upgraded to C; see the OC_UPGRADE whitelist.",
    }, "fields": {}}
    for e in sorted(all_entries, key=lambda x: (x["uri"], x["path"])):
        when = to_when(e["cond"], e["field_names"]) if e["cond"] else None
        conf = "confirmed" if (e["uri"] + "." + e["path"]) in OC_UPGRADE else (
            "inferred" if (e["required"] == "C" and e["cond"]) else None)
        if e["required"] == "C":
            conf = conf or ("unresolved" if not e["cond"] else "inferred")
        entry = {
            "required": e["required"],
            "title": e["field_title"],
            "type": e["type"],
        }
        if e["enum"]:
            entry["enum"] = e["enum"]
        if e["required"] == "C":
            entry["condition_text"] = e["cond"]
            entry["required_when"] = when
            entry["source_doc"] = e["src"]
            entry["confidence"] = conf
        entry["description"] = e["desc"]
        out["fields"][f"{e['uri']}.{e['path']}"] = entry

    with open(os.path.join(RULES_DIR, "field-required.yaml"), "w", encoding="utf-8") as fp:
        yaml.safe_dump(out, fp, allow_unicode=True, sort_keys=False, width=200)

    # 2.5) generate field-conditions.yaml (C field rules, consumed by resolve_fields.py)
    cond_out = {"_meta": {
        "description": "Conditional-required rule base (field-level C). Empty required_when means the condition cannot be auto-structured; confirm manually, do not fabricate.",
        "confidence": "confirmed=manually confirmed / inferred=AI extracted from description, to confirm / unresolved=condition is in an external doc, to fill",
        "generated_by": "python3 scripts/analyze_field_required.py",
    }, "fields": {}}
    for e in sorted(all_entries, key=lambda x: (x["uri"], x["path"])):
        if e["required"] != "C":
            continue
        key = f"{e['uri']}.{e['path']}"
        when = to_when(e["cond"], e["field_names"]) if e["cond"] else None
        conf = "confirmed" if key in OC_UPGRADE else ("inferred" if e["cond"] else "unresolved")
        cond_out["fields"][key] = {
            "api": e["uri"],
            "apiTitle": e["title"],
            "field": e["path"],
            "type": e["type"],
            "enum": e["enum"],
            "required_when": when,
            "condition_text": e["cond"],
            "source_doc": e["src"],
            "confidence": conf,
            "description": e["desc"],
        }
    with open(os.path.join(RULES_DIR, "field-conditions.yaml"), "w", encoding="utf-8") as fp:
        yaml.safe_dump(cond_out, fp, allow_unicode=True, sort_keys=False, width=200)

    # 3) stats
    stat = Counter(e["required"] for e in all_entries)
    c_fields = [e for e in all_entries if e["required"] == "C"]
    with_when = sum(1 for e in c_fields if to_when(e["cond"], e["field_names"]))
    print(f"Total fields (reqParams): {len(all_entries)}")
    print(f"required distribution: {dict(stat)}")
    print(f"O->C upgraded fields: {len(upgraded)}")
    for u in sorted(upgraded):
        print(f"  ^ {u}")
    print(f"C field total: {len(c_fields)}")
    print(f"  structured required_when: {with_when}")
    print(f"  extracted condition_text: {sum(1 for e in c_fields if e['cond'])}")
    print(f"  referencing external doc (source_doc): {sum(1 for e in c_fields if e['src'])}")
    print(f"\nLists written to {os.path.join(RULES_DIR, 'field-required.yaml')}")


if __name__ == "__main__":
    main()
